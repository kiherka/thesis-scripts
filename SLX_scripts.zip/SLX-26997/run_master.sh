#!/bin/bash
# Run the Snakemake master on the login node (inside tmux/screen).
#
# Usage:  screen -S smk26997
#         bash run_master.sh          # runs in foreground
#         # Ctrl-a d  to detach       # re-attach: screen -r smk26997
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-26997

LOG=logs/slurm/smk_master_$(date +%Y%m%d_%H%M%S).log
echo "Logging to $LOG"

snakemake --profile profile --jobs 200 2>&1 | tee "$LOG"
