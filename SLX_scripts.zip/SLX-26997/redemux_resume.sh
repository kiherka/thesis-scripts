#!/bin/bash
# Resume re-demultiplexing from Lane 3 R2 onwards.
# The original redemux_excluded.sh died during Lane 3 R2.
#
# Usage:  screen -S redemux
#         bash redemux_resume.sh 2>&1 | tee -a redemux_excluded.log
#         # Ctrl-a d  to detach
set -euo pipefail

# Prevent shell timeout on login node
unset TMOUT 2>/dev/null || true
export TMOUT=0

# Keep-alive: print a dot every 5 min so the session is never idle
keep_alive() {
    while true; do sleep 300; echo -n "."; done
}
keep_alive &
KEEP_ALIVE_PID=$!
trap 'kill $KEEP_ALIVE_PID 2>/dev/null' EXIT

cd /mnt/scratchc/sblab/herka01/SLX-26997

DEMUX=/Users/simeon01/applications/demultiplexer.rhel/demuxFQ
NAS=/mnt/nas-data/sblab/group_folders/herka01/SLX-26997_ENS_BG4_all

R1=r1_excluded.txt
R2=r2_excluded.txt

FLAGS="-c -d -i -e -t 1 -R -r 0.01 -l 9"

wait_for_file() {
    local f="$1"
    if [[ -f "$f" ]]; then return 0; fi
    echo "  Waiting for $f ..."
    while [[ ! -f "$f" ]]; do sleep 120; done
    local prev=0 curr
    while true; do
        curr=$(stat --format='%s' "$f" 2>/dev/null || echo 0)
        if [[ "$curr" -eq "$prev" && "$curr" -gt 0 ]]; then break; fi
        prev=$curr
        echo "    size=${curr} — still copying, rechecking in 2 min …"
        sleep 120
    done
    echo "  File ready: $f ($(numfmt --to=iec "$curr"))"
}

# ── Clean up partial Lane 3 R2 files from crashed run ──────────────────────
echo "=== Cleaning partial Lane 3 R2 files ==="
for s in BG4_4A08_B1 BG4_4C07_B1 BG4_4E12_B1 BG4_4F10_B1 \
         BG4_6A11_B1 BG4_6C05_B1 BG4_6D11_B1 BG4_7C08_B1 \
         BG4_7F06_B1 BG4_7F07_B1 BG4_7F10_B1 BG4_8A04_B1 \
         BG4_8A05_B1 BG4_8A06_B1; do
    f="./demultiplexed_lane3/${s}_r2.fq.gz"
    if [[ -f "$f" ]]; then rm -v "$f"; fi
done

# ── Lane 3 R2 (resume point) ───────────────────────────────────────────────
echo "=== Lane 3 R2 ==="
wait_for_file ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_2.r_2.fq.gz
$DEMUX $FLAGS -o ./demultiplexed_lane3 -s redemux_summary_lane3_r2.txt \
    $R2 ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_2.r_2.fq.gz

# ── Soma (SLX-26996 lostreads — on scratch) ────────────────────────────────
echo "=== Soma R1 ==="
$DEMUX $FLAGS -o ./demultiplexed_Soma -s redemux_summary_Soma_r1.txt \
    $R1 /mnt/scratchc/sblab/dhir01/Files/Krz/SLX-26996/SLX-26996.lostreads2.r1.fq.gz

echo "=== Soma R2 ==="
$DEMUX $FLAGS -o ./demultiplexed_Soma -s redemux_summary_Soma_r2.txt \
    $R2 /mnt/scratchc/sblab/dhir01/Files/Krz/SLX-26996/SLX-26996.lostreads2.r2.fq.gz

# ── Lane 4 (flowcell 23LMW2LT4, s_3) ──────────────────────────────────────
echo "=== Lane 4 R1 ==="
wait_for_file ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_3.r_1.fq.gz
$DEMUX $FLAGS -o ./demultiplexed_lane4 -s redemux_summary_lane4_r1.txt \
    $R1 ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_3.r_1.fq.gz

echo "=== Lane 4 R2 ==="
wait_for_file ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_3.r_2.fq.gz
$DEMUX $FLAGS -o ./demultiplexed_lane4 -s redemux_summary_lane4_r2.txt \
    $R2 ${NAS}/SLX-26997.UnspecifiedIndex.23LMW2LT4.s_3.r_2.fq.gz

# ── Lane 1 (flowcell 23LNGJLT4) ────────────────────────────────────────────
echo "=== Lane 1 R1 ==="
wait_for_file ${NAS}/SLX-26997.UnspecifiedIndex.23LNGJLT4.s_1.r_1.fq.gz
$DEMUX $FLAGS -o ./demultiplexed_lane1 -s redemux_summary_lane1_r1.txt \
    $R1 ${NAS}/SLX-26997.UnspecifiedIndex.23LNGJLT4.s_1.r_1.fq.gz

echo "=== Lane 1 R2 ==="
wait_for_file ${NAS}/SLX-26997.UnspecifiedIndex.23LNGJLT4.s_1.r_2.fq.gz
$DEMUX $FLAGS -o ./demultiplexed_lane1 -s redemux_summary_lane1_r2.txt \
    $R2 ${NAS}/SLX-26997.UnspecifiedIndex.23LNGJLT4.s_1.r_2.fq.gz

echo "=== All done ==="
