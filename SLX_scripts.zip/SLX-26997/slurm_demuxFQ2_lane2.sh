#!/bin/bash

mkdir demultiplexed_lane2

sbatch --time 72:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-26997_lostreads_r1.fq.gz  -o ./demultiplexed_lane2  -s SLX-26997_summary2_demuxFQ_lane2_r1.txt r1.txt SLX-26997.UnspecifiedIndex.23LMW2LT4.s_1.r_1.fq.gz"

sbatch --mem 32G --time 72:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-26997_lostreads_r2.fq.gz -o ./demultiplexed_lane2 -s SLX-26997_summary2_demuxFQ_lane2_r2.txt r2.txt  SLX-26997.UnspecifiedIndex.23LMW2LT4.s_1.r_2.fq.gz"