#!/bin/bash

mkdir demultiplexed_Soma

sbatch --time 72:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-26996_lostreads_r1.fq.gz  -o ./demultiplexed_Soma  -s SLX-26996_summary2_demuxFQ_Soma_r1.txt r1.txt /mnt/scratchc/sblab/dhir01/Files/Krz/SLX-26996/SLX-26996.lostreads2.r1.fq.gz"

sbatch --mem 32G --time 72:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-26996_lostreads_r2.fq.gz -o ./demultiplexed_Soma -s SLX-26996_summary2_demuxFQ_Soma_r2.txt r2.txt /mnt/scratchc/sblab/dhir01/Files/Krz/SLX-26996/SLX-26996.lostreads2.r2.fq.gz"