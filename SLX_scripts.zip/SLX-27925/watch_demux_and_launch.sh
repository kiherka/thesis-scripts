#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --job-name=watch_demux_27925
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=2-12:00:00
#SBATCH --output=logs/slurm/watch_demux_%j.out
#SBATCH --error=logs/slurm/watch_demux_%j.err

set -euo pipefail

# Demux job IDs to monitor
DEMUX_JOBS="50915042,50915043,50915044,50915045"
PIPELINE_DIR="/scratche/slow/sblab/herka01/SLX-27925/pipeline"

echo "$(date) | Watching demux jobs: ${DEMUX_JOBS}"
echo "$(date) | Will launch Snakemake pipeline in: ${PIPELINE_DIR}"

# Poll every 60 seconds until all demux jobs have completed
while true; do
    # Count how many of our jobs are still in the queue (any state)
    REMAINING=$(squeue -j "${DEMUX_JOBS}" -h -o "%i" 2>/dev/null | wc -l)

    if [[ "${REMAINING}" -eq 0 ]]; then
        echo "$(date) | All demux jobs finished — checking exit codes"
        break
    fi

    echo "$(date) | ${REMAINING} demux job(s) still running/pending — sleeping 60s"
    sleep 60
done

# Verify all jobs completed successfully
ALL_OK=true
for JOB in ${DEMUX_JOBS//,/ }; do
    STATE=$(sacct -j "${JOB}" --format=State -n -X | tr -d ' ')
    echo "  Job ${JOB}: ${STATE}"
    if [[ "${STATE}" != "COMPLETED" ]]; then
        echo "  WARNING: Job ${JOB} ended with state ${STATE}"
        ALL_OK=false
    fi
done

if [[ "${ALL_OK}" != "true" ]]; then
    echo "$(date) | ERROR: One or more demux jobs failed. NOT launching pipeline."
    echo "  Check slurm-*.out logs for details."
    exit 1
fi

echo "$(date) | All demux jobs completed successfully"

# Check that demultiplexed output directories are populated
LANE1_COUNT=$(ls /scratche/slow/sblab/herka01/SLX-27925/demultiplexed_lane1/*_r1.fq.gz 2>/dev/null | wc -l)
LANE2_COUNT=$(ls /scratche/slow/sblab/herka01/SLX-27925/demultiplexed_lane2/*_r1.fq.gz 2>/dev/null | wc -l)
echo "  Lane 1 samples: ${LANE1_COUNT}"
echo "  Lane 2 samples: ${LANE2_COUNT}"

if [[ "${LANE1_COUNT}" -eq 0 ]] || [[ "${LANE2_COUNT}" -eq 0 ]]; then
    echo "$(date) | ERROR: Missing demultiplexed files. NOT launching pipeline."
    exit 1
fi

# Launch the Snakemake pipeline
echo "$(date) | Launching Snakemake pipeline"

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd "${PIPELINE_DIR}"
mkdir -p logs/slurm

snakemake --profile profile --jobs 200

echo "$(date) | Snakemake pipeline finished"
