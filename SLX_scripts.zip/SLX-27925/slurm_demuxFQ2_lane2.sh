#!/bin/bash

mkdir demultiplexed_lane2

sbatch --time 1-23:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -b SLX-27925_lostreads_r1.fq.gz  -o ./demultiplexed_lane2  -s SLX-27925_summary2_demuxFQ_r1.txt r1.txt SLX-27925.UnspecifiedIndex.23LNK5LT4.s_8.r_1.fq.gz"

sbatch --mem 32G --time 1-23:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -b SLX-27925_lostreads_r2.fq.gz -o ./demultiplexed_lane2 -s SLX-27925_summary2_demuxFQ_r2.txt r2.txt  SLX-27925.UnspecifiedIndex.23LNK5LT4.s_8.r_2.fq.gz"