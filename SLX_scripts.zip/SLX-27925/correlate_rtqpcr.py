#!/usr/bin/env python3
"""
Correlate RT-qPCR fold changes (alpha-globin expression) with
BG4 / CUTAC normalised CPM at the target locus.

Inputs (all in cpm_analysis/):
  ddct_results_livak.csv  – RT-qPCR fold changes per sample
  Sample_mapping.xlsx     – 'Sample' sheet: clone names grid
                            'Number' sheet: sample numbers at same positions
  per_sample_cpm.tsv      – ChIP-seq norm_cpm per biological replicate
                            (includes dedup_reads column for filtering)

Filter:
  ChIP-seq replicates with < MIN_DEDUP_READS deduplicated reads are excluded.
  Clones whose every replicate fails this filter are dropped from the correlation.

Outputs (cpm_analysis/):
  05_rtqpcr_correlation.pdf      – scatter + regression for BG4 and CUTAC
  rtqpcr_correlation_stats.tsv   – Pearson / Spearman stats per assay
  rtqpcr_correlation_data.tsv    – merged per-sample table used for plotting
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

# ── Paths ────────────────────────────────────────────────────────────────────
ANALYSIS_DIR    = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis"
DDCT_CSV        = os.path.join(ANALYSIS_DIR, "ddct_results_livak.csv")
MAPPING_XLSX    = os.path.join(ANALYSIS_DIR, "Sample_mapping.xlsx")
CPM_TSV         = os.path.join(ANALYSIS_DIR, "per_sample_cpm.tsv")
OUT_PDF         = os.path.join(ANALYSIS_DIR, "05_rtqpcr_correlation.pdf")
OUT_TSV         = os.path.join(ANALYSIS_DIR, "rtqpcr_correlation_stats.tsv")
OUT_MERGED_TSV  = os.path.join(ANALYSIS_DIR, "rtqpcr_correlation_data.tsv")

MIN_DEDUP_READS = 1_000_000   # ChIP-seq replicates below this are excluded

# Clones excluded from BG4 analysis only (visually confirmed outliers)
BG4_OUTLIER_CLONES = {
    "KH-14-N13-2",   # BG4 CPM ~0.86, >4x above next highest
    "KH-17-C-1",     # BG4 CPM ~0.49, substantially above cluster
    "KH-WT-N13-4",   # RT-qPCR fold change ~4.16, >2x above next highest
}

# ── 1. Build sample-number → clone-name mapping ───────────────────────────
xf     = pd.ExcelFile(MAPPING_XLSX)
names  = pd.read_excel(xf, sheet_name="Sample", header=None)
nums   = pd.read_excel(xf, sheet_name="Number", header=None)

num2clone = {}
for r in range(names.shape[0]):
    for c in range(names.shape[1]):
        name = names.iloc[r, c]
        num  = nums.iloc[r, c]
        if pd.notna(name) and pd.notna(num):
            num2clone[int(num)] = str(name).strip()

print("Sample-number → clone mapping:")
for k, v in sorted(num2clone.items()):
    print(f"  {k:3d} → {v}")

# ── 2. Load RT-qPCR data ─────────────────────────────────────────────────
ddct = pd.read_csv(DDCT_CSV)
ddct["clone"] = ddct["Sample"].map(num2clone)

missing = ddct[ddct["clone"].isna()]["Sample"].tolist()
if missing:
    print(f"\nRT-qPCR sample numbers without clone mapping: {missing}")

ddct = ddct.dropna(subset=["clone"])

# Map group label → edit_category
group2cat = {
    "14_control": "KH-14-C",
    "17_control": "KH-17-C",
    "WT_control": "KH-WT-C",
    "WT_N15":     "KH-WT-N15",
    "14_N14":     "KH-14-N14",
    "14_N12":     "KH-14-N12",
    "17_N12":     "KH-17-N12",
    "14_N13":     "KH-14-N13",
    "17_N13":     "KH-17-N13",
    "WT_N13":     "KH-WT-N13",
}
ddct["edit_category"] = ddct["Group"].map(group2cat)

print(f"\nRT-qPCR data after mapping: {len(ddct)} samples")
print(ddct[["Sample", "clone", "Group", "edit_category", "Fold change"]].to_string(index=False))

# ── 3. Load ChIP-seq CPM, apply ≥1M dedup-reads filter ───────────────────
cpm_all = pd.read_csv(CPM_TSV, sep="\t")

excluded = cpm_all[cpm_all["dedup_reads"] < MIN_DEDUP_READS]
if not excluded.empty:
    print(f"\nExcluding {len(excluded)} ChIP-seq replicate(s) with "
          f"< {MIN_DEDUP_READS:,} deduplicated reads:")
    print(excluded[["stem", "dedup_reads"]].to_string(index=False))
else:
    print(f"\nAll ChIP-seq replicates pass the ≥{MIN_DEDUP_READS:,} filter.")

cpm = cpm_all[cpm_all["dedup_reads"] >= MIN_DEDUP_READS].copy()
print(f"{len(cpm)} of {len(cpm_all)} ChIP-seq replicates retained.")

# Strip assay prefix: "BG4_KH-14-N12-1" → "KH-14-N12-1"
cpm["clone"] = cpm["cell_line"].str.replace(r"^(BG4|CUTAC)_", "", regex=True)

# Average norm_cpm over passing replicates per assay × clone
mean_cpm = (
    cpm.groupby(["assay", "clone"])
    .agg(mean_norm_cpm=("norm_cpm", "mean"), n_reps=("norm_cpm", "count"))
    .reset_index()
)

print(f"\nMean CPM table ({len(mean_cpm)} assay × clone combinations):")
print(mean_cpm.to_string(index=False))

# ── 4. Merge RT-qPCR with ChIP CPM ──────────────────────────────────────
merged = ddct.merge(mean_cpm, on="clone", how="inner")

# Clones present in RT-qPCR but absent from ChIP (all reps failed filter)
chip_clones = set(mean_cpm["clone"])
rtqpcr_clones_by_assay = {
    assay: set(ddct["clone"])
    for assay in ["BG4", "CUTAC"]
}
for assay in ["BG4", "CUTAC"]:
    missing_clones = rtqpcr_clones_by_assay[assay] - chip_clones
    if missing_clones:
        print(f"\nRT-qPCR clones with no passing {assay} ChIP replicates "
              f"(excluded from correlation): {sorted(missing_clones)}")

print(f"\nMerged data: {len(merged)} rows "
      f"({merged[merged['assay']=='BG4'].shape[0]} BG4, "
      f"{merged[merged['assay']=='CUTAC'].shape[0]} CUTAC)")
print(merged[["clone", "edit_category", "Fold change", "assay",
              "mean_norm_cpm", "n_reps"]].to_string(index=False))

merged.to_csv(OUT_MERGED_TSV, sep="\t", index=False)
print(f"\nSaved merged data → {OUT_MERGED_TSV}")

# ── 5. Colour palette (edit category) ────────────────────────────────────
cats    = sorted(merged["edit_category"].unique())
colours = dict(zip(cats, plt.cm.tab10.colors[:len(cats)]))

# ── 6. Plot ──────────────────────────────────────────────────────────────
assays   = ["BG4", "CUTAC"]
fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), constrained_layout=True)

stats_rows = []

for ax, assay in zip(axes, assays):
    sub = merged[merged["assay"] == assay].copy()

    # Apply BG4-specific outlier exclusion
    if assay == "BG4" and BG4_OUTLIER_CLONES:
        outlier_mask = sub["clone"].isin(BG4_OUTLIER_CLONES)
        n_excluded = outlier_mask.sum()
        sub_outliers = sub[outlier_mask].copy()
        sub = sub[~outlier_mask].copy()
        print(f"\nBG4: excluding {n_excluded} outlier point(s):")
        print(sub_outliers[["clone", "edit_category", "Fold change",
                             "mean_norm_cpm"]].to_string(index=False))

    if sub.empty:
        ax.set_title(f"{assay}: no data")
        continue

    # scatter, one point per RT-qPCR sample
    for cat in cats:
        pts = sub[sub["edit_category"] == cat]
        if pts.empty:
            continue
        ax.scatter(
            pts["mean_norm_cpm"],
            pts["Fold change"],
            label=cat,
            color=colours[cat],
            s=50,
            alpha=0.8,
            edgecolors="white",
            linewidths=0.4,
            zorder=3,
        )

    # Also plot excluded outlier points (greyed out, hollow)
    if assay == "BG4" and not sub_outliers.empty:
        ax.scatter(
            sub_outliers["mean_norm_cpm"],
            sub_outliers["Fold change"],
            s=55, facecolors="none", edgecolors="grey",
            linewidths=1.2, zorder=3, label="_outlier"
        )
        for _, row in sub_outliers.iterrows():
            ax.annotate(
                row["clone"], (row["mean_norm_cpm"], row["Fold change"]),
                fontsize=5, color="grey", ha="left",
                xytext=(4, 2), textcoords="offset points"
            )

    # regression line
    x = sub["mean_norm_cpm"].values
    y = sub["Fold change"].values
    slope, intercept, r, p, se = stats.linregress(x, y)
    xline = np.linspace(x.min(), x.max(), 200)
    ax.plot(xline, slope * xline + intercept, color="black", lw=1.5, zorder=4)

    rho, p_sp = stats.spearmanr(x, y)

    outlier_note = ""
    if assay == "BG4" and BG4_OUTLIER_CLONES:
        outlier_note = f"\n(outliers excluded: {', '.join(sorted(BG4_OUTLIER_CLONES))})"
    title = (
        f"{assay}  |  n = {len(sub)}{outlier_note}\n"
        f"Pearson r = {r:.3f}  p = {p:.3g}\n"
        f"Spearman ρ = {rho:.3f}  p = {p_sp:.3g}"
    )
    ax.set_title(title, fontsize=9)
    ax.set_xlabel("Mean normalised CPM (ChIP-seq)", fontsize=9)
    ax.set_ylabel("RT-qPCR fold change (Livak)", fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

    stats_rows.append({
        "assay":         assay,
        "n":             len(sub),
        "pearson_r":     r,
        "pearson_p":     p,
        "spearman_rho":  rho,
        "spearman_p":    p_sp,
    })

# shared legend
handles = [
    plt.Line2D([0], [0], marker="o", color="w", markerfacecolor=colours[c],
               markersize=7, label=c)
    for c in cats
]
axes[-1].legend(handles=handles, title="Edit category", fontsize=7,
                title_fontsize=7, loc="upper right", framealpha=0.8)

fig.suptitle(
    "Correlation: RT-qPCR fold change (alpha-globin) vs ChIP-seq CPM\n"
    "Each point = one RT-qPCR sample; ChIP CPM averaged over bioreplicates",
    fontsize=10,
)
fig.savefig(OUT_PDF, dpi=150)
plt.close(fig)
print(f"\nSaved {OUT_PDF}")

# ── 7. Save stats ────────────────────────────────────────────────────────
stats_df = pd.DataFrame(stats_rows)
stats_df.to_csv(OUT_TSV, sep="\t", index=False)
print(f"Saved {OUT_TSV}")
print(stats_df.to_string(index=False))
