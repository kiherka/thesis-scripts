#!/usr/bin/env python3
"""
Plot mean bigwig trace (CPM) for each cell line vs WT mean,
in a 2000 bp window centred at the peak start site.

One plot per assay (BG4, CUTAC).  Each subplot shows:
  • Mean CPM trace for a single cell line (coloured by edit category)
  • Mean CPM trace across ALL WT samples (grey, dashed) as reference
  • Shaded ±SEM for both

BG4 replicate-level exclusions from analyse_cpm_v2.py are applied.
CUTAC is unchanged.

Outputs (cpm_analysis/mean_traces/):
  mean_traces_BG4.pdf
  mean_traces_CUTAC.pdf
  mean_traces_BG4_per_edit.pdf   – one page per edit category
  mean_traces_CUTAC_per_edit.pdf
"""

import re
import glob
import math
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import pyBigWig
from scipy import stats

# ── Region ────────────────────────────────────────────────────────────────────
TARGET_CHR  = "chr16"
PEAK_START  = 113670          # window is centred here
WINDOW_HALF = 1000            # ±1000 bp → 2000 bp total
WIN_START   = PEAK_START - WINDOW_HALF
WIN_END     = PEAK_START + WINDOW_HALF
BIN_SIZE    = 10              # bp per bin (200 bins across 2000 bp)

BIGWIG_DIR  = "/scratche/slow/sblab/herka01/SLX-27925/pipeline/bigwigs"
DEDUP_LOG_DIR = "/scratche/slow/sblab/herka01/SLX-27925/pipeline/logs/dedup"
OUT_DIR     = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/mean_traces"
MIN_DEDUP_READS = 1_000_000

os.makedirs(OUT_DIR, exist_ok=True)

# ── BG4 replicate exclusions (same as analyse_cpm_v2) ─────────────────────────
BG4_EXCLUDED_STEMS = {
    "BG4_KH-14-N12-1_B3", "BG4_KH-14-N12-9_B2",
    "BG4_KH-14-N13-2_B1", "BG4_KH-14-N13-3_B2", "BG4_KH-14-N13-3_B3",
    "BG4_KH-14-N13-4_B1", "BG4_KH-14-N14-2_B1", "BG4_KH-14-N14-2_B2",
    "BG4_KH-14-N14-3_B3", "BG4_KH-14-N14-6_B1", "BG4_KH-17-C-1_B1",
    "BG4_KH-17-C-2_B1",   "BG4_KH-17-N12-1_B1", "BG4_KH-WT-N13-4_B2",
    "BG4_KH-WT-N13-6_B2", "BG4_KH-WT-N15-7_B1", "BG4_KH-WT-N15-7_B3",
    "BG4_KH-WT-N15-8_B1", "BG4_KH-WT-N15-8_B3",
}

WT_CATEGORIES = {"KH-WT-C", "KH-WT-N13", "KH-WT-N15"}

# ── Sample parsing ─────────────────────────────────────────────────────────────
def parse_sample(stem):
    m = re.match(r'^(BG4|CUTAC)_(.+)_(B\d+)$', stem)
    if not m:
        return None
    assay, middle, biorep = m.group(1), m.group(2), m.group(3)
    cell_line     = f"{assay}_{middle}"
    edit_category = re.sub(r'-\d+$', '', middle)
    return dict(stem=stem, assay=assay, cell_line=cell_line,
                edit_category=edit_category, biorep=biorep)

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "*.cpm.bw")))
records = []
for path in bw_files:
    stem = os.path.basename(path).replace(".cpm.bw", "")
    info = parse_sample(stem)
    if info:
        info["path"] = path
        records.append(info)

meta_all = pd.DataFrame(records)

# ── Dedup reads filter ─────────────────────────────────────────────────────────
def parse_dedup_reads(stem):
    log_path = os.path.join(DEDUP_LOG_DIR, f"{stem}.log")
    if not os.path.exists(log_path):
        return None
    total, dups = None, None
    with open(log_path) as fh:
        for line in fh:
            m = re.search(r'Read (\d+) records\. \d+ pairs never matched', line)
            if m:
                total = int(m.group(1))
            m = re.search(r'Marking ([\d,]+) records as duplicates', line)
            if m:
                dups = int(m.group(1).replace(',', ''))
    if total is not None and dups is not None:
        return total - dups
    return None

meta_all["dedup_reads"] = meta_all["stem"].apply(parse_dedup_reads)
meta_all = meta_all[meta_all["dedup_reads"].ge(MIN_DEDUP_READS)].copy()

# ── Apply BG4 exclusions ──────────────────────────────────────────────────────
bg4_excl = (meta_all["assay"] == "BG4") & (meta_all["stem"].isin(BG4_EXCLUDED_STEMS))
meta = meta_all[~bg4_excl].copy()
print(f"{len(meta)} samples retained  ({bg4_excl.sum()} BG4 replicates excluded)")

# ── Bin positions (x axis, centred at PEAK_START) ─────────────────────────────
bins      = np.arange(WIN_START, WIN_END, BIN_SIZE)
x_rel     = bins - PEAK_START   # offset from peak start (−1000 … +990)
n_bins    = len(bins)

# ── Extract per-replicate traces ───────────────────────────────────────────────
print(f"Extracting traces in {WIN_START}–{WIN_END} ({n_bins} bins × {BIN_SIZE} bp) …")

def fetch_trace(path):
    bw = pyBigWig.open(path)
    sig = []
    for b in bins:
        try:
            v = bw.stats(TARGET_CHR, int(b), int(b + BIN_SIZE), type="mean", exact=True)[0]
        except RuntimeError:
            v = None
        sig.append(float(v) if v is not None else 0.0)
    bw.close()
    return np.array(sig)

traces = {}
for _, row in meta.iterrows():
    traces[row["stem"]] = fetch_trace(row["path"])
    print(f"  {row['stem']}")

# ── Colour palette by edit category ───────────────────────────────────────────
edit_cats = sorted(meta["edit_category"].unique())
tab20 = list(cm.tab20.colors)
cat_colors = {c: tab20[i % 20] for i, c in enumerate(edit_cats)}

# ── Helper: mean ± SEM across a set of stems ──────────────────────────────────
def mean_sem(stems):
    mat = np.stack([traces[s] for s in stems])
    m   = mat.mean(axis=0)
    s   = mat.std(axis=0, ddof=1) / np.sqrt(mat.shape[0]) if mat.shape[0] > 1 else np.zeros(n_bins)
    return m, s

# ── WT mean (all WT replicates, per assay) ────────────────────────────────────
def wt_stems(assay):
    return meta[(meta["assay"] == assay) & (meta["edit_category"].isin(WT_CATEGORIES))]["stem"].tolist()

# ── Cell lines to plot (one subplot each) ────────────────────────────────────
def cell_lines_for_assay(assay):
    return sorted(meta[meta["assay"] == assay]["cell_line"].unique())

# ── Grid layout helper ─────────────────────────────────────────────────────────
def grid_dims(n, max_cols=4):
    ncols = min(n, max_cols)
    nrows = math.ceil(n / ncols)
    return nrows, ncols

# ── Plot one cell line per subplot ─────────────────────────────────────────────
def plot_traces(assay, out_pdf, title_suffix=""):
    cls    = cell_lines_for_assay(assay)
    wt_st  = wt_stems(assay)
    wt_m, wt_s = mean_sem(wt_st) if wt_st else (np.zeros(n_bins), np.zeros(n_bins))

    nrows, ncols = grid_dims(len(cls), max_cols=4)
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=(ncols * 3.8, nrows * 3.0),
                             constrained_layout=True)
    axes_flat = np.array(axes).flatten() if len(cls) > 1 else [axes]

    for ax_idx, cl in enumerate(cls):
        ax   = axes_flat[ax_idx]
        rows = meta[(meta["assay"] == assay) & (meta["cell_line"] == cl)]
        ec   = rows["edit_category"].iloc[0]
        col  = cat_colors[ec]
        stems = rows["stem"].tolist()

        cl_m, cl_s = mean_sem(stems)

        # WT background
        if wt_st:
            ax.fill_between(x_rel, wt_m - wt_s, wt_m + wt_s,
                            color="grey", alpha=0.25, linewidth=0)
            ax.plot(x_rel, wt_m, color="grey", lw=1.0,
                    linestyle="--", label=f"WT mean (n={len(wt_st)})")

        # Cell line trace
        ax.fill_between(x_rel, cl_m - cl_s, cl_m + cl_s,
                        color=col, alpha=0.3, linewidth=0)
        ax.plot(x_rel, cl_m, color=col, lw=1.5,
                label=f"{cl} (n={len(stems)})")

        # Peak marker
        ax.axvline(0, color="red", lw=0.8, linestyle=":", alpha=0.7)

        ax.set_title(cl.replace(f"{assay}_", ""), fontsize=7)
        ax.set_xlabel("Offset from peak start (bp)", fontsize=6)
        ax.set_ylabel("CPM", fontsize=6)
        ax.tick_params(labelsize=5)
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(fontsize=5, loc="upper right", framealpha=0.6)

    for ax_idx in range(len(cls), len(axes_flat)):
        axes_flat[ax_idx].set_visible(False)

    fig.suptitle(
        f"{assay} CUT&Tag — Mean CPM trace per cell line  {title_suffix}\n"
        f"2000 bp window centred at peak start ({TARGET_CHR}:{PEAK_START:,})  |  "
        f"Shading = ±SEM  |  Dashed grey = WT mean ± SEM",
        fontsize=8,
    )
    fig.savefig(out_pdf, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out_pdf}")

# ── Plot per-edit-category (overlay all clones of that edit vs WT) ─────────────
def plot_per_edit(assay, out_pdf, title_suffix=""):
    wt_st  = wt_stems(assay)
    wt_m, wt_s = mean_sem(wt_st) if wt_st else (np.zeros(n_bins), np.zeros(n_bins))

    focal_cats = [c for c in edit_cats if c not in WT_CATEGORIES]
    nrows, ncols = grid_dims(len(focal_cats), max_cols=4)
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=(ncols * 3.8, nrows * 3.0),
                             constrained_layout=True)
    axes_flat = np.array(axes).flatten() if len(focal_cats) > 1 else [axes]

    for ax_idx, ec in enumerate(focal_cats):
        ax    = axes_flat[ax_idx]
        rows  = meta[(meta["assay"] == assay) & (meta["edit_category"] == ec)]
        if rows.empty:
            ax.text(0.5, 0.5, f"{ec}\nno data for {assay}",
                    ha="center", va="center", transform=ax.transAxes, fontsize=8)
            ax.set_visible(True)
            continue

        stems = rows["stem"].tolist()
        ec_m, ec_s = mean_sem(stems)
        col = cat_colors[ec]

        # WT
        if wt_st:
            ax.fill_between(x_rel, wt_m - wt_s, wt_m + wt_s,
                            color="grey", alpha=0.25, linewidth=0)
            ax.plot(x_rel, wt_m, color="grey", lw=1.0,
                    linestyle="--", label=f"WT mean (n={len(wt_st)})")

        # Edit mean
        ax.fill_between(x_rel, ec_m - ec_s, ec_m + ec_s,
                        color=col, alpha=0.3, linewidth=0)
        ax.plot(x_rel, ec_m, color=col, lw=1.5,
                label=f"{ec} mean (n={len(stems)})")

        ax.axvline(0, color="red", lw=0.8, linestyle=":", alpha=0.7)
        ax.set_title(ec, fontsize=7)
        ax.set_xlabel("Offset from peak start (bp)", fontsize=6)
        ax.set_ylabel("CPM", fontsize=6)
        ax.tick_params(labelsize=5)
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(fontsize=5, loc="upper right", framealpha=0.6)

    for ax_idx in range(len(focal_cats), len(axes_flat)):
        axes_flat[ax_idx].set_visible(False)

    fig.suptitle(
        f"{assay} CUT&Tag — Mean CPM trace per edit category  {title_suffix}\n"
        f"2000 bp window centred at peak start ({TARGET_CHR}:{PEAK_START:,})  |  "
        f"Dashed grey = WT mean ± SEM",
        fontsize=8,
    )
    fig.savefig(out_pdf, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out_pdf}")

# ── Generate all plots ─────────────────────────────────────────────────────────
v2_note = "[v2: BG4 excl. applied]"

for assay in ["BG4", "CUTAC"]:
    plot_traces(
        assay,
        os.path.join(OUT_DIR, f"mean_traces_{assay}.pdf"),
        title_suffix=v2_note if assay == "BG4" else "",
    )
    plot_per_edit(
        assay,
        os.path.join(OUT_DIR, f"mean_traces_{assay}_per_edit.pdf"),
        title_suffix=v2_note if assay == "BG4" else "",
    )

# ── Save trace data ────────────────────────────────────────────────────────────
rows_out = []
for stem, tr in traces.items():
    row = meta[meta["stem"] == stem].iloc[0]
    r = {"stem": stem, "assay": row["assay"],
         "cell_line": row["cell_line"], "edit_category": row["edit_category"],
         "biorep": row["biorep"]}
    for i, v in enumerate(tr):
        r[f"bin_{bins[i]}"] = v
    rows_out.append(r)
pd.DataFrame(rows_out).to_csv(
    os.path.join(OUT_DIR, "mean_traces_data.tsv"), sep="\t", index=False
)
print(f"Saved mean_traces_data.tsv")
print("Done.")
