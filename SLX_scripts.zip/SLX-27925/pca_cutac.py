#!/usr/bin/env python3
"""
PCA analysis of CUTAC samples from SLX-27925 bigwig tracks.

Steps:
  1. Run deeptools multiBigwigSummary (via SLURM) to compute genome-wide
     bin scores across all CUTAC bigwigs.
  2. Load the resulting npz/tab file and run sklearn PCA.
  3. Plot PC1 vs PC2 (and PC2 vs PC3) coloured by edit_category and biorep.

Outputs (cpm_analysis/pca/):
  multiBigwigSummary.npz
  multiBigwigSummary_scores.tab
  pca_CUTAC_PC1vsPC2.pdf
  pca_CUTAC_PC2vsPC3.pdf
  pca_CUTAC_variance.pdf
  pca_CUTAC_scores.tsv
"""

import os
import re
import subprocess
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# ── Paths ─────────────────────────────────────────────────────────────────────
BW_DIR   = "/scratche/slow/sblab/herka01/SLX-27925/pipeline/bigwigs"
OUT_DIR  = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/pca"
NPZ      = os.path.join(OUT_DIR, "multiBigwigSummary.npz")
TAB      = os.path.join(OUT_DIR, "multiBigwigSummary_scores.tab")
CONDA_ENV = "/scratche/slow/sblab/herka01/conda_envs/cf18bbe11cb40f88914862f16121f4d3_"  # deeptools env

os.makedirs(OUT_DIR, exist_ok=True)

# ── Collect CUTAC bigwigs ─────────────────────────────────────────────────────
bw_files = sorted(f for f in os.listdir(BW_DIR) if f.startswith("CUTAC_") and f.endswith(".cpm.bw"))
bw_paths = [os.path.join(BW_DIR, f) for f in bw_files]
sample_names = [f.replace(".cpm.bw", "") for f in bw_files]
print(f"Found {len(bw_files)} CUTAC bigwig files")

# ── Parse sample metadata from name ──────────────────────────────────────────
# Format: CUTAC_{KH-EDIT-CLONE}_{BIOREP}
meta = []
for s in sample_names:
    m = re.match(r"CUTAC_(KH-(\w+-\w+)-\d+)_(\w+)", s)
    if m:
        clone        = m.group(1)
        edit_cat     = "KH-" + m.group(2)
        biorep       = m.group(3)
    else:
        clone = edit_cat = biorep = "unknown"
    meta.append({"sample": s, "clone": clone, "edit_category": edit_cat, "biorep": biorep})
meta_df = pd.DataFrame(meta)

# ── Step 1: multiBigwigSummary (SLURM) ────────────────────────────────────────
if not os.path.exists(TAB):
    print("Running multiBigwigSummary via SLURM...")
    bw_list    = " \\\n    ".join(bw_paths)
    label_list = " ".join(sample_names)

    script = f"""#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=04:00:00
#SBATCH --job-name=mBWsummary
#SBATCH --output={OUT_DIR}/slurm_mBWsummary.out

export PATH="{CONDA_ENV}/bin:$PATH"

multiBigwigSummary bins \\
    -b {bw_list} \\
    --labels {label_list} \\
    -out {NPZ} \\
    --outRawCounts {TAB} \\
    -p 16 \\
    --binSize 1000
"""
    script_path = os.path.join(OUT_DIR, "run_mBWsummary.sh")
    with open(script_path, "w") as fh:
        fh.write(script)

    result = subprocess.run(["sbatch", script_path], capture_output=True, text=True)
    print(result.stdout.strip())
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    print(f"Re-run this script once the job completes to generate PCA plots.")
    sys.exit(0)

# ── Step 2: Load scores matrix ────────────────────────────────────────────────
print(f"Loading {TAB} ...")
raw = pd.read_csv(TAB, sep="\t", comment="#")
# Columns: chr, start, end, sample1, sample2, ...
score_cols = [c for c in raw.columns if c in sample_names]
mat = raw[score_cols].values.T  # shape: (n_samples, n_bins)

# Drop bins with any NaN across samples
valid = ~np.isnan(mat).any(axis=0)
mat = mat[:, valid]
print(f"Matrix: {mat.shape[0]} samples × {mat.shape[1]} valid bins")

# ── Step 3: PCA ───────────────────────────────────────────────────────────────
scaler = StandardScaler()
mat_scaled = scaler.fit_transform(mat)

n_pcs = min(10, mat.shape[0])
pca = PCA(n_components=n_pcs)
coords = pca.fit_transform(mat_scaled)
var_exp = pca.explained_variance_ratio_ * 100

print("Variance explained:")
for i, v in enumerate(var_exp):
    print(f"  PC{i+1}: {v:.1f}%")

# Save scores
scores_df = meta_df.copy()
for i in range(n_pcs):
    scores_df[f"PC{i+1}"] = coords[:, i]
scores_df.to_csv(os.path.join(OUT_DIR, "pca_CUTAC_scores.tsv"), sep="\t", index=False)

# ── Step 4: Plot ──────────────────────────────────────────────────────────────
edit_cats = sorted(scores_df["edit_category"].unique())
palette   = dict(zip(edit_cats, cm.tab10.colors[:len(edit_cats)]))
bioreps   = sorted(scores_df["biorep"].unique())
markers   = dict(zip(bioreps, ["o", "s", "^", "D", "v", "P", "X"][:len(bioreps)]))

def scatter_pca(ax, pcx, pcy, df, palette, markers, annotate=True):
    for _, row in df.iterrows():
        ax.scatter(
            row[pcx], row[pcy],
            color=palette.get(row["edit_category"], "grey"),
            marker=markers.get(row["biorep"], "o"),
            s=60, alpha=0.85, edgecolors="white", linewidths=0.4, zorder=3
        )
        if annotate:
            ax.annotate(row["clone"], (row[pcx], row[pcy]),
                        fontsize=3.5, color="dimgray",
                        xytext=(3, 2), textcoords="offset points")
    ax.set_xlabel(f"{pcx} ({var_exp[int(pcx[2:])-1]:.1f}%)", fontsize=8)
    ax.set_ylabel(f"{pcy} ({var_exp[int(pcy[2:])-1]:.1f}%)", fontsize=8)
    ax.tick_params(labelsize=7)
    ax.spines[["top", "right"]].set_visible(False)

# Legend patches
from matplotlib.lines import Line2D
cat_handles = [Line2D([0],[0], marker="o", color="w", markerfacecolor=palette[c],
                       markersize=7, label=c) for c in edit_cats]
rep_handles = [Line2D([0],[0], marker=markers[r], color="grey",
                       markersize=7, label=r) for r in bioreps]

# PC1 vs PC2
fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
scatter_pca(ax, "PC1", "PC2", scores_df, palette, markers)
ax.set_title("CUTAC CUT&Tag — PCA  PC1 vs PC2", fontsize=10)
leg1 = ax.legend(handles=cat_handles, title="Edit category", fontsize=6,
                 title_fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 1))
ax.add_artist(leg1)
ax.legend(handles=rep_handles, title="Biorep", fontsize=6,
          title_fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 0.45))
out1 = os.path.join(OUT_DIR, "pca_CUTAC_PC1vsPC2.pdf")
fig.savefig(out1, dpi=150, bbox_inches="tight")
plt.close(fig)
print(f"Saved {out1}")

# PC2 vs PC3
if n_pcs >= 3:
    fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
    scatter_pca(ax, "PC2", "PC3", scores_df, palette, markers)
    ax.set_title("CUTAC CUT&Tag — PCA  PC2 vs PC3", fontsize=10)
    leg1 = ax.legend(handles=cat_handles, title="Edit category", fontsize=6,
                     title_fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 1))
    ax.add_artist(leg1)
    ax.legend(handles=rep_handles, title="Biorep", fontsize=6,
              title_fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 0.45))
    out2 = os.path.join(OUT_DIR, "pca_CUTAC_PC2vsPC3.pdf")
    fig.savefig(out2, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out2}")

# Scree plot
fig, ax = plt.subplots(figsize=(5, 3.5), constrained_layout=True)
ax.bar(range(1, n_pcs + 1), var_exp, color="steelblue", alpha=0.8)
ax.set_xlabel("Principal Component", fontsize=9)
ax.set_ylabel("Variance explained (%)", fontsize=9)
ax.set_title("CUTAC CUT&Tag — Scree plot", fontsize=10)
ax.tick_params(labelsize=8)
ax.spines[["top", "right"]].set_visible(False)
out3 = os.path.join(OUT_DIR, "pca_CUTAC_variance.pdf")
fig.savefig(out3, dpi=150, bbox_inches="tight")
plt.close(fig)
print(f"Saved {out3}")

print("Done.")
