#!/usr/bin/env python3
"""
Per-edit correlation plots: RT-qPCR fold change vs ChIP-seq CPM.

For each "focal" edit category, produces one scatter + regression panel
showing:
  - The focal edit's data points (coloured, labelled)
  - WT reference categories (KH-WT-C, KH-WT-N13, KH-WT-N15) — always visible
  - KH-17-C — always visible as a second reference

One PDF per assay (BG4, CUTAC), each with one subplot per focal edit.
BG4 uses the v2 replicate exclusions (same as correlate_rtqpcr_v2.py).

Outputs → cpm_analysis/excluded_samples_analysis/separate_edits/
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

# ── Paths ─────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis"
DDCT_CSV     = os.path.join(ANALYSIS_DIR, "ddct_results_livak.csv")
MAPPING_XLSX = os.path.join(ANALYSIS_DIR, "Sample_mapping.xlsx")
CPM_TSV      = os.path.join(ANALYSIS_DIR, "per_sample_cpm.tsv")
OUT_DIR      = os.path.join(ANALYSIS_DIR, "excluded_samples_analysis", "separate_edits")
os.makedirs(OUT_DIR, exist_ok=True)

MIN_DEDUP_READS = 1_000_000

# ── BG4 replicate exclusions (same as v2) ─────────────────────────────────────
BG4_EXCLUDED_STEMS = {
    "BG4_KH-14-N12-1_B3", "BG4_KH-14-N12-9_B2",
    "BG4_KH-14-N13-2_B1", "BG4_KH-14-N13-3_B2", "BG4_KH-14-N13-3_B3",
    "BG4_KH-14-N13-4_B1", "BG4_KH-14-N14-2_B1", "BG4_KH-14-N14-2_B2",
    "BG4_KH-14-N14-3_B3", "BG4_KH-14-N14-6_B1", "BG4_KH-17-C-1_B1",
    "BG4_KH-17-C-2_B1",   "BG4_KH-17-N12-1_B1", "BG4_KH-WT-N13-4_B2",
    "BG4_KH-WT-N13-6_B2", "BG4_KH-WT-N15-7_B1", "BG4_KH-WT-N15-7_B3",
    "BG4_KH-WT-N15-8_B1", "BG4_KH-WT-N15-8_B3",
}

# ── Always-visible reference categories ───────────────────────────────────────
REFERENCE_CATS = {"KH-WT-C", "KH-WT-N13", "KH-WT-N15", "KH-17-C"}

# ── 1. Build sample-number → clone-name mapping ───────────────────────────────
xf    = pd.ExcelFile(MAPPING_XLSX)
names = pd.read_excel(xf, sheet_name="Sample", header=None)
nums  = pd.read_excel(xf, sheet_name="Number", header=None)

num2clone = {}
for r in range(names.shape[0]):
    for c in range(names.shape[1]):
        nm = names.iloc[r, c]; nu = nums.iloc[r, c]
        if pd.notna(nm) and pd.notna(nu):
            num2clone[int(nu)] = str(nm).strip()

# ── 2. Load RT-qPCR ───────────────────────────────────────────────────────────
ddct = pd.read_csv(DDCT_CSV)
ddct["clone"] = ddct["Sample"].map(num2clone)
ddct = ddct.dropna(subset=["clone"])

group2cat = {
    "14_control": "KH-14-C",  "17_control": "KH-17-C",
    "WT_control": "KH-WT-C",  "WT_N15":     "KH-WT-N15",
    "14_N14":     "KH-14-N14","14_N12":     "KH-14-N12",
    "17_N12":     "KH-17-N12","14_N13":     "KH-14-N13",
    "17_N13":     "KH-17-N13","WT_N13":     "KH-WT-N13",
}
ddct["edit_category"] = ddct["Group"].map(group2cat)

# ── 3. Load ChIP-seq CPM, apply filters ──────────────────────────────────────
cpm_all = pd.read_csv(CPM_TSV, sep="\t")
cpm_all = cpm_all[cpm_all["dedup_reads"] >= MIN_DEDUP_READS].copy()

bg4_excl = (cpm_all["assay"] == "BG4") & (cpm_all["stem"].isin(BG4_EXCLUDED_STEMS))
cpm = cpm_all[~bg4_excl].copy()
cpm["clone"] = cpm["cell_line"].str.replace(r"^(BG4|CUTAC)_", "", regex=True)

mean_cpm = (
    cpm.groupby(["assay", "clone"])
    .agg(mean_norm_cpm=("norm_cpm", "mean"), n_reps=("norm_cpm", "count"))
    .reset_index()
)

# ── 4. Merge ──────────────────────────────────────────────────────────────────
merged = ddct.merge(mean_cpm, on="clone", how="inner")

# ── 5. Colour scheme ──────────────────────────────────────────────────────────
# Reference categories: muted palette; focal edit: tab10 colour per category
REF_COLOURS = {
    "KH-WT-C":   "#aec7e8",  # light blue
    "KH-WT-N13": "#9edae5",  # light teal
    "KH-WT-N15": "#c5b0d5",  # light purple
    "KH-17-C":   "#ffbb78",  # light orange
}
FOCAL_COLOURS = {
    "KH-14-C":   "#d62728",
    "KH-14-N12": "#1f77b4",
    "KH-14-N13": "#2ca02c",
    "KH-14-N14": "#ff7f0e",
    "KH-17-N12": "#8c564b",
}

# ── 6. Determine focal categories per assay ───────────────────────────────────
# Focal = all categories that are not pure references
def get_focal_cats(assay_data):
    all_cats = sorted(assay_data["edit_category"].unique())
    return [c for c in all_cats if c not in REFERENCE_CATS]

# ── 7. Plot function ──────────────────────────────────────────────────────────
def plot_per_edit(assay):
    sub_all = merged[merged["assay"] == assay].copy()
    focal_cats = get_focal_cats(sub_all)
    n_focal = len(focal_cats)

    ncols = 3
    nrows = int(np.ceil(n_focal / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=(5.5 * ncols, 4.8 * nrows),
                             constrained_layout=True)
    axes_flat = np.array(axes).flatten()

    all_stats = []

    for idx, focal in enumerate(focal_cats):
        ax = axes_flat[idx]

        # Data for this panel: focal edit + reference categories
        panel_cats = {focal} | REFERENCE_CATS
        sub = sub_all[sub_all["edit_category"].isin(panel_cats)].copy()

        # Plot reference points first (background layer)
        for ref_cat in sorted(REFERENCE_CATS):
            pts = sub[sub["edit_category"] == ref_cat]
            if pts.empty:
                continue
            ax.scatter(
                pts["mean_norm_cpm"], pts["Fold change"],
                color=REF_COLOURS.get(ref_cat, "lightgrey"),
                s=45, alpha=0.75, edgecolors="white", linewidths=0.4,
                zorder=2, label=ref_cat,
            )

        # Plot focal edit points (foreground)
        focal_pts = sub[sub["edit_category"] == focal]
        focal_col = FOCAL_COLOURS.get(focal, "#333333")
        ax.scatter(
            focal_pts["mean_norm_cpm"], focal_pts["Fold change"],
            color=focal_col, s=65, alpha=0.9,
            edgecolors="white", linewidths=0.5,
            zorder=3, label=focal,
        )

        # Label individual focal points with clone name
        for _, row in focal_pts.iterrows():
            ax.annotate(
                row["clone"],
                (row["mean_norm_cpm"], row["Fold change"]),
                fontsize=4, color="black", ha="left",
                xytext=(3, 2), textcoords="offset points",
            )

        # Regression on focal + references combined
        x = sub["mean_norm_cpm"].values
        y = sub["Fold change"].values
        if len(x) >= 3:
            slope, intercept, r, p, _ = stats.linregress(x, y)
            rho, p_sp = stats.spearmanr(x, y)
            xline = np.linspace(x.min(), x.max(), 200)
            ax.plot(xline, slope * xline + intercept,
                    color="black", lw=1.2, zorder=4)
            stat_label = (f"Pearson r={r:.2f} p={p:.2g}\n"
                          f"Spearman ρ={rho:.2f} p={p_sp:.2g}")
            all_stats.append(dict(
                assay=assay, focal_edit=focal,
                n_focal=len(focal_pts), n_total=len(sub),
                pearson_r=r, pearson_p=p, spearman_rho=rho, spearman_p=p_sp,
            ))
        else:
            stat_label = "n < 3"

        ax.set_title(f"{focal}  (n={len(focal_pts)})\n{stat_label}", fontsize=8)
        ax.set_xlabel("Mean norm. CPM (ChIP-seq)", fontsize=8)
        ax.set_ylabel("RT-qPCR fold change", fontsize=8)
        ax.spines[["top", "right"]].set_visible(False)

        # Legend: focal first, then references
        handles, labels = [], []
        handles.append(plt.Line2D([0],[0], marker="o", color="w",
                                  markerfacecolor=focal_col, markersize=7,
                                  label=focal))
        labels.append(focal)
        for ref_cat in sorted(REFERENCE_CATS):
            handles.append(plt.Line2D([0],[0], marker="o", color="w",
                                      markerfacecolor=REF_COLOURS.get(ref_cat, "grey"),
                                      markersize=6, label=ref_cat))
            labels.append(ref_cat)
        ax.legend(handles=handles, labels=labels, fontsize=5.5,
                  loc="upper left", framealpha=0.7)

    # Hide unused panels
    for idx in range(n_focal, len(axes_flat)):
        axes_flat[idx].set_visible(False)

    fig.suptitle(
        f"{assay}: Correlation per focal edit  "
        f"(WT and KH-17-C shown on every panel)\n"
        f"Regression fitted to focal edit + reference points combined",
        fontsize=11,
    )

    out = os.path.join(OUT_DIR, f"07_per_edit_correlation_{assay}.pdf")
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"Saved {out}")
    return all_stats

# ── 8. Run and save stats ─────────────────────────────────────────────────────
stats_rows = []
for assay in ["BG4", "CUTAC"]:
    stats_rows.extend(plot_per_edit(assay))

stats_df = pd.DataFrame(stats_rows)
out_stats = os.path.join(OUT_DIR, "07_per_edit_correlation_stats.tsv")
stats_df.to_csv(out_stats, sep="\t", index=False)
print(f"\nSaved {out_stats}")
print(stats_df.to_string(index=False))
