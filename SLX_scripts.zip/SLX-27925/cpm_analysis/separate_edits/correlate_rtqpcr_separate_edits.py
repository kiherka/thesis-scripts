#!/usr/bin/env python3
"""
Correlate RT-qPCR fold changes (alpha-globin expression) with ChIP-seq CPM,
plotting one subplot per focal edit category.

Each subplot shows:
  • The focal edit category (coloured, labelled)
  • KH-WT-C  } always shown as reference background (grey tones)
  • KH-17-C  }
  • Regression line fit to focal + reference points combined

BG4 replicate-level exclusions from correlate_rtqpcr_v2.py are applied.
CUTAC is unchanged.

Inputs (all in cpm_analysis/ or excluded_samples_analysis/):
  rtqpcr_correlation_v2_data.tsv  – pre-merged RT-qPCR × ChIP-seq table

Outputs (cpm_analysis/separate_edits/):
  07_separate_edits_BG4.pdf
  07_separate_edits_CUTAC.pdf
  separate_edits_stats.tsv        – per-assay × per-focal-edit stats
"""

import os
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

# ── Paths ─────────────────────────────────────────────────────────────────────
ESA_DIR  = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/excluded_samples_analysis"
OUT_DIR  = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/separate_edits"
DATA_TSV = os.path.join(ESA_DIR, "rtqpcr_correlation_v2_data.tsv")

os.makedirs(OUT_DIR, exist_ok=True)

# ── Reference categories always shown on every subplot ────────────────────────
REFERENCE_CATS = {"KH-WT-C", "KH-17-C"}

# ── Load data ─────────────────────────────────────────────────────────────────
df = pd.read_csv(DATA_TSV, sep="\t")
all_cats    = sorted(df["edit_category"].unique())
focal_cats  = [c for c in all_cats if c not in REFERENCE_CATS]

print(f"Focal edit categories ({len(focal_cats)}): {focal_cats}")
print(f"Reference categories (always shown):      {sorted(REFERENCE_CATS)}")

# ── Colour map ────────────────────────────────────────────────────────────────
# Focal categories: tab10; reference: fixed grey tones
import matplotlib.cm as cm
focal_colors = dict(zip(focal_cats, cm.tab10.colors[:len(focal_cats)]))
ref_colors   = {"KH-WT-C": "#888888", "KH-17-C": "#bbbbbb"}
all_colors   = {**focal_colors, **ref_colors}

# ── Grid layout helper ────────────────────────────────────────────────────────
def grid_dims(n, max_cols=4):
    ncols = min(n, max_cols)
    nrows = math.ceil(n / ncols)
    return nrows, ncols

# ── Stats accumulator ─────────────────────────────────────────────────────────
stats_rows = []

# ── One PDF per assay ─────────────────────────────────────────────────────────
for assay in ["BG4", "CUTAC"]:
    sub_all = df[df["assay"] == assay].copy()

    ref_pts  = sub_all[sub_all["edit_category"].isin(REFERENCE_CATS)]
    n_focal  = len(focal_cats)
    nrows, ncols = grid_dims(n_focal, max_cols=4)

    fig, axes = plt.subplots(
        nrows, ncols,
        figsize=(ncols * 3.8, nrows * 3.5),
        constrained_layout=True,
    )
    axes_flat = np.array(axes).flatten() if n_focal > 1 else [axes]

    for ax_idx, focal_cat in enumerate(focal_cats):
        ax = axes_flat[ax_idx]

        focal_pts = sub_all[sub_all["edit_category"] == focal_cat]

        # ── Plot reference points (always shown, background) ──────────────
        for ref_cat in sorted(REFERENCE_CATS):
            rpts = ref_pts[ref_pts["edit_category"] == ref_cat]
            if rpts.empty:
                continue
            ax.scatter(
                rpts["mean_norm_cpm"], rpts["Fold change"],
                color=ref_colors[ref_cat], s=45, alpha=0.7,
                edgecolors="white", linewidths=0.4,
                zorder=2, label=ref_cat,
            )

        # ── Plot focal points ─────────────────────────────────────────────
        ax.scatter(
            focal_pts["mean_norm_cpm"], focal_pts["Fold change"],
            color=focal_colors[focal_cat], s=55, alpha=0.9,
            edgecolors="white", linewidths=0.5,
            zorder=3, label=focal_cat,
        )

        # ── Regression on focal + reference combined ──────────────────────
        combined = pd.concat([focal_pts, ref_pts])
        x = combined["mean_norm_cpm"].values
        y = combined["Fold change"].values

        if len(x) >= 3:
            slope, intercept, r, p, _ = stats.linregress(x, y)
            rho, p_sp = stats.spearmanr(x, y)
            xline = np.linspace(x.min(), x.max(), 200)
            ax.plot(xline, slope * xline + intercept,
                    color="black", lw=1.2, zorder=4)
            stats_rows.append({
                "assay": assay, "focal_category": focal_cat,
                "n_focal": len(focal_pts), "n_total": len(combined),
                "pearson_r": r, "pearson_p": p,
                "spearman_rho": rho, "spearman_p": p_sp,
            })
        else:
            r, p, rho, p_sp = np.nan, np.nan, np.nan, np.nan

        # ── Annotate clone names on focal points ──────────────────────────
        for _, row in focal_pts.iterrows():
            ax.annotate(
                row["clone"],
                (row["mean_norm_cpm"], row["Fold change"]),
                fontsize=4, color="dimgray",
                xytext=(3, 2), textcoords="offset points",
            )

        # ── Axes formatting ───────────────────────────────────────────────
        p_str  = f"{p:.2g}"   if not np.isnan(p)   else "n/a"
        psp_str = f"{p_sp:.2g}" if not np.isnan(p_sp) else "n/a"
        ax.set_title(
            f"{focal_cat}  (n={len(focal_pts)}+{len(ref_pts)} ref)\n"
            f"Pearson r={r:.2f} p={p_str}  |  Spearman ρ={rho:.2f} p={psp_str}",
            fontsize=7,
        )
        ax.set_xlabel("Mean norm. CPM (ChIP-seq)", fontsize=7)
        ax.set_ylabel("RT-qPCR fold change", fontsize=7)
        ax.tick_params(labelsize=6)
        ax.spines[["top", "right"]].set_visible(False)

        # Per-subplot legend (small)
        ax.legend(fontsize=5, loc="upper right", framealpha=0.7,
                  markerscale=0.8)

    # Hide unused axes
    for ax_idx in range(n_focal, len(axes_flat)):
        axes_flat[ax_idx].set_visible(False)

    fig.suptitle(
        f"{assay}: RT-qPCR fold change vs ChIP-seq CPM — one panel per edit\n"
        f"Each panel: focal edit (coloured) + KH-WT-C + KH-17-C (grey, reference)\n"
        f"Regression fit to focal + reference combined",
        fontsize=9,
    )

    out = os.path.join(OUT_DIR, f"07_separate_edits_{assay}.pdf")
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out}")

# ── Save stats ────────────────────────────────────────────────────────────────
stats_df = pd.DataFrame(stats_rows)
out_stats = os.path.join(OUT_DIR, "separate_edits_stats.tsv")
stats_df.to_csv(out_stats, sep="\t", index=False, float_format="%.4f")
print(f"Saved {out_stats}")
print(stats_df.to_string(index=False))
