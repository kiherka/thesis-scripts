#!/usr/bin/env python3
"""
plot_wt_cpm.py – Normalised CPM for BG4 and CUTAC across WT-C, WT-N15,
14-C, and 17-C conditions.

Outputs (in OUT_DIR):
  01_combined_BG4.pdf        – all BG4 conditions together (stripplot)
  02_combined_CUTAC.pdf      – all CUTAC conditions together (stripplot)
  03_per_cellline_BG4.pdf    – per-cell-line bars + dots, BG4
  04_per_cellline_CUTAC.pdf  – per-cell-line bars + dots, CUTAC
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
from scipy import stats

# ── Font: Helvetica Neue Light (falls back to Nimbus Sans / DejaVu Sans) ──────
rcParams.update({
    "font.family":      "sans-serif",
    "font.sans-serif":  ["Helvetica Neue", "Helvetica", "Nimbus Sans",
                         "Arial", "DejaVu Sans"],
    "font.weight":      "light",
    "font.size":        8,
    "axes.titlesize":   9,
    "axes.labelsize":   8,
    "xtick.labelsize":  7,
    "ytick.labelsize":  7,
    "legend.fontsize":  7,
    "pdf.fonttype":     42,   # embed TrueType in PDF
    "ps.fonttype":      42,
    "axes.linewidth":   0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
})

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE       = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis"
PER_SAMPLE = os.path.join(BASE, "per_sample_cpm.tsv")
OUT_DIR    = os.path.join(BASE, "wt_cpm_plots")
os.makedirs(OUT_DIR, exist_ok=True)

# ── BG4 replicate exclusions (from analyse_cpm_v2.py) ─────────────────────────
BG4_EXCLUDED = {
    "BG4_KH-14-N12-1_B3", "BG4_KH-14-N12-9_B2",
    "BG4_KH-14-N13-2_B1", "BG4_KH-14-N13-3_B2", "BG4_KH-14-N13-3_B3",
    "BG4_KH-14-N13-4_B1", "BG4_KH-14-N14-2_B1", "BG4_KH-14-N14-2_B2",
    "BG4_KH-14-N14-3_B3", "BG4_KH-14-N14-6_B1", "BG4_KH-17-C-1_B1",
    "BG4_KH-17-C-2_B1",   "BG4_KH-17-N12-1_B1", "BG4_KH-WT-N13-4_B2",
    "BG4_KH-WT-N13-6_B2", "BG4_KH-WT-N15-7_B1", "BG4_KH-WT-N15-7_B3",
    "BG4_KH-WT-N15-8_B1", "BG4_KH-WT-N15-8_B3",
}

# ── Colour scheme ──────────────────────────────────────────────────────────────
#  WT-C   → black
#  14-C   → light red
#  17-C   → dark red
#  WT-N15 → purple

COND_COLORS = {
    "WT-C":   "#000000",
    "14-C":   "#FF6B6B",
    "17-C":   "#B71C1C",
    "WT-N15": "#7B2FBE",
}

COND_LABELS = {
    "KH-WT-C":   "WT-C",
    "KH-14-C":   "14-C",
    "KH-17-C":   "17-C",
    "KH-WT-N15": "WT-N15",
}

COND_ORDER = ["WT-C", "14-C", "17-C", "WT-N15"]

# ── Load & filter data ─────────────────────────────────────────────────────────
df = pd.read_csv(PER_SAMPLE, sep="\t")
df = df[
    df["edit_category"].isin(COND_LABELS.keys()) &
    df["assay"].isin(["BG4", "CUTAC"])
].copy()
df = df[~df["stem"].isin(BG4_EXCLUDED)].copy()
df["condition"] = df["edit_category"].map(COND_LABELS)

print(f"Samples retained: {len(df)}")
print(df.groupby(["assay", "condition"]).size().to_string())

# ── Helper: significance bracket ──────────────────────────────────────────────
def annotate_pval(ax, x1, x2, y, p, gap=0.012):
    label = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else "ns"
    y_top = y + gap
    ax.plot([x1, x1, x2, x2], [y, y_top, y_top, y], lw=0.8, color="black")
    ax.text((x1 + x2) / 2, y_top + 0.003, label,
            ha="center", va="bottom", fontsize=7)

# ── 1 & 2. Combined bar charts: one panel per assay ───────────────────────────
for assay in ["BG4", "CUTAC"]:
    sub = df[df["assay"] == assay].copy()
    conds_present = [c for c in COND_ORDER if c in sub["condition"].values]
    n = len(conds_present)

    fig, ax = plt.subplots(figsize=(1.4 * n + 1.2, 4.2))

    means, sems = [], []
    for cond in conds_present:
        vals = sub[sub["condition"] == cond]["norm_cpm"].dropna().values
        means.append(vals.mean())
        sems.append(vals.std(ddof=1) / np.sqrt(len(vals)) if len(vals) > 1 else 0)

    bar_colors = [COND_COLORS[c] for c in conds_present]
    ax.bar(range(n), means, yerr=sems, color=bar_colors, alpha=0.7,
           width=0.6, capsize=3, error_kw=dict(linewidth=0.9, ecolor="black"),
           zorder=2)

    # Overlay individual dots
    for i, cond in enumerate(conds_present):
        vals = sub[sub["condition"] == cond]["norm_cpm"].dropna().values
        jx   = np.random.default_rng(i).normal(i, 0.07, size=len(vals))
        ax.scatter(jx, vals, color="black", s=16, alpha=0.65,
                   zorder=3, edgecolors="none")

    # Y-axis: scale to max(mean + sem) of bars, with headroom for brackets
    n_comparisons = len(conds_present) - 1 if "WT-C" in conds_present else 0
    data_top = max(m + s for m, s in zip(means, sems))
    bracket_headroom = data_top * 0.22 * max(n_comparisons, 1)
    ylim_top = data_top + bracket_headroom
    ax.set_ylim(0, ylim_top)

    # Pairwise Mann-Whitney vs WT-C
    if "WT-C" in conds_present:
        wt_vals   = sub[sub["condition"] == "WT-C"]["norm_cpm"].dropna().values
        wt_idx    = conds_present.index("WT-C")
        bracket_y = data_top * 1.08
        for i, cond in enumerate(conds_present):
            if cond == "WT-C":
                continue
            other = sub[sub["condition"] == cond]["norm_cpm"].dropna().values
            if len(wt_vals) >= 2 and len(other) >= 2:
                _, p = stats.mannwhitneyu(wt_vals, other, alternative="two-sided")
                annotate_pval(ax, wt_idx, i, bracket_y, p, gap=data_top * 0.06)
                bracket_y += data_top * 0.18

    ax.set_xticks(range(n))
    ax.set_xticklabels(conds_present)
    ax.set_ylabel("Normalised CPM (target / reference)")
    ax.set_title(assay, fontweight="light")
    ax.spines[["top", "right"]].set_visible(False)

    idx = 1 if assay == "BG4" else 2
    out = os.path.join(OUT_DIR, f"0{idx}_combined_{assay}.pdf")
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out}")

# ── 3 & 4. Per-cell-line bar + dot plots ──────────────────────────────────────
for assay in ["BG4", "CUTAC"]:
    sub = df[df["assay"] == assay].copy()

    # Sort: WT-C | 14-C | 17-C | WT-N15, then numerically within each condition
    sub["_cond_rank"] = sub["condition"].map(
        {c: i for i, c in enumerate(COND_ORDER)}
    )
    sub["_clone_num"] = sub["cell_line"].str.extract(r'-(\d+)$').astype(int)
    cell_order = (
        sub.drop_duplicates("cell_line")
        .sort_values(["_cond_rank", "_clone_num"])["cell_line"]
        .tolist()
    )

    stats_df = (
        sub.groupby("cell_line")["norm_cpm"]
        .agg(mean="mean", sem=lambda x: x.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else 0)
        .reindex(cell_order)
    )
    cell_cond = (
        sub.drop_duplicates("cell_line")
        .set_index("cell_line")["condition"]
        .reindex(cell_order)
    )

    n = len(cell_order)
    fig, ax = plt.subplots(figsize=(max(7, n * 0.6 + 1.5), 4.5))

    bar_colors = [COND_COLORS[cell_cond[cl]] for cl in cell_order]
    ax.bar(range(n), stats_df["mean"], yerr=stats_df["sem"],
           color=bar_colors, alpha=0.65, width=0.65, capsize=3,
           error_kw=dict(linewidth=0.9, ecolor="black"), zorder=2)

    for i, cl in enumerate(cell_order):
        vals = sub[sub["cell_line"] == cl]["norm_cpm"].dropna().values
        jx   = np.random.default_rng(i).normal(i, 0.07, size=len(vals))
        ax.scatter(jx, vals, color="black", s=14, zorder=3,
                   alpha=0.7, edgecolors="none")

    # Vertical separators between conditions
    prev_cond = cell_cond[cell_order[0]]
    for i in range(1, n):
        cur = cell_cond[cell_order[i]]
        if cur != prev_cond:
            ax.axvline(i - 0.5, color="#BBBBBB", lw=0.7, linestyle="--", zorder=1)
        prev_cond = cur

    ax.set_xticks(range(n))
    ax.set_xticklabels(
        [cl.replace(f"{assay}_KH-", "") for cl in cell_order],
        rotation=50, ha="right"
    )
    ax.set_ylabel("Normalised CPM (target / reference)")
    ax.set_title(f"{assay} – normalised CPM per cell line", fontweight="light")
    ax.spines[["top", "right"]].set_visible(False)

    handles = [
        plt.Rectangle((0, 0), 1, 1, color=COND_COLORS[c], alpha=0.65, label=c)
        for c in COND_ORDER if c in cell_cond.values
    ]
    ax.legend(handles=handles, framealpha=0.6, edgecolor="none")

    idx = 3 if assay == "BG4" else 4
    out = os.path.join(OUT_DIR, f"0{idx}_per_cellline_{assay}.pdf")
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {out}")

print(f"\nAll plots written to: {OUT_DIR}")
