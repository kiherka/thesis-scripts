#!/usr/bin/env python3
"""
Correlate RT-qPCR fold changes (alpha-globin expression) with
BG4 / CUTAC normalised CPM at the target locus.

Version 2: replicate-level BG4 exclusions.
Specific BG4 replicates (stems) are excluded before averaging per clone.
Clones whose every replicate is excluded are dropped from the correlation.
CUTAC analysis is unchanged.

Inputs (all in cpm_analysis/):
  ddct_results_livak.csv  – RT-qPCR fold changes per sample
  Sample_mapping.xlsx     – 'Sample' sheet: clone names grid
                            'Number' sheet: sample numbers at same positions
  per_sample_cpm.tsv      – ChIP-seq norm_cpm per biological replicate

Outputs (cpm_analysis/):
  06_rtqpcr_correlation_v2.pdf        – scatter + regression for BG4 and CUTAC
  rtqpcr_correlation_v2_stats.tsv     – Pearson / Spearman stats per assay
  rtqpcr_correlation_v2_data.tsv      – merged per-sample table used for plotting
  excluded_bg4_replicates.tsv         – table of excluded BG4 replicates
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

# ── Paths ─────────────────────────────────────────────────────────────────────
ANALYSIS_DIR      = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis"
EXCL_DIR          = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/excluded_samples_analysis"
DDCT_CSV          = os.path.join(EXCL_DIR, "ddct_results_livak_unfiltered.csv")
MAPPING_XLSX      = os.path.join(ANALYSIS_DIR, "Sample_mapping.xlsx")
CPM_TSV           = os.path.join(ANALYSIS_DIR, "per_sample_cpm.tsv")
OUT_PDF           = os.path.join(EXCL_DIR, "06_rtqpcr_correlation_v2_unfiltered.pdf")
OUT_STATS_TSV     = os.path.join(EXCL_DIR, "rtqpcr_correlation_v2_unfiltered_stats.tsv")
OUT_MERGED_TSV    = os.path.join(EXCL_DIR, "rtqpcr_correlation_v2_unfiltered_data.tsv")
OUT_EXCLUDED_TSV  = os.path.join(EXCL_DIR, "excluded_bg4_replicates_unfiltered.tsv")

MIN_DEDUP_READS = 1_000_000

# ── BG4 replicate-level exclusions ────────────────────────────────────────────
# Specific stems excluded from BG4 CPM averaging before correlation.
# Reason: low-quality / outlier replicates identified by visual QC.
BG4_EXCLUDED_STEMS = {
    # stem                        reason
    "BG4_KH-14-N12-1_B3":   "low dedup reads (2.6M) + elevated CPM vs other reps",
    "BG4_KH-14-N12-9_B2":   "CPM outlier vs B1/B3",
    "BG4_KH-14-N13-2_B1":   "extreme CPM outlier (1.68 vs 0.037 for B3)",
    "BG4_KH-14-N13-3_B2":   "low dedup reads (1.1M) + elevated CPM",
    "BG4_KH-14-N13-3_B3":   "excluded by QC",
    "BG4_KH-14-N13-4_B1":   "zero CPM with low dedup reads (1.1M)",
    "BG4_KH-14-N14-2_B1":   "low dedup reads (1.3M) + low CPM outlier",
    "BG4_KH-14-N14-2_B2":   "CPM outlier (0.47 vs 0.057 for B3)",
    "BG4_KH-14-N14-3_B3":   "excluded by QC",
    "BG4_KH-14-N14-6_B1":   "zero CPM; only replicate — clone fully dropped",
    "BG4_KH-17-C-1_B1":     "CPM outlier (0.49); only replicate — clone fully dropped",
    "BG4_KH-17-C-2_B1":     "zero CPM with low dedup reads (2.6M)",
    "BG4_KH-17-N12-1_B1":   "zero CPM with low dedup reads (1.5M)",
    "BG4_KH-WT-N13-4_B2":   "anomalously high dedup reads (55M) + CPM outlier",
    "BG4_KH-WT-N13-6_B2":   "excluded by QC",
    "BG4_KH-WT-N15-7_B1":   "low dedup reads (9.1M) + elevated CPM vs B2/B3",
    "BG4_KH-WT-N15-7_B3":   "zero CPM with low dedup reads (1.3M)",
    "BG4_KH-WT-N15-8_B1":   "low dedup reads (1.4M)",
    "BG4_KH-WT-N15-8_B3":   "excluded by QC",
}

# ── 1. Build sample-number → clone-name mapping ───────────────────────────────
xf    = pd.ExcelFile(MAPPING_XLSX)
names = pd.read_excel(xf, sheet_name="Sample", header=None)
nums  = pd.read_excel(xf, sheet_name="Number", header=None)

num2clone = {}
for r in range(names.shape[0]):
    for c in range(names.shape[1]):
        name = names.iloc[r, c]
        num  = nums.iloc[r, c]
        if pd.notna(name) and pd.notna(num):
            num2clone[int(num)] = str(name).strip()

# ── 2. Load RT-qPCR data ─────────────────────────────────────────────────────
ddct = pd.read_csv(DDCT_CSV)
ddct["clone"] = ddct["Sample"].map(num2clone)
ddct = ddct.dropna(subset=["clone"])

group2cat = {
    "14_control": "KH-14-C",  "17_control": "KH-17-C",
    "WT_control": "KH-WT-C",  "WT_N15":     "KH-WT-N15",
    "14_N14":     "KH-14-N14","14_N12":     "KH-14-N12",
    "17_N12":     "KH-17-N12","14_N13":     "KH-14-N13",
    "17_N13":     "KH-17-N13","WT_N13":     "KH-WT-N13",
}
ddct["edit_category"] = ddct["Group"].map(group2cat)

# ── 3. Load ChIP-seq CPM ──────────────────────────────────────────────────────
cpm_all = pd.read_csv(CPM_TSV, sep="\t")

# Step A: apply ≥1M dedup-reads filter (same as v1)
cpm_pass = cpm_all[cpm_all["dedup_reads"] >= MIN_DEDUP_READS].copy()
print(f"{len(cpm_pass)} of {len(cpm_all)} ChIP-seq replicates pass ≥{MIN_DEDUP_READS:,} filter.")

# Step B: for BG4, further exclude the specific stems
bg4_excluded_mask = (
    (cpm_pass["assay"] == "BG4") &
    (cpm_pass["stem"].isin(BG4_EXCLUDED_STEMS))
)
cpm_bg4_excluded = cpm_pass[bg4_excluded_mask].copy()
cpm_bg4_excluded["reason"] = cpm_bg4_excluded["stem"].map(BG4_EXCLUDED_STEMS)

cpm = cpm_pass[~bg4_excluded_mask].copy()

# Save excluded table
excl_table = cpm_bg4_excluded[
    ["stem", "assay", "cell_line", "biorep", "dedup_reads", "norm_cpm", "reason"]
].sort_values("stem")
excl_table.to_csv(OUT_EXCLUDED_TSV, sep="\t", index=False)
print(f"\nExcluded {len(cpm_bg4_excluded)} BG4 replicates (saved → {OUT_EXCLUDED_TSV}):")
print(excl_table[["stem", "norm_cpm", "dedup_reads", "reason"]].to_string(index=False))

# Step C: verify all listed stems were actually found
not_found = set(BG4_EXCLUDED_STEMS) - set(cpm_pass[cpm_pass["assay"]=="BG4"]["stem"])
if not_found:
    print(f"\nWARNING: these stems were listed for exclusion but not found: {not_found}")

# ── 4. Average over replicates ────────────────────────────────────────────────
cpm["clone"] = cpm["cell_line"].str.replace(r"^(BG4|CUTAC)_", "", regex=True)

mean_cpm = (
    cpm.groupby(["assay", "clone"])
    .agg(mean_norm_cpm=("norm_cpm", "mean"), n_reps=("norm_cpm", "count"))
    .reset_index()
)

# Identify BG4 clones where all reps were excluded
all_bg4_clones = set(
    cpm_pass[cpm_pass["assay"]=="BG4"]["cell_line"]
    .str.replace(r"^BG4_", "", regex=True)
)
retained_bg4_clones = set(mean_cpm[mean_cpm["assay"]=="BG4"]["clone"])
fully_dropped = all_bg4_clones - retained_bg4_clones
if fully_dropped:
    print(f"\nBG4 clones fully dropped (all replicates excluded): {sorted(fully_dropped)}")

# ── 5. Merge with RT-qPCR ─────────────────────────────────────────────────────
merged = ddct.merge(mean_cpm, on="clone", how="inner")
merged.to_csv(OUT_MERGED_TSV, sep="\t", index=False)
print(f"\nMerged data: {len(merged)} rows "
      f"({merged[merged['assay']=='BG4'].shape[0]} BG4, "
      f"{merged[merged['assay']=='CUTAC'].shape[0]} CUTAC)")

# ── 7. Plot ───────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), constrained_layout=True)
stats_rows = []

for ax, assay in zip(axes, ["BG4", "CUTAC"]):
    sub = merged[merged["assay"] == assay].copy()

    if sub.empty:
        ax.set_title(f"{assay}: no data")
        continue

    ax.scatter(
        sub["mean_norm_cpm"], sub["Fold change"],
        color="tab:blue",
        s=50, alpha=0.8, edgecolors="white", linewidths=0.4, zorder=3,
    )

    x = sub["mean_norm_cpm"].values
    y = sub["Fold change"].values
    slope, intercept, r, p, _ = stats.linregress(x, y)
    xline = np.linspace(x.min(), x.max(), 200)
    ax.plot(xline, slope * xline + intercept, color="black", lw=1.5, zorder=4)
    rho, p_sp = stats.spearmanr(x, y)

    excl_note = ""
    if assay == "BG4":
        excl_note = f"\n({len(BG4_EXCLUDED_STEMS)} replicates excluded; " \
                    f"{len(fully_dropped)} clone(s) fully dropped)"
    ax.set_title(
        f"{assay}  |  n = {len(sub)}{excl_note}\n"
        f"Pearson r = {r:.3f}  p = {p:.3g}\n"
        f"Spearman ρ = {rho:.3f}  p = {p_sp:.3g}",
        fontsize=8,
    )
    ax.set_xlabel("Mean normalised CPM (ChIP-seq)", fontsize=9)
    ax.set_ylabel("RT-qPCR fold change (Livak)", fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

    stats_rows.append({
        "assay": assay, "n": len(sub),
        "pearson_r": r, "pearson_p": p,
        "spearman_rho": rho, "spearman_p": p_sp,
    })

fig.suptitle(
    "Correlation: RT-qPCR fold change (alpha-globin) vs ChIP-seq CPM  [v2]\n"
    "Each point = one RT-qPCR sample; ChIP CPM averaged over QC-passing replicates",
    fontsize=9,
)
fig.savefig(OUT_PDF, dpi=150)
plt.close(fig)
print(f"\nSaved {OUT_PDF}")

# ── 8. Save stats ─────────────────────────────────────────────────────────────
stats_df = pd.DataFrame(stats_rows)
stats_df.to_csv(OUT_STATS_TSV, sep="\t", index=False)
print(f"Saved {OUT_STATS_TSV}")
print(stats_df.to_string(index=False))
