#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=03:00:00
#SBATCH --job-name=fix_gzip
#SBATCH --output=/scratche/slow/sblab/herka01/SLX-27925/fix_gzip_%j.log
#SBATCH --error=/scratche/slow/sblab/herka01/SLX-27925/fix_gzip_%j.log

set -e
cd /scratche/slow/sblab/herka01/SLX-27925

SAMPLE=CUTAC_KH-14-N13-4_B1

for file in \
  "demultiplexed_lane1/${SAMPLE}_r1.fq.gz" \
  "demultiplexed_lane2/${SAMPLE}_r1.fq.gz" \
  "demultiplexed_lane2/${SAMPLE}_r2.fq.gz"
do
  echo "[$(date)] Fixing: $file"
  zcat "$file" 2>/dev/null | gzip > "${file}.fixed"
  mv "${file}.fixed" "$file"
  echo "[$(date)] Done: $file"
done

echo "[$(date)] All done."
