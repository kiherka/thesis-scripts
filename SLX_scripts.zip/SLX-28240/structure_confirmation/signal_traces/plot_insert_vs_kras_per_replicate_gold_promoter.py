#!/usr/bin/env python3
"""
Same per-replicate insert-vs-KRAS analysis as plot_insert_vs_kras_per_replicate.py
(all 4 assays: BG4, CM, CUTAC, 27ac), but restricted to the UNION of:
  1. The 120 curated gold-standard BG4 junctions
     (SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv).
  2. Every OTHER insert junction annotated "Promoter" in
     SLX-27649/insert_peak_analysis/location_analysis_new/all_inserts_annotations.tsv
     (resolved to region_start/region_end/junction_id/orientation via that
     well's SPLINK_{well}.insert_regions.bed in insert_peak_analysis/bed_regions/,
     matched on chrom:clip_pos == junction_loc).

For each junction in this union and each assay, one page (2 subplots side by
side): insert region (2525 bp zoom window) + KRAS reference region, every
replicate plotted as its own line, plus a black dashed "Others mean" line
pooling every replicate from every OTHER well in this junction set.

Outputs (this folder):
  promoter_region_inserts.tsv                        - full list of every
    Promoter-annotated insert (126), resolved coordinates + gold-standard flag
  BG4_insert_vs_kras_per_replicate_gold_promoter.pdf
  CM_insert_vs_kras_per_replicate_gold_promoter.pdf
  CUTAC_insert_vs_kras_per_replicate_gold_promoter.pdf
  27ac_insert_vs_kras_per_replicate_gold_promoter.pdf
  insert_vs_kras_all_values_gold_promoter.tsv         - every individual
    (query_well, replicate) value, not just aggregated means
"""

import csv
import os
import re
from collections import defaultdict

import numpy as np
import pyBigWig
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# ── Paths ──────────────────────────────────────────────────────────────────────
GOLD_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
ANNOTATIONS_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/location_analysis_new/all_inserts_annotations.tsv"
INSERT_REGIONS_BED_DIR = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/bed_regions"
JUNCTIONS_BED_DIR = "/scratche/slow/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"
SLX28240_DIR = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"

MIN_MAPPED_READS = 1_000_000
ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]

OLD_FLANK = 1000    # flank already baked into region_start/region_end
ZOOM_FLANK = 1000   # new flank for the 2525 bp insert window
NUM_BINS = 200

KRAS_CHROM = "chr12"
KRAS_START = 25250600
KRAS_END = 25251600
KRAS_FLANK = 1000

REP_COLORS = {
    "SLX26997:B1": "#2166ac",
    "SLX27843:B1": "#238b45",
    "SLX28240:BR1": "#cb181d",
    "SLX28240:BR2": "#e6a817",
    "SLX28240:BR3": "#6a3d9a",
}


def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def collect_replicates(well_norm, assay):
    reps = []

    if assay == "BG4":
        raw = _raw_26997_by_norm.get(well_norm)
        if raw:
            reps.append({
                "label": "SLX26997:B1",
                "sample": f"BG4_{raw}_B1",
                "bw_dir": os.path.join(SLX26997_DIR, "bigwigs"),
                "base_dir": SLX26997_DIR,
            })

    if assay in ("BG4", "CUTAC"):
        sample = f"{assay}_{well_norm}_B1"
        stats_dir = os.path.join(SLX27843_DIR, "stats")
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": "SLX27843:B1",
                "sample": sample,
                "bw_dir": os.path.join(SLX27843_DIR, "bigwigs"),
                "base_dir": SLX27843_DIR,
            })

    stats_dir = os.path.join(SLX28240_DIR, "stats")
    for n in (1, 2, 3):
        sample = f"{assay}_{well_norm}_BR{n}"
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": f"SLX28240:BR{n}",
                "sample": sample,
                "bw_dir": os.path.join(SLX28240_DIR, "bigwigs"),
                "base_dir": SLX28240_DIR,
            })

    passing = []
    for r in reps:
        n = get_dedup_reads(r["base_dir"], r["sample"])
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(r["bw_dir"], f"{r['sample']}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                r["bw_path"] = bw_path
                passing.append(r)
    return passing


def get_kras_shift(well):
    path = os.path.join(JUNCTIONS_BED_DIR, f"SPLINK_{well}.junctions.bed")
    if not os.path.exists(path):
        return 0
    shift = 0
    with open(path) as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            chrom, start, consensus_len = parts[0], int(parts[1]), int(parts[6])
            if chrom == KRAS_CHROM and start < KRAS_START:
                shift += consensus_len
    return shift


_bw_cache = {}


def get_bw(bw_path):
    bw = _bw_cache.get(bw_path)
    if bw is None:
        bw = pyBigWig.open(bw_path)
        _bw_cache[bw_path] = bw
    return bw


def extract_signal(bw, chrom, start, end, num_bins):
    chroms = bw.chroms()
    if chrom not in chroms:
        return None
    chrom_len = chroms[chrom]
    s, e = max(0, start), min(end, chrom_len)
    if e <= s:
        return None
    vals = bw.stats(chrom, s, e, nBins=num_bins, type="mean")
    return np.array([v if v is not None else 0.0 for v in vals])


def style_axis(ax, title, xlabel, ylabel, region_len):
    ax.axvspan(0, region_len, color="grey", alpha=0.1)
    ax.set_title(title, fontsize=9)
    ax.set_xlabel(xlabel, fontsize=8)
    ax.set_ylabel(ylabel, fontsize=8)
    ax.tick_params(labelsize=7)
    ax.spines[["top", "right"]].set_visible(False)


def resolve_insert_region(well, chrom, clip_pos):
    """Look up region_start/region_end/junction_id/orientation/read_support
    for an arbitrary (well, chrom, clip_pos) insert from that well's full
    insert_regions.bed (not just the gold-standard subset)."""
    path = os.path.join(INSERT_REGIONS_BED_DIR, f"SPLINK_{well}.insert_regions.bed")
    if not os.path.exists(path):
        return None
    target_loc = f"{chrom}:{clip_pos}"
    with open(path) as fh:
        for line in fh:
            parts = line.rstrip("\n").split("\t")
            region_chrom, region_start, region_end, name = parts[0], int(parts[1]), int(parts[2]), parts[3]
            name_parts = name.split("|")
            junction_id = name_parts[0]
            junction_loc = name_parts[1] if len(name_parts) > 1 else ""
            read_support = name_parts[2] if len(name_parts) > 2 else ""
            orientation = name_parts[3] if len(name_parts) > 3 else ""
            if junction_loc == target_loc:
                return {
                    "chrom": region_chrom, "region_start": region_start, "region_end": region_end,
                    "junction_id": junction_id, "orientation": orientation, "read_support": read_support,
                }
    return None


def load_junction_union():
    """Build the union of the 120 gold-standard junctions + every promoter-
    annotated insert, deduplicated on (well, junction_id). Also returns the
    full promoter-insert reference list (resolved coordinates + gold-standard
    flag) for promoter_region_inserts.tsv."""
    gold_keys = set()
    junctions = {}   # key -> dict

    with open(GOLD_TSV) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            key = (row["cell_line"], row["junction_id"])
            gold_keys.add(key)
            junctions[key] = {
                "well": row["cell_line"], "junction_id": row["junction_id"], "chrom": row["chrom"],
                "region_start": int(row["region_start"]), "region_end": int(row["region_end"]),
                "orientation": row["orientation"], "gold_standard": True, "promoter": False,
            }

    promoter_ref_rows = []
    with open(ANNOTATIONS_TSV) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            if row["annotation"] != "Promoter":
                continue
            well = row["cell_line"]
            resolved = resolve_insert_region(well, row["chrom"], row["clip_pos"])
            if resolved is None:
                promoter_ref_rows.append({
                    "well": well, "chrom": row["chrom"], "clip_pos": row["clip_pos"],
                    "junction_id": "", "region_start": "", "region_end": "", "orientation": "",
                    "read_support": "", "gold_standard": False, "resolved": False,
                })
                continue
            key = (well, resolved["junction_id"])
            is_gold = key in gold_keys
            promoter_ref_rows.append({
                "well": well, "chrom": resolved["chrom"], "clip_pos": row["clip_pos"],
                "junction_id": resolved["junction_id"], "region_start": resolved["region_start"],
                "region_end": resolved["region_end"], "orientation": resolved["orientation"],
                "read_support": resolved["read_support"], "gold_standard": is_gold, "resolved": True,
            })
            if key not in junctions:
                junctions[key] = {
                    "well": well, "junction_id": resolved["junction_id"], "chrom": resolved["chrom"],
                    "region_start": resolved["region_start"], "region_end": resolved["region_end"],
                    "orientation": resolved["orientation"], "gold_standard": False, "promoter": True,
                }
            else:
                junctions[key]["promoter"] = True

    return list(junctions.values()), promoter_ref_rows


def main():
    junction_rows, promoter_ref_rows = load_junction_union()
    print(f"Gold-standard + promoter junction union: {len(junction_rows)} junctions")
    print(f"Promoter-annotated inserts: {len(promoter_ref_rows)} "
          f"({sum(1 for r in promoter_ref_rows if r['gold_standard'])} also gold-standard)")

    promoter_tsv = os.path.join(OUT_DIR, "promoter_region_inserts.tsv")
    header = ["well", "chrom", "clip_pos", "junction_id", "region_start", "region_end",
              "orientation", "read_support", "gold_standard", "resolved"]
    with open(promoter_tsv, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for r in promoter_ref_rows:
            fo.write("\t".join(str(r[h]) for h in header) + "\n")
    print(f"Saved: {promoter_tsv}")

    junction_specs = []
    for row in junction_rows:
        insert_start = row["region_start"] + OLD_FLANK
        insert_end = row["region_end"] - OLD_FLANK
        junction_specs.append({
            "well": row["well"], "junction_id": row["junction_id"], "chrom": row["chrom"],
            "orientation": row["orientation"],
            "insert_start": insert_start, "insert_end": insert_end,
            "i_start": insert_start - ZOOM_FLANK, "i_end": insert_end + ZOOM_FLANK,
            "key": (row["well"], row["junction_id"]),
            "group": ("gold-standard" if row["gold_standard"] else "") +
                     (", promoter" if row["promoter"] else ""),
        })
    all_wells = sorted({j["well"] for j in junction_specs})
    print(f"Unique wells: {len(all_wells)}")

    shift_cache = {w: get_kras_shift(w) for w in all_wells}

    all_value_rows = []

    for assay in ASSAYS:
        reps_by_well = {w: collect_replicates(w, assay) for w in all_wells}

        kras_trace_by_well = {}
        for w in all_wells:
            reps = reps_by_well[w]
            if not reps:
                kras_trace_by_well[w] = []
                continue
            shift = shift_cache[w]
            k_start = KRAS_START + shift - KRAS_FLANK
            k_end = KRAS_END + shift + KRAS_FLANK
            kras_trace_by_well[w] = [extract_signal(get_bw(rep["bw_path"]), KRAS_CHROM, k_start, k_end, NUM_BINS)
                                      for rep in reps]

        per_rep_traces = defaultdict(dict)
        for w in all_wells:
            reps = reps_by_well[w]
            if not reps:
                continue
            bws = [get_bw(rep["bw_path"]) for rep in reps]
            for j in junction_specs:
                per_rep_traces[j["key"]][w] = [extract_signal(bw, j["chrom"], j["i_start"], j["i_end"], NUM_BINS)
                                                for bw in bws]

        others_mean_by_key = {}
        for j in junction_specs:
            key = j["key"]
            owner_well = j["well"]
            well_traces = per_rep_traces.get(key, {})
            other_traces_for_mean = []
            for w, traces in well_traces.items():
                reps = reps_by_well[w]
                kras_traces = kras_trace_by_well.get(w, [])
                is_self = (w == owner_well)
                for i, sig in enumerate(traces):
                    insert_mean_cpm = float(np.mean(sig)) if sig is not None else None
                    kras_sig = kras_traces[i] if i < len(kras_traces) else None
                    kras_mean_cpm = float(np.mean(kras_sig)) if kras_sig is not None else None
                    all_value_rows.append({
                        "assay": assay, "well": owner_well, "junction_id": j["junction_id"],
                        "chrom": j["chrom"], "insert_start": j["insert_start"], "insert_end": j["insert_end"],
                        "query_well": w, "is_self": is_self, "replicate_label": reps[i]["label"],
                        "insert_mean_cpm": insert_mean_cpm, "kras_shift_bp": shift_cache[w],
                        "kras_mean_cpm": kras_mean_cpm,
                    })
                    if not is_self and sig is not None:
                        other_traces_for_mean.append(sig[::-1] if j["orientation"] == "reverse" else sig)
            if other_traces_for_mean:
                n_other_wells = len({w for w in well_traces if w != owner_well})
                others_mean_by_key[key] = (np.mean(other_traces_for_mean, axis=0),
                                            len(other_traces_for_mean), n_other_wells)
            else:
                others_mean_by_key[key] = None

        out_pdf = os.path.join(OUT_DIR, f"{assay}_insert_vs_kras_per_replicate_gold_promoter.pdf")
        n_no_reps = 0
        with PdfPages(out_pdf) as pdf:
            for j in junction_specs:
                well, junction_id, chrom = j["well"], j["junction_id"], j["chrom"]
                orientation = j["orientation"]
                insert_start, insert_end = j["insert_start"], j["insert_end"]

                reps = reps_by_well[well]
                shift = shift_cache[well]

                fig, axes = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)

                if not reps:
                    for ax in axes:
                        ax.text(0.5, 0.5, f"No {assay} bigwig\n(failed QC or missing)",
                                 ha="center", va="center", transform=ax.transAxes,
                                 fontsize=9, color="grey")
                    fig.suptitle(f"{well}  {junction_id}  |  {assay}  ({j['group']})",
                                 fontsize=10, fontweight="bold")
                    pdf.savefig(fig)
                    plt.close(fig)
                    n_no_reps += 1
                    continue

                x_insert = np.linspace(-ZOOM_FLANK, (insert_end - insert_start) + ZOOM_FLANK, NUM_BINS)
                x_kras = np.linspace(-KRAS_FLANK, (KRAS_END - KRAS_START) + KRAS_FLANK, NUM_BINS)

                ax_insert, ax_kras = axes
                owner_traces = per_rep_traces.get(j["key"], {}).get(well, [])
                kras_traces = kras_trace_by_well.get(well, [])
                for i, rep in enumerate(reps):
                    color = REP_COLORS.get(rep["label"], "#333333")

                    insert_sig = owner_traces[i] if i < len(owner_traces) else None
                    if insert_sig is not None:
                        disp = insert_sig[::-1] if orientation == "reverse" else insert_sig
                        ax_insert.plot(x_insert, disp, color=color, linewidth=1.2, label=rep["label"])

                    kras_sig = kras_traces[i] if i < len(kras_traces) else None
                    if kras_sig is not None:
                        ax_kras.plot(x_kras, kras_sig, color=color, linewidth=1.2, label=rep["label"])

                om = others_mean_by_key.get(j["key"])
                if om is not None:
                    others_trace, n_other_reps, n_other_wells = om
                    ax_insert.plot(x_insert, others_trace, color="black", linestyle="--", linewidth=1.5,
                                   label=f"Others mean (n={n_other_wells} wells, {n_other_reps} reps)")

                style_axis(ax_insert, f"Insert region\n{chrom}:{insert_start:,}-{insert_end:,}",
                           "Position relative to insert (bp)", f"{assay} CPM",
                           insert_end - insert_start)
                ax_insert.legend(loc="upper right", fontsize=6)

                shift_note = f" (+{shift} bp shift)" if shift else ""
                style_axis(ax_kras, f"KRAS reference region{shift_note}\n"
                           f"{KRAS_CHROM}:{KRAS_START + shift:,}-{KRAS_END + shift:,}",
                           "Position relative to KRAS region (bp)", f"{assay} CPM",
                           KRAS_END - KRAS_START)
                ax_kras.legend(loc="upper right", fontsize=6)

                fig.suptitle(f"{well}  {junction_id}  |  {assay}  (n={len(reps)} replicates)  ({j['group']})",
                             fontsize=10, fontweight="bold")
                pdf.savefig(fig)
                plt.close(fig)

        print(f"{assay}: {len(junction_specs) - n_no_reps}/{len(junction_specs)} junctions with >=1 replicate. "
              f"Saved: {out_pdf}")

    all_values_tsv = os.path.join(OUT_DIR, "insert_vs_kras_all_values_gold_promoter.tsv")
    header = ["assay", "well", "junction_id", "chrom", "insert_start", "insert_end",
              "query_well", "is_self", "replicate_label", "insert_mean_cpm", "kras_shift_bp",
              "kras_mean_cpm"]
    with open(all_values_tsv, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for r in all_value_rows:
            fo.write("\t".join(str(r[h]) for h in header) + "\n")
    print(f"Saved: {all_values_tsv}  ({len(all_value_rows)} rows)")

    for bw in _bw_cache.values():
        bw.close()

    print("\nDONE.")


if __name__ == "__main__":
    main()
