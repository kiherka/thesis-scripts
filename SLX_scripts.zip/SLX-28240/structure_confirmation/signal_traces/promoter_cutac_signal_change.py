#!/usr/bin/env python3
"""
For every insert in the gold-standard + promoter junction union (same 240
junctions as plot_insert_vs_kras_per_replicate_gold_promoter.py), find every
gene whose TSS falls within 100 kb either side of the insert, and quantify
the change in CUTAC signal at each of those promoters: the insert-owning
well's own CUTAC signal at that promoter vs. the mean CUTAC signal at the
same promoter pooled from every OTHER well in the same junction set
("Others mean", same background convention used throughout signal_traces/).

Promoter region = TSS +/- 1kb (same convention as
SLX-27649/.../scripts/junction_gencode_annotation_optimized.py), but TSS here
is strand-aware (gene start for '+', gene end for '-'), unlike that script.

Per-well genome coordinate shift: each well is aligned to its own integrated
genome with its own insert(s) spliced in, so any locus downstream of one of
THIS well's own insert breakpoints is shifted relative to plain hg38 -
generalises get_kras_shift() from the sibling scripts to an arbitrary locus.

Output (this folder): promoter_cutac_signal_change.tsv - one row per
(insert, nearby gene) pair; first columns identify the promoter (this is
also literally "the list of gene promoters within 100kb of the insert"),
remaining columns quantify the CUTAC signal change.
"""

import os
import re
import bisect
from collections import defaultdict

import numpy as np

from plot_insert_vs_kras_per_replicate_gold_promoter import (
    load_junction_union, collect_replicates, get_bw, _bw_cache,
)

GTF_PATH = "/scratche/slow/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/reference/gencode.v44.annotation.gtf"
JUNCTIONS_BED_DIR = "/scratche/slow/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_TSV = os.path.join(OUT_DIR, "promoter_cutac_signal_change.tsv")

PROMOTER_WINDOW = 100_000   # search radius either side of the insert
PROMOTER_FLANK = 1_000      # TSS +/- 1kb promoter region for signal extraction
PSEUDOCOUNT = 0.01


def log(msg):
    from datetime import datetime
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def parse_genes(gtf_path):
    genes_by_chrom = defaultdict(list)  # chrom -> [(tss, gene_id, gene_name, strand), ...]
    gene_id_re = re.compile(r'gene_id "([^"]+)"')
    gene_name_re = re.compile(r'gene_name "([^"]+)"')
    n = 0
    with open(gtf_path) as f:
        for line in f:
            if line[0] == "#":
                continue
            fields = line.rstrip("\n").split("\t")
            if fields[2] != "gene":
                continue
            chrom, start, end, strand, attrs = fields[0], int(fields[3]), int(fields[4]), fields[6], fields[8]
            tss = start if strand == "+" else end
            gid_m = gene_id_re.search(attrs)
            gname_m = gene_name_re.search(attrs)
            gene_id = gid_m.group(1) if gid_m else ""
            gene_name = gname_m.group(1) if gname_m else gene_id
            genes_by_chrom[chrom].append((tss, gene_id, gene_name, strand))
            n += 1
            if n % 20000 == 0:
                log(f"  parsed {n} genes so far...")
    for chrom in genes_by_chrom:
        genes_by_chrom[chrom].sort(key=lambda g: g[0])
    log(f"Parsed {n} genes across {len(genes_by_chrom)} chroms")
    return genes_by_chrom


def find_nearby_genes(genes_by_chrom, chrom, pos, window):
    genes = genes_by_chrom.get(chrom)
    if not genes:
        return []
    tss_list = [g[0] for g in genes]
    lo = bisect.bisect_left(tss_list, pos - window)
    hi = bisect.bisect_right(tss_list, pos + window)
    return genes[lo:hi]


_well_junctions_cache = {}


def load_well_junctions(well):
    cached = _well_junctions_cache.get(well)
    if cached is not None:
        return cached
    path = os.path.join(JUNCTIONS_BED_DIR, f"SPLINK_{well}.junctions.bed")
    entries = []
    if os.path.exists(path):
        with open(path) as fh:
            for line in fh:
                if line.startswith("#"):
                    continue
                parts = line.rstrip("\n").split("\t")
                entries.append((parts[0], int(parts[1]), int(parts[6])))
    _well_junctions_cache[well] = entries
    return entries


def get_locus_shift(well, chrom, pos):
    shift = 0
    for j_chrom, j_start, consensus_len in load_well_junctions(well):
        if j_chrom == chrom and j_start < pos:
            shift += consensus_len
    return shift


def mean_cpm(bw, chrom, start, end):
    chroms = bw.chroms()
    if chrom not in chroms:
        return None
    s, e = max(0, start), min(end, chroms[chrom])
    if e <= s:
        return None
    val = bw.stats(chrom, s, e, type="mean")[0]
    return float(val) if val is not None else 0.0


_promoter_signal_cache = {}  # (well, gene_id) -> list of per-replicate mean CPM


def get_promoter_signal(well, gene_id, chrom, promoter_start, promoter_end, reps_by_well):
    key = (well, gene_id)
    cached = _promoter_signal_cache.get(key)
    if cached is not None:
        return cached
    reps = reps_by_well.get(well, [])
    values = []
    if reps:
        shift = get_locus_shift(well, chrom, promoter_start)
        p_start, p_end = promoter_start + shift, promoter_end + shift
        for rep in reps:
            v = mean_cpm(get_bw(rep["bw_path"]), chrom, p_start, p_end)
            if v is not None:
                values.append(v)
    _promoter_signal_cache[key] = values
    return values


def main():
    log("Loading gold-standard + promoter junction union...")
    junction_rows, _ = load_junction_union()
    log(f"Union: {len(junction_rows)} junctions")

    all_wells = sorted({j["well"] for j in junction_rows})
    log(f"Unique wells: {len(all_wells)}")

    log("Collecting CUTAC replicates for all wells...")
    reps_by_well = {}
    for i, w in enumerate(all_wells, 1):
        reps_by_well[w] = collect_replicates(w, "CUTAC")
        if i % 25 == 0:
            log(f"  {i}/{len(all_wells)} wells checked")
    n_with_cutac = sum(1 for w in all_wells if reps_by_well[w])
    log(f"Wells with >=1 passing CUTAC replicate: {n_with_cutac}/{len(all_wells)}")

    log(f"Parsing genes from {GTF_PATH} ...")
    genes_by_chrom = parse_genes(GTF_PATH)

    rows = []
    for i, j in enumerate(junction_rows, 1):
        well, chrom = j["well"], j["chrom"]
        insert_mid = (j["region_start"] + j["region_end"]) // 2
        group = ("gold-standard" if j["gold_standard"] else "") + (", promoter" if j["promoter"] else "")

        nearby = find_nearby_genes(genes_by_chrom, chrom, insert_mid, PROMOTER_WINDOW)
        for tss, gene_id, gene_name, strand in nearby:
            promoter_start, promoter_end = tss - PROMOTER_FLANK, tss + PROMOTER_FLANK

            self_vals = get_promoter_signal(well, gene_id, chrom, promoter_start, promoter_end, reps_by_well)

            other_vals = []
            n_other_wells = 0
            for w in all_wells:
                if w == well or not reps_by_well.get(w):
                    continue
                vals = get_promoter_signal(w, gene_id, chrom, promoter_start, promoter_end, reps_by_well)
                if vals:
                    other_vals.extend(vals)
                    n_other_wells += 1

            self_mean = float(np.mean(self_vals)) if self_vals else None
            others_mean = float(np.mean(other_vals)) if other_vals else None
            if self_mean is not None and others_mean is not None:
                log2fc = float(np.log2((self_mean + PSEUDOCOUNT) / (others_mean + PSEUDOCOUNT)))
                delta = self_mean - others_mean
            else:
                log2fc = None
                delta = None

            rows.append({
                "well": well, "junction_id": j["junction_id"], "chrom": chrom,
                "insert_mid": insert_mid, "group": group,
                "gene_id": gene_id, "gene_name": gene_name, "strand": strand,
                "tss_pos": tss, "distance_bp": tss - insert_mid,
                "promoter_start": promoter_start, "promoter_end": promoter_end,
                "cutac_insert_well_mean_cpm": self_mean, "cutac_others_mean_cpm": others_mean,
                "log2fc": log2fc, "delta_cpm": delta,
                "n_insert_reps": len(self_vals), "n_other_wells": n_other_wells, "n_other_reps": len(other_vals),
            })

        if i % 20 == 0:
            log(f"  {i}/{len(junction_rows)} junctions processed, {len(rows)} promoter rows so far")

    header = ["well", "junction_id", "chrom", "insert_mid", "group", "gene_id", "gene_name", "strand",
              "tss_pos", "distance_bp", "promoter_start", "promoter_end",
              "cutac_insert_well_mean_cpm", "cutac_others_mean_cpm", "log2fc", "delta_cpm",
              "n_insert_reps", "n_other_wells", "n_other_reps"]
    with open(OUT_TSV, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for r in rows:
            fo.write("\t".join(str(r[h]) for h in header) + "\n")
    log(f"Saved: {OUT_TSV} ({len(rows)} rows, {len(junction_rows)} inserts)")

    for bw in _bw_cache.values():
        bw.close()

    log("DONE.")


if __name__ == "__main__":
    main()
