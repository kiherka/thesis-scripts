#!/usr/bin/env python3
"""
Per-insert summary PDF (one page per junction in the same 240-junction
gold-standard + promoter union used throughout signal_traces/), combining:
  - promoter_cutac_signal_change.tsv: CUTAC log2FC at every gene promoter
    within 100kb of the insert, vs. an "Average (all nearby)" summary bar.
  - A freshly computed BG4/CUTAC log2FC AT THE INSERT SITE ITSELF (the
    edited site), using the same "Others mean" control convention (mean
    signal at the same locus pooled across every other well in the union).

Output: promoter_and_editsite_changes.pdf
"""
import os
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

from plot_insert_vs_kras_per_replicate_gold_promoter import (
    load_junction_union, collect_replicates, get_bw, _bw_cache, OLD_FLANK,
)

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
PROMOTER_TSV = os.path.join(OUT_DIR, "promoter_cutac_signal_change.tsv")
OUT_PDF = os.path.join(OUT_DIR, "promoter_and_editsite_changes.pdf")

EDIT_SITE_ASSAYS = ["BG4", "CUTAC"]
EDIT_SITE_COLORS = {"BG4": "#2166ac", "CUTAC": "#238b45"}
PSEUDOCOUNT = 0.01


def log(msg):
    from datetime import datetime
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def mean_cpm(bw, chrom, start, end):
    chroms = bw.chroms()
    if chrom not in chroms:
        return None
    s, e = max(0, start), min(end, chroms[chrom])
    if e <= s:
        return None
    val = bw.stats(chrom, s, e, type="mean")[0]
    return float(val) if val is not None else 0.0


def load_promoter_rows():
    rows_by_key = defaultdict(list)
    with open(PROMOTER_TSV) as f:
        header = f.readline().rstrip("\n").split("\t")
        for line in f:
            vals = line.rstrip("\n").split("\t")
            r = dict(zip(header, vals))
            rows_by_key[(r["well"], r["junction_id"])].append(r)
    return rows_by_key


def main():
    log("Loading gold-standard + promoter junction union...")
    junction_rows, _ = load_junction_union()
    log(f"Union: {len(junction_rows)} junctions")

    all_wells = sorted({j["well"] for j in junction_rows})
    log(f"Unique wells: {len(all_wells)}")

    promoter_rows_by_key = load_promoter_rows()

    log("Collecting BG4/CUTAC replicates for all wells...")
    reps_by_well = {assay: {w: collect_replicates(w, assay) for w in all_wells} for assay in EDIT_SITE_ASSAYS}

    n_pages = 0
    with PdfPages(OUT_PDF) as pdf:
        for i, j in enumerate(junction_rows, 1):
            well, junction_id, chrom = j["well"], j["junction_id"], j["chrom"]
            insert_start = j["region_start"] + OLD_FLANK
            insert_end = j["region_end"] - OLD_FLANK
            group = ("gold-standard" if j["gold_standard"] else "") + (", promoter" if j["promoter"] else "")

            # --- Panel 1: nearby-promoter CUTAC changes (from promoter_cutac_signal_change.tsv) ---
            prom_rows = sorted(promoter_rows_by_key.get((well, junction_id), []),
                                key=lambda r: int(r["distance_bp"]))
            gene_labels, gene_log2fc = [], []
            for r in prom_rows:
                if r["log2fc"] == "None":
                    continue
                gene_labels.append(f"{r['gene_name']}\n({int(r['distance_bp']) / 1000:+.0f}kb)")
                gene_log2fc.append(float(r["log2fc"]))
            avg_log2fc = float(np.mean(gene_log2fc)) if gene_log2fc else None

            # --- Panel 2: BG4/CUTAC change at the insert site itself ---
            edit_log2fc = {}
            for assay in EDIT_SITE_ASSAYS:
                self_vals = [v for v in (mean_cpm(get_bw(rep["bw_path"]), chrom, insert_start, insert_end)
                                          for rep in reps_by_well[assay].get(well, [])) if v is not None]
                other_vals = []
                for w in all_wells:
                    if w == well:
                        continue
                    for rep in reps_by_well[assay].get(w, []):
                        v = mean_cpm(get_bw(rep["bw_path"]), chrom, insert_start, insert_end)
                        if v is not None:
                            other_vals.append(v)
                if self_vals and other_vals:
                    self_mean, others_mean = float(np.mean(self_vals)), float(np.mean(other_vals))
                    edit_log2fc[assay] = float(np.log2((self_mean + PSEUDOCOUNT) / (others_mean + PSEUDOCOUNT)))

            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(max(8, 0.5 * len(gene_labels) + 4), 5),
                                            constrained_layout=True)

            if gene_log2fc:
                bar_labels = ["Average\n(all nearby)"] + gene_labels
                bar_vals = [avg_log2fc] + gene_log2fc
                colors = ["#d62728"] + ["#4c72b0"] * len(gene_labels)
                ax1.bar(range(len(bar_vals)), bar_vals, color=colors)
                ax1.set_xticks(range(len(bar_vals)))
                ax1.set_xticklabels(bar_labels, rotation=90, fontsize=6)
            else:
                ax1.text(0.5, 0.5, "No gene promoters\nwithin 100kb", ha="center", va="center",
                          transform=ax1.transAxes, fontsize=9, color="grey")
            ax1.axhline(0, color="black", linewidth=0.8)
            ax1.set_ylabel("CUTAC log2FC vs other wells (control)", fontsize=8)
            ax1.set_title(f"Nearby gene promoters (\u00b1100kb, n={len(gene_log2fc)})", fontsize=9)
            ax1.tick_params(labelsize=7)
            ax1.spines[["top", "right"]].set_visible(False)

            assays_present = [a for a in EDIT_SITE_ASSAYS if a in edit_log2fc]
            if assays_present:
                vals = [edit_log2fc[a] for a in assays_present]
                ax2.bar(range(len(assays_present)), vals, color=[EDIT_SITE_COLORS[a] for a in assays_present])
                ax2.set_xticks(range(len(assays_present)))
                ax2.set_xticklabels(assays_present, fontsize=8)
            else:
                ax2.text(0.5, 0.5, "No data\n(failed QC)", ha="center", va="center",
                          transform=ax2.transAxes, fontsize=9, color="grey")
            ax2.axhline(0, color="black", linewidth=0.8)
            ax2.set_ylabel("log2FC vs other wells (control)", fontsize=8)
            ax2.set_title("Edited insert site", fontsize=9)
            ax2.tick_params(labelsize=7)
            ax2.spines[["top", "right"]].set_visible(False)

            fig.suptitle(f"{well}  {junction_id}  ({chrom})  ({group})", fontsize=10, fontweight="bold")
            pdf.savefig(fig)
            plt.close(fig)
            n_pages += 1

            if i % 20 == 0:
                log(f"  {i}/{len(junction_rows)} inserts plotted")

    log(f"Saved: {OUT_PDF} ({n_pages} pages)")

    for bw in _bw_cache.values():
        bw.close()

    log("DONE.")


if __name__ == "__main__":
    main()
