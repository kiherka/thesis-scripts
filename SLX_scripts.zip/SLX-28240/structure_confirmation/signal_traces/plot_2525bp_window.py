#!/usr/bin/env python3
"""
Re-plot BG4/CM/CUTAC/27ac signal traces zoomed to the original 2525 bp
insert region (1 kb flank + 525 bp insert + 1 kb flank), reusing the
already-extracted 20525 bp signal data in signal_traces_data.npz produced by
extract_assay_signal_traces.py - no bigwig re-extraction needed.

Outputs (this folder):
  per_insert_signal_traces_2525bp.pdf   - one page per junction, all 4 assays
  all_inserts_median_signal_2525bp.pdf  - median signal per assay, across all
                                            120 junctions
"""

import csv
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
NPZ_PATH = os.path.join(OUT_DIR, "signal_traces_data.npz")
ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"

ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}

# ── Original (full) extraction window parameters, must match extract_assay_signal_traces.py ──
FLANK_SIZE  = 10000
INSERT_SIZE = 525
FULL_REGION_SIZE = FLANK_SIZE * 2 + INSERT_SIZE   # 20525
NUM_BINS = 500

# ── New, narrower window to zoom into: 2525 bp (1 kb flank + insert + 1 kb flank) ──
ZOOM_FLANK = 1000
ZOOM_REGION_SIZE = ZOOM_FLANK * 2 + INSERT_SIZE   # 2525


def main():
    data = np.load(NPZ_PATH)
    print(f"Loaded {len(data.files)} signal arrays from {NPZ_PATH}")

    # Reconstruct the full-window x-axis (bp position, 0 = start of the
    # original 20525 bp extraction) and find the indices covering the
    # narrower 2525 bp zoom window, centred the same way.
    x_full = np.linspace(0, FULL_REGION_SIZE, NUM_BINS)
    zoom_start = FLANK_SIZE - ZOOM_FLANK              # 9000
    zoom_end   = FLANK_SIZE + INSERT_SIZE + ZOOM_FLANK  # 11525
    mask = (x_full >= zoom_start) & (x_full <= zoom_end)
    x_zoom = x_full[mask] - zoom_start  # rebase to 0..2525
    print(f"Zoom window: {zoom_start}-{zoom_end} bp of the original extraction "
          f"({mask.sum()} of {NUM_BINS} bins)")

    # ── Reconstruct per-insert / per-assay signals from the npz keys ─────────
    # key format: "{well}__{junction_id}__{assay}"
    with open(ORIGINAL_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    junctions = [(r["cell_line"], r["junction_id"]) for r in rows]

    per_insert_data = []
    per_assay_signals = {assay: [] for assay in ASSAYS}
    for well, junction_id in junctions:
        signals = {}
        for assay in ASSAYS:
            key = f"{well}__{junction_id}__{assay}"
            median_key = f"{key}__median"
            if key in data:
                mean_zoom = data[key][mask]
                signals[assay] = {
                    "mean": mean_zoom,
                    "median": data[median_key][mask] if median_key in data else None,
                }
                per_assay_signals[assay].append(mean_zoom)
            else:
                signals[assay] = None
        per_insert_data.append({"well": well, "junction_id": junction_id, "signals": signals})

    # ── Plot style ─────────────────────────────────────────────────────────────
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Helvetica Neue", "HelveticaNeue-Light",
                                        "Helvetica", "Arial"]

    ticks = [0, ZOOM_FLANK // 2, ZOOM_FLANK, ZOOM_FLANK + INSERT_SIZE // 2,
             ZOOM_FLANK + INSERT_SIZE, ZOOM_FLANK + INSERT_SIZE + ZOOM_FLANK // 2,
             ZOOM_REGION_SIZE]
    labels = ["-1 kb", "-0.5 kb", "Insert\nstart", "Insert\nmid",
              "Insert\nend", "+0.5 kb", "+1 kb"]

    def style_axis(ax, title):
        ax.axvline(ZOOM_FLANK, color="grey", linestyle="--", linewidth=0.8)
        ax.axvline(ZOOM_FLANK + INSERT_SIZE, color="grey", linestyle="--", linewidth=0.8)
        ax.axvspan(ZOOM_FLANK, ZOOM_FLANK + INSERT_SIZE, color="grey", alpha=0.08)
        ax.set_xlabel("Position relative to insert region (bp)", fontsize=8)
        ax.set_ylabel("CPM", fontsize=8)
        ax.set_title(title, fontsize=9)
        ax.set_xticks(ticks)
        ax.set_xticklabels(labels, fontsize=6)
        ax.tick_params(axis="y", labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)

    # ── Per-insert plots ───────────────────────────────────────────────────────
    per_insert_pdf = os.path.join(OUT_DIR, "per_insert_signal_traces_2525bp.pdf")
    with PdfPages(per_insert_pdf) as pdf:
        for entry in per_insert_data:
            fig, ax = plt.subplots(figsize=(8, 4))
            any_signal = False
            for assay in ASSAYS:
                sig = entry["signals"][assay]
                if sig is not None:
                    ax.plot(x_zoom, sig["mean"], color=ASSAY_COLORS[assay], linewidth=1.2,
                            linestyle="-", label=f"{assay} (mean)")
                    if sig["median"] is not None:
                        ax.plot(x_zoom, sig["median"], color=ASSAY_COLORS[assay], linewidth=1.2,
                                linestyle="--", label=f"{assay} (median)")
                    any_signal = True
            style_axis(ax, f"{entry['well']}  {entry['junction_id']}")
            if any_signal:
                ax.legend(loc="upper right", fontsize=6)
            else:
                ax.text(0.5, 0.5, "No signal available", ha="center", va="center",
                         transform=ax.transAxes, fontsize=9, color="grey")
            plt.tight_layout()
            pdf.savefig(fig)
            plt.close(fig)
    print(f"Saved: {per_insert_pdf}  ({len(per_insert_data)} pages)")

    # ── Aggregate plot: median signal per assay across all inserts ────────────
    fig, ax = plt.subplots(figsize=(10, 4.5))
    for assay in ASSAYS:
        sigs = per_assay_signals[assay]
        if not sigs:
            continue
        stacked = np.vstack(sigs)
        median_sig = np.median(stacked, axis=0)
        ax.plot(x_zoom, median_sig, color=ASSAY_COLORS[assay], linewidth=1.5,
                label=f"{assay} (n={len(sigs)})")

    style_axis(ax, f"Median CPM signal across {len(per_insert_data)} gold-standard insert junctions "
                    f"(2525 bp window)")
    ax.legend(loc="upper right", fontsize=9)
    plt.tight_layout()

    all_pdf = os.path.join(OUT_DIR, "all_inserts_median_signal_2525bp.pdf")
    fig.savefig(all_pdf)
    plt.close(fig)
    print(f"Saved: {all_pdf}")

    print("\nDONE.")


if __name__ == "__main__":
    main()
