#!/usr/bin/env python3
"""
Plot median BG4, CUTAC, CM and 27ac CPM signal at the 120 original
gold-standard insert junctions - both per-insert and averaged across all
inserts.

Modelled on:
  /scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/signal_traces/extract_signal_traces.py

For each of the 120 junctions and each assay (BG4, CM, CUTAC, 27ac):
  - Collect every available replicate bigwig (SLX-26997 + SLX-27843 +
    SLX-28240, same replicate-discovery logic as check_structure_confirmation.py)
  - Extract CPM signal over a 20525 bp window (10 kb flank + 525 bp insert +
    10 kb flank), 500 bins
  - Flip reverse-oriented inserts so all are shown in the forward direction
  - Average the replicate signals -> one representative trace per (well, assay)

Outputs (this folder):
  per_insert_signal_traces.pdf   - one page per junction, all 4 assays overlaid
  all_inserts_median_signal.pdf  - single figure: median signal per assay,
                                     averaged across all 120 junctions
  signal_traces_data.npz         - raw per-junction, per-assay signal arrays
"""

import csv
import os
import re

import numpy as np
import pyBigWig
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# ── Paths ──────────────────────────────────────────────────────────────────────
ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"
SLX28240_DIR = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"

MIN_MAPPED_READS = 1_000_000
ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}

FLANK_SIZE  = 10000     # bp of context either side of the insert (new flank)
OLD_FLANK   = 1000      # flank baked into region_start/region_end already
INSERT_SIZE = 525
REGION_SIZE = FLANK_SIZE * 2 + INSERT_SIZE   # 20525
NUM_BINS    = 500


# ── Well normalisation + SLX-26997 padded-well lookup (as in check_structure_confirmation.py) ──
def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (SLX-26997/SLX-27843 keep
    # these permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    # Fallback: SLX-28240's rmDups.txt is a Snakemake temp() file deleted
    # after the pipeline finished. The bigwig_cpm rule's log records the
    # post-dedup pysam mapped-read count before running bamCoverage.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def collect_replicates(well_norm, assay):
    """Same replicate-discovery logic as check_structure_confirmation.py, but
    returning bigwig paths instead of peak files."""
    reps = []

    if assay == "BG4":
        raw = _raw_26997_by_norm.get(well_norm)
        if raw:
            reps.append({
                "label": "SLX26997:B1",
                "sample": f"BG4_{raw}_B1",
                "bw_dir": os.path.join(SLX26997_DIR, "bigwigs"),
                "stats_dir": os.path.join(SLX26997_DIR, "stats"),
                "base_dir": SLX26997_DIR,
            })

    if assay in ("BG4", "CUTAC"):
        sample = f"{assay}_{well_norm}_B1"
        stats_dir = os.path.join(SLX27843_DIR, "stats")
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": "SLX27843:B1",
                "sample": sample,
                "bw_dir": os.path.join(SLX27843_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX27843_DIR,
            })

    stats_dir = os.path.join(SLX28240_DIR, "stats")
    for n in (1, 2, 3):
        sample = f"{assay}_{well_norm}_BR{n}"
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": f"SLX28240:BR{n}",
                "sample": sample,
                "bw_dir": os.path.join(SLX28240_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX28240_DIR,
            })

    passing = []
    for r in reps:
        n = get_dedup_reads(r["base_dir"], r["sample"])
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(r["bw_dir"], f"{r['sample']}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                r["bw_path"] = bw_path
                passing.append(r)
    return passing


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    with open(ORIGINAL_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Original gold-standard BG4 junctions loaded: {len(rows)}")

    # per_assay_signals[assay] -> list of (well, junction_id, signal_array)
    per_assay_signals = {assay: [] for assay in ASSAYS}
    per_insert_data = []   # list of dicts: well, junction_id, {assay: signal or None}

    for row in rows:
        well = row["cell_line"]
        junction_id = row["junction_id"]
        chrom = row["chrom"]
        orientation = row["orientation"]

        insert_start = int(row["region_start"]) + OLD_FLANK
        insert_end   = int(row["region_end"])   - OLD_FLANK
        start = insert_start - FLANK_SIZE
        end   = insert_end   + FLANK_SIZE

        insert_signals = {}
        for assay in ASSAYS:
            reps = collect_replicates(well, assay)
            rep_signals = []
            for rep in reps:
                sig = extract_signal(rep["bw_path"], chrom, start, end, NUM_BINS)
                if sig is not None:
                    rep_signals.append(sig)
            if rep_signals:
                stacked = np.vstack(rep_signals)
                mean_sig = np.mean(stacked, axis=0)
                median_sig = np.median(stacked, axis=0)
                if orientation == "reverse":
                    mean_sig = mean_sig[::-1]
                    median_sig = median_sig[::-1]
                insert_signals[assay] = {"mean": mean_sig, "median": median_sig, "n_reps": len(rep_signals)}
                per_assay_signals[assay].append(mean_sig)
            else:
                insert_signals[assay] = None

        per_insert_data.append({
            "well": well, "junction_id": junction_id, "signals": insert_signals,
        })
        print(f"  {well} {junction_id}: "
              + ", ".join(f"{a}={'Y' if insert_signals[a] is not None else '-'}" for a in ASSAYS))

    # Save raw data. Keys: "{well}__{junction_id}__{assay}" (mean-across-reps)
    # and "{well}__{junction_id}__{assay}__median" (median-across-reps)
    npz_path = os.path.join(OUT_DIR, "signal_traces_data.npz")
    save_dict = {}
    for entry in per_insert_data:
        key_prefix = f"{entry['well']}__{entry['junction_id']}"
        for assay in ASSAYS:
            sig = entry["signals"][assay]
            if sig is not None:
                save_dict[f"{key_prefix}__{assay}"] = sig["mean"]
                save_dict[f"{key_prefix}__{assay}__median"] = sig["median"]
    np.savez_compressed(npz_path, **save_dict)
    print(f"\nSaved raw signal data: {npz_path}")

    # ── Plot style ─────────────────────────────────────────────────────────────
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Helvetica Neue", "HelveticaNeue-Light",
                                        "Helvetica", "Arial"]

    x = np.linspace(0, REGION_SIZE, NUM_BINS)
    mid = FLANK_SIZE + INSERT_SIZE // 2
    ticks = [0, FLANK_SIZE // 2, FLANK_SIZE, mid,
             FLANK_SIZE + INSERT_SIZE,
             FLANK_SIZE + INSERT_SIZE + FLANK_SIZE // 2,
             REGION_SIZE]
    labels = ["-10 kb", "-5 kb", "Insert\nstart", "Insert\nmid",
              "Insert\nend", "+5 kb", "+10 kb"]

    def style_axis(ax, title):
        ax.axvline(FLANK_SIZE, color="grey", linestyle="--", linewidth=0.8)
        ax.axvline(FLANK_SIZE + INSERT_SIZE, color="grey", linestyle="--", linewidth=0.8)
        ax.axvspan(FLANK_SIZE, FLANK_SIZE + INSERT_SIZE, color="grey", alpha=0.08)
        ax.set_xlabel("Position relative to insert region (bp)", fontsize=8)
        ax.set_ylabel("CPM", fontsize=8)
        ax.set_title(title, fontsize=9)
        ax.set_xticks(ticks)
        ax.set_xticklabels(labels, fontsize=6)
        ax.tick_params(axis="y", labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)

    # ── Per-insert plots (one page per junction, 4 assays overlaid) ────────────
    per_insert_pdf = os.path.join(OUT_DIR, "per_insert_signal_traces.pdf")
    with PdfPages(per_insert_pdf) as pdf:
        for entry in per_insert_data:
            fig, ax = plt.subplots(figsize=(8, 4))
            any_signal = False
            for assay in ASSAYS:
                sig = entry["signals"][assay]
                if sig is not None:
                    ax.plot(x, sig["mean"], color=ASSAY_COLORS[assay], linewidth=1.2,
                            linestyle="-", label=f"{assay} (mean, n={sig['n_reps']})")
                    ax.plot(x, sig["median"], color=ASSAY_COLORS[assay], linewidth=1.2,
                            linestyle="--", label=f"{assay} (median)")
                    any_signal = True
            style_axis(ax, f"{entry['well']}  {entry['junction_id']}")
            if any_signal:
                ax.legend(loc="upper right", fontsize=6)
            else:
                ax.text(0.5, 0.5, "No signal available", ha="center", va="center",
                         transform=ax.transAxes, fontsize=9, color="grey")
            plt.tight_layout()
            pdf.savefig(fig)
            plt.close(fig)
    print(f"Saved: {per_insert_pdf}  ({len(per_insert_data)} pages)")

    # ── Aggregate plot: median signal per assay across all inserts ────────────
    fig, ax = plt.subplots(figsize=(10, 4.5))
    for assay in ASSAYS:
        sigs = per_assay_signals[assay]
        if not sigs:
            continue
        stacked = np.vstack(sigs)
        median_sig = np.median(stacked, axis=0)
        ax.plot(x, median_sig, color=ASSAY_COLORS[assay], linewidth=1.5,
                label=f"{assay} (n={len(sigs)})")

    style_axis(ax, f"Median CPM signal across {len(per_insert_data)} gold-standard insert junctions")
    ax.legend(loc="upper right", fontsize=9)
    plt.tight_layout()

    all_pdf = os.path.join(OUT_DIR, "all_inserts_median_signal.pdf")
    fig.savefig(all_pdf)
    plt.close(fig)
    print(f"Saved: {all_pdf}")

    # ── Summary ────────────────────────────────────────────────────────────────
    print("\nReplicate coverage per assay (n junctions with >=1 signal):")
    for assay in ASSAYS:
        print(f"  {assay}: {len(per_assay_signals[assay])}/{len(rows)}")

    print("\nDONE.")


if __name__ == "__main__":
    main()
