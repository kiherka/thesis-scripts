#!/usr/bin/env python3
"""
For every BG4 "BR1" bigwig (SLX-26997 BG4_{well}_B1, falling back to
SLX-27843 BG4_{well}_B1 for the handful of wells where SLX-26997 fails the
deduplicated-read-count QC filter), plot two signal traces side by side:
  1. The insert region for that well's junction(s), with 1 kb flanks either
     side (matching the 2525 bp window used throughout this project).
  2. The KRAS reference region (chr12:25,250,600-25,251,600) with 1 kb flanks,
     coordinate-shifted for wells whose own integrated genome has additional
     insert(s) upstream of this locus on chr12 (same shift logic as
     analyse_insert_specificity_v2.py, using consensus_len from that well's
     SPLINK_{well}.junctions.bed).

One page per gold-standard junction (120 total), each using ONLY that well's
single BG4 BR1 bigwig (no averaging across replicates).

Output (this folder): bg4_br1_insert_vs_kras.pdf
"""

import csv
import os
import re

import numpy as np
import pyBigWig
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# ── Paths ──────────────────────────────────────────────────────────────────────
ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
JUNCTIONS_BED_DIR = "/scratche/slow/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PDF = os.path.join(OUT_DIR, "bg4_br1_insert_vs_kras.pdf")

SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"

MIN_MAPPED_READS = 1_000_000
FLANK = 1000                  # 1 kb flanks
NUM_BINS = 200

KRAS_CHROM = "chr12"
KRAS_START = 25250600
KRAS_END = 25251600


# ── Well normalisation + SLX-26997 padded-well lookup ─────────────────────────
def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (kept permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)
    # Fallback: bigwig_cpm log's pysam mapped-read count.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def get_bg4_br1_bigwig(well_norm):
    """Return the BG4 'BR1' bigwig path for this well: SLX-26997 preferred,
    SLX-27843 fallback. Only returns a path if the sample passes the
    deduplicated-reads QC filter."""
    raw = _raw_26997_by_norm.get(well_norm)
    if raw:
        sample = f"BG4_{raw}_B1"
        n = get_dedup_reads(SLX26997_DIR, sample)
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(SLX26997_DIR, "bigwigs", f"{sample}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                return bw_path, "SLX-26997", sample

    sample = f"BG4_{well_norm}_B1"
    stats_path = os.path.join(SLX27843_DIR, "stats", f"{sample}.r1.hg38.sort.stats")
    if os.path.exists(stats_path):
        n = get_dedup_reads(SLX27843_DIR, sample)
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(SLX27843_DIR, "bigwigs", f"{sample}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                return bw_path, "SLX-27843", sample

    return None, None, None


def get_kras_shift(well):
    """Sum consensus_len for every junction on chr12 upstream of the KRAS
    locus in this well's OWN junctions.bed (all detected junctions), giving
    the coordinate shift needed to find KRAS in this well's integrated
    genome."""
    path = os.path.join(JUNCTIONS_BED_DIR, f"SPLINK_{well}.junctions.bed")
    if not os.path.exists(path):
        return 0
    shift = 0
    with open(path) as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            chrom, start, consensus_len = parts[0], int(parts[1]), int(parts[6])
            if chrom == KRAS_CHROM and start < KRAS_START:
                shift += consensus_len
    return shift


def extract_signal(bw, chrom, start, end, num_bins):
    chroms = bw.chroms()
    if chrom not in chroms:
        return None
    chrom_len = chroms[chrom]
    s, e = max(0, start), min(end, chrom_len)
    if e <= s:
        return None
    vals = bw.stats(chrom, s, e, nBins=num_bins, type="mean")
    return np.array([v if v is not None else 0.0 for v in vals])


def main():
    with open(ORIGINAL_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Original gold-standard BG4 junctions loaded: {len(rows)}")

    # Cache one bigwig handle + KRAS shift per well
    bw_cache = {}
    shift_cache = {}
    n_no_bw = 0

    plt.rcParams["font.family"] = "sans-serif"

    with PdfPages(OUT_PDF) as pdf:
        for row in rows:
            well = row["cell_line"]
            junction_id = row["junction_id"]
            chrom = row["chrom"]
            insert_start = int(row["region_start"])
            insert_end = int(row["region_end"])
            orientation = row["orientation"]

            if well not in bw_cache:
                bw_path, dataset, sample = get_bg4_br1_bigwig(well)
                bw_cache[well] = (bw_path, dataset, sample)
                shift_cache[well] = get_kras_shift(well)
            bw_path, dataset, sample = bw_cache[well]
            shift = shift_cache[well]

            fig, axes = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)

            if bw_path is None:
                for ax in axes:
                    ax.text(0.5, 0.5, "No BG4 BR1 bigwig\n(failed QC or missing)",
                            ha="center", va="center", transform=ax.transAxes,
                            fontsize=9, color="grey")
                fig.suptitle(f"{well}  {junction_id}", fontsize=10, fontweight="bold")
                pdf.savefig(fig)
                plt.close(fig)
                n_no_bw += 1
                continue

            bw = pyBigWig.open(bw_path)
            try:
                # ── Insert region (with 1 kb flanks) ─────────────────────────
                i_start, i_end = insert_start - FLANK, insert_end + FLANK
                insert_sig = extract_signal(bw, chrom, i_start, i_end, NUM_BINS)
                if insert_sig is not None and orientation == "reverse":
                    insert_sig = insert_sig[::-1]

                # ── KRAS reference region (with 1 kb flanks, shifted) ────────
                k_start = KRAS_START + shift - FLANK
                k_end = KRAS_END + shift + FLANK
                kras_sig = extract_signal(bw, KRAS_CHROM, k_start, k_end, NUM_BINS)
            finally:
                bw.close()

            x_insert = np.linspace(-(FLANK), (insert_end - insert_start) + FLANK, NUM_BINS)
            x_kras = np.linspace(-(FLANK), (KRAS_END - KRAS_START) + FLANK, NUM_BINS)

            ax = axes[0]
            if insert_sig is not None:
                ax.plot(x_insert, insert_sig, color="#2166ac", linewidth=1.2)
                ax.axvspan(0, insert_end - insert_start, color="grey", alpha=0.1)
            ax.set_title(f"Insert region\n{chrom}:{insert_start:,}-{insert_end:,}", fontsize=9)
            ax.set_xlabel("Position relative to insert (bp)", fontsize=8)
            ax.set_ylabel("BG4 CPM", fontsize=8)
            ax.tick_params(labelsize=7)
            ax.spines[["top", "right"]].set_visible(False)

            ax = axes[1]
            if kras_sig is not None:
                ax.plot(x_kras, kras_sig, color="#cb181d", linewidth=1.2)
                ax.axvspan(0, KRAS_END - KRAS_START, color="grey", alpha=0.1)
            shift_note = f" (+{shift} bp shift)" if shift else ""
            ax.set_title(f"KRAS reference region{shift_note}\n"
                         f"{KRAS_CHROM}:{KRAS_START + shift:,}-{KRAS_END + shift:,}", fontsize=9)
            ax.set_xlabel("Position relative to KRAS region (bp)", fontsize=8)
            ax.set_ylabel("BG4 CPM", fontsize=8)
            ax.tick_params(labelsize=7)
            ax.spines[["top", "right"]].set_visible(False)

            fig.suptitle(f"{well}  {junction_id}  |  BG4 BR1 = {sample} ({dataset})",
                         fontsize=10, fontweight="bold")
            pdf.savefig(fig)
            plt.close(fig)

    n_wells_with_bw = sum(1 for v in bw_cache.values() if v[0] is not None)
    print(f"\nWells with a usable BG4 BR1 bigwig: {n_wells_with_bw}/{len(bw_cache)}")
    print(f"Junctions with no BG4 BR1 signal available: {n_no_bw}/{len(rows)}")
    print(f"\nSaved: {OUT_PDF}  ({len(rows)} pages)")
    print("\nDONE.")


if __name__ == "__main__":
    main()
