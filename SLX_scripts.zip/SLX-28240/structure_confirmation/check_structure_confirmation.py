#!/usr/bin/env python3
"""
Structure confirmation (v2): for each of the 120 original gold-standard BG4
insert junctions (SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv),
check how many replicates across BG4, CM, CUTAC and 27ac assays independently
detect a peak at the SAME insert junction in the SAME cell line (well).

A replicate counts as having a peak if EITHER SEACR OR MACS2 called one there
(lenient OR logic - a replicate need not be confirmed by both callers).

Data sources combined (v2 adds SLX-27843 directly + CUTAC/27ac assays):
  SLX-26997  : BG4 only            sample = BG4_{padded_well}_B1
  SLX-27843  : BG4, CUTAC          sample = {ASSAY}_{well}_B1
               (this is the dataset some of the original 120 calls actually
               came from - see v1 finding that 14/22 SLX-27843-origin
               junctions showed zero BG4 support because SLX-27843 was never
               checked before)
  SLX-28240  : BG4, CM, CUTAC, 27ac  sample = {ASSAY}_{well}_BR{1,2,3}
               (27ac only has BR1/BR2, no BR3)

All replicates are subject to the same >=1,000,000 mapped-reads QC filter
used throughout this project.

Output (this folder):
  structure_confirmation.tsv - one row per original junction, with per-assay
                                 replicate counts/peak status across all 3
                                 datasets
  Console summary of confirmation rates, per assay.
"""

import csv
import os
import re
import subprocess
import tempfile
from collections import defaultdict

ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
BED_DIR      = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/bed_regions"

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_TSV = os.path.join(OUT_DIR, "structure_confirmation.tsv")

MIN_MAPPED_READS = 1_000_000
ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]

# ── Dataset / sample-naming definitions ───────────────────────────────────────
SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"
SLX28240_DIR = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"


def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


# Map normalised well -> raw (zero-padded) SLX-26997 well name
_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (SLX-26997/SLX-27843 keep
    # these permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    # Fallback: SLX-28240's rmDups.txt is a Snakemake temp() file deleted
    # after the pipeline finished. The bigwig_cpm rule's log records the
    # post-dedup pysam mapped-read count before running bamCoverage.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def peak_files(peaks_dir, sample):
    seacr = os.path.join(peaks_dir, "seacr", f"{sample}.stringent.bed")
    macs2 = os.path.join(peaks_dir, "macs2", f"{sample}_peaks.narrowPeak")
    return (seacr if os.path.exists(seacr) else None,
            macs2 if os.path.exists(macs2) else None)


def collect_replicates(well_norm, assay):
    """Return list of dicts: {label, sample, peaks_dir, stats_dir} for every
    available (and read-count-passing) replicate of `assay` for this well,
    across SLX-26997, SLX-27843 and SLX-28240."""
    reps = []

    # SLX-26997: BG4 only
    if assay == "BG4":
        raw = _raw_26997_by_norm.get(well_norm)
        if raw:
            reps.append({
                "label": "SLX26997:B1",
                "sample": f"BG4_{raw}_B1",
                "peaks_dir": os.path.join(SLX26997_DIR, "peaks"),
                "stats_dir": os.path.join(SLX26997_DIR, "stats"),
                "base_dir": SLX26997_DIR,
            })

    # SLX-27843: BG4, CUTAC (unpadded well names)
    if assay in ("BG4", "CUTAC"):
        sample = f"{assay}_{well_norm}_B1"
        stats_dir = os.path.join(SLX27843_DIR, "stats")
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": "SLX27843:B1",
                "sample": sample,
                "peaks_dir": os.path.join(SLX27843_DIR, "peaks"),
                "stats_dir": stats_dir,
                "base_dir": SLX27843_DIR,
            })

    # SLX-28240: BG4, CM, CUTAC, 27ac (unpadded well names, BR1/2/3)
    stats_dir = os.path.join(SLX28240_DIR, "stats")
    for n in (1, 2, 3):
        sample = f"{assay}_{well_norm}_BR{n}"
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": f"SLX28240:BR{n}",
                "sample": sample,
                "peaks_dir": os.path.join(SLX28240_DIR, "peaks"),
                "stats_dir": stats_dir,
                "base_dir": SLX28240_DIR,
            })

    # Apply read-count filter
    passing = []
    for r in reps:
        n = get_dedup_reads(r["base_dir"], r["sample"])
        if n is not None and n >= MIN_MAPPED_READS:
            r["mapped_reads"] = n
            passing.append(r)
    return passing


def filter_chr(peak_file, tmp_dir, tag):
    if peak_file is None:
        return None
    out = os.path.join(tmp_dir, os.path.basename(peak_file) + f".{tag}.chr.bed")
    with open(peak_file) as fi, open(out, "w") as fo:
        for line in fi:
            if line.startswith("chr"):
                fo.write(line)
    return out if os.path.getsize(out) > 0 else None


def bedtools_hit_names(bed_a, bed_b):
    if not bed_b:
        return set()
    try:
        res = subprocess.run(
            ["bedtools", "intersect", "-a", bed_a, "-b", bed_b, "-wa", "-u"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
        )
    except subprocess.CalledProcessError:
        return set()
    hits = set()
    for line in res.stdout.decode().strip().split("\n"):
        if line:
            hits.add(line.split("\t")[3])
    return hits


def main():
    originals = []
    with open(ORIGINAL_TSV) as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            originals.append(row)
    print(f"Original gold-standard BG4 junctions loaded: {len(originals)}")

    # Group originals by well so we only run bedtools once per well/assay
    by_well = defaultdict(list)
    for row in originals:
        by_well[row["cell_line"]].append(row)

    results_by_key = {}

    with tempfile.TemporaryDirectory() as tmp_dir:
        for well, rows in by_well.items():
            bed_file = os.path.join(BED_DIR, f"SPLINK_{well}.insert_regions.bed")
            if not os.path.exists(bed_file):
                bed_file = os.path.join(BED_DIR, f"SPLINK_{normalise_well(well)}.insert_regions.bed")
            if not os.path.exists(bed_file):
                for row in rows:
                    results_by_key[(well, row["junction_id"])] = {"__no_bed__": True}
                continue

            per_assay = {}
            for assay in ASSAYS:
                reps = collect_replicates(well, assay)
                hits_by_rep = {}
                for rep in reps:
                    seacr_raw, macs2_raw = peak_files(rep["peaks_dir"], rep["sample"])
                    seacr_f = filter_chr(seacr_raw, tmp_dir, f"{rep['sample']}_s")
                    macs2_f = filter_chr(macs2_raw, tmp_dir, f"{rep['sample']}_m")
                    seacr_hits = bedtools_hit_names(bed_file, seacr_f)
                    macs2_hits = bedtools_hit_names(bed_file, macs2_f)
                    hits_by_rep[rep["label"]] = (seacr_hits, macs2_hits)
                per_assay[assay] = (reps, hits_by_rep)

            for row in rows:
                junction_id = row["junction_id"]
                # need the full junction "name" (id|loc|reads|orientation) to
                # match against bedtools -wa -u hit names
                name = "|".join([
                    row["junction_id"], row["junction_location"],
                    row["read_support"], row["orientation"],
                ])
                per_assay_result = {}
                for assay in ASSAYS:
                    reps, hits_by_rep = per_assay[assay]
                    reps_with_peak = []
                    for rep in reps:
                        seacr_hits, macs2_hits = hits_by_rep[rep["label"]]
                        # Lenient: EITHER SEACR OR MACS2 counts as a peak call
                        if name in seacr_hits or name in macs2_hits:
                            reps_with_peak.append(rep["label"])
                    per_assay_result[assay] = {
                        "n_available": len(reps),
                        "n_with_peak": len(reps_with_peak),
                        "reps_with_peak": reps_with_peak,
                    }
                results_by_key[(well, junction_id)] = per_assay_result

    # ── Build output rows ──────────────────────────────────────────────────────
    out_rows = []
    for row in originals:
        well = row["cell_line"]
        junction_id = row["junction_id"]
        res = results_by_key.get((well, junction_id))

        out = {
            "well": well, "junction_id": junction_id,
            "chrom": row["chrom"], "region_start": row["region_start"],
            "region_end": row["region_end"], "junction_location": row["junction_location"],
            "read_support": row["read_support"], "orientation": row["orientation"],
            "original_dataset": row["dataset"], "original_sample": row["sample"],
            "original_seacr_peak": row["seacr_peak"], "original_macs2_peak": row["macs2_peak"],
        }

        if res is None or res.get("__no_bed__"):
            for assay in ASSAYS:
                out[f"n_{assay}_reps_available"] = 0
                out[f"n_{assay}_reps_with_peak"] = 0
                out[f"{assay}_reps_with_peak"] = "-"
            out["status"] = "NO_BED_FILE"
        else:
            n_total_avail = n_total_hit = 0
            for assay in ASSAYS:
                a = res[assay]
                out[f"n_{assay}_reps_available"] = a["n_available"]
                out[f"n_{assay}_reps_with_peak"] = a["n_with_peak"]
                out[f"{assay}_reps_with_peak"] = ";".join(a["reps_with_peak"]) or "-"
                n_total_avail += a["n_available"]
                n_total_hit += a["n_with_peak"]

            if n_total_avail == 0:
                status = "NO_DATA"
            elif n_total_hit == 0:
                status = "NOT_CONFIRMED"
            elif n_total_hit == n_total_avail:
                status = "FULLY_CONFIRMED"
            else:
                status = "PARTIALLY_CONFIRMED"
            out["n_total_reps_available"] = n_total_avail
            out["n_total_reps_with_peak"] = n_total_hit
            out["status"] = status

        out_rows.append(out)

    header = [
        "well", "junction_id", "chrom", "region_start", "region_end",
        "junction_location", "read_support", "orientation",
        "original_dataset", "original_sample", "original_seacr_peak", "original_macs2_peak",
    ]
    for assay in ASSAYS:
        header += [f"n_{assay}_reps_available", f"n_{assay}_reps_with_peak", f"{assay}_reps_with_peak"]
    header += ["n_total_reps_available", "n_total_reps_with_peak", "status"]

    with open(OUT_TSV, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for r in out_rows:
            fo.write("\t".join(str(r.get(h, "")) for h in header) + "\n")

    print(f"Written: {OUT_TSV}\n")

    # ── Summary ────────────────────────────────────────────────────────────────
    status_counts = defaultdict(int)
    for r in out_rows:
        status_counts[r["status"]] += 1
    print("Overall status breakdown (across all assays combined):")
    for s in ["FULLY_CONFIRMED", "PARTIALLY_CONFIRMED", "NOT_CONFIRMED", "NO_DATA", "NO_BED_FILE"]:
        print(f"  {s}: {status_counts.get(s, 0)}")

    print("\nPer-assay confirmation (junctions with >=1 replicate showing a peak):")
    for assay in ASSAYS:
        n_avail = sum(1 for r in out_rows if r.get(f"n_{assay}_reps_available", 0) > 0)
        n_hit = sum(1 for r in out_rows if r.get(f"n_{assay}_reps_with_peak", 0) > 0)
        print(f"  {assay}: {n_hit}/{n_avail} confirmed (of {n_avail} junctions with {assay} data; "
              f"{len(out_rows) - n_avail} had no {assay} data at all)")

    print("\nDONE.")


if __name__ == "__main__":
    main()
