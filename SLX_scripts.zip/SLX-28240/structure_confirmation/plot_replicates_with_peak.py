#!/usr/bin/env python3
"""
Plot the number of insert junctions (from structure_confirmation.tsv) against
the number of BG4 / CM replicates in which a peak is present at that same
junction.

Output: replicates_with_peak_histogram.pdf (this folder)
"""

import os
from collections import Counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

IN_TSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "structure_confirmation.tsv")
OUT_PDF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "replicates_with_peak_histogram.pdf")

import csv

bg4_counts = Counter()
cm_counts = Counter()

with open(IN_TSV) as f:
    reader = csv.DictReader(f, delimiter="\t")
    for row in reader:
        bg4_counts[int(row["n_bg4_reps_with_peak"])] += 1
        cm_counts[int(row["n_cm_reps_with_peak"])] += 1

max_x = max(max(bg4_counts, default=0), max(cm_counts, default=0))
x_vals = list(range(0, max_x + 1))

bg4_y = [bg4_counts.get(x, 0) for x in x_vals]
cm_y = [cm_counts.get(x, 0) for x in x_vals]

fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), constrained_layout=True)

for ax, y, title, color in zip(
    axes, [bg4_y, cm_y], ["BG4", "CM"], ["#2171b5", "#cb181d"]
):
    bars = ax.bar(x_vals, y, color=color, width=0.6)
    for rect, val in zip(bars, y):
        if val > 0:
            ax.text(rect.get_x() + rect.get_width() / 2, val + 0.5, str(val),
                    ha="center", va="bottom", fontsize=8)
    ax.set_xlabel("Number of replicates with a peak")
    ax.set_ylabel("Number of insert junctions")
    ax.set_title(f"{title} replicates", fontsize=11, fontweight="bold")
    ax.set_xticks(x_vals)
    ax.spines[["top", "right"]].set_visible(False)

fig.suptitle(
    "Insert junctions vs. number of replicates with a peak\n"
    "(120 original gold-standard BG4 junctions; structure_confirmation.tsv)",
    fontsize=10,
)

fig.savefig(OUT_PDF)
print(f"Saved: {OUT_PDF}")
print(f"BG4 counts (n_reps_with_peak -> n_junctions): {dict(sorted(bg4_counts.items()))}")
print(f"CM  counts (n_reps_with_peak -> n_junctions): {dict(sorted(cm_counts.items()))}")
