#!/usr/bin/env python3
"""
Insert specificity analysis.

For each of the 120 original gold-standard BG4 insert junctions, compute the
mean and peak (max) CPM signal in the 2525 bp region (1 kb flank + 525 bp
insert + 1 kb flank) for BG4, CM, CUTAC and 27ac - using every available
replicate for that cell line (well), combining SLX-26997, SLX-27843 and
SLX-28240 (SLX-26997/SLX-27843 both provide a BG4 "BR1"-equivalent replicate).

This "self" signal is then compared with the SAME genomic locus in the OTHER
83 cell lines from the same 84-well deep-profiled panel (which do NOT carry
this particular insert) - i.e. is there something intrinsically special
about this signal at this locus in this clone specifically, vs the same
locus in unrelated clones where no insert landed there?

Outputs (this folder):
  insert_specificity.tsv - one row per (well, junction, assay): self mean/peak
                             CPM vs the distribution of the other 83 wells'
                             mean/peak CPM at the same locus
  insert_specificity_boxplots.pdf - per-assay boxplots: self vs others,
                             for mean CPM and peak CPM
  insert_specificity_differences.pdf - per-assay distribution of
                             (self - median(others)) across all 120 junctions
"""

import csv
import os
import re
from collections import defaultdict

import numpy as np
import pyBigWig
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ── Paths ──────────────────────────────────────────────────────────────────────
ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"
SLX28240_DIR = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"

MIN_MAPPED_READS = 1_000_000
ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}


# ── Well normalisation + SLX-26997 padded-well lookup ─────────────────────────
def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (SLX-26997/SLX-27843 keep
    # these permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    # Fallback: SLX-28240's rmDups.txt is a Snakemake temp() file deleted
    # after the pipeline finished. The bigwig_cpm rule's log records the
    # post-dedup pysam mapped-read count before running bamCoverage.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def collect_replicates(well_norm, assay):
    """Same replicate-discovery logic as check_structure_confirmation.py /
    extract_assay_signal_traces.py, returning bigwig paths."""
    reps = []

    if assay == "BG4":
        raw = _raw_26997_by_norm.get(well_norm)
        if raw:
            reps.append({
                "label": "SLX26997:B1",
                "sample": f"BG4_{raw}_B1",
                "bw_dir": os.path.join(SLX26997_DIR, "bigwigs"),
                "stats_dir": os.path.join(SLX26997_DIR, "stats"),
                "base_dir": SLX26997_DIR,
            })

    if assay in ("BG4", "CUTAC"):
        sample = f"{assay}_{well_norm}_B1"
        stats_dir = os.path.join(SLX27843_DIR, "stats")
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": "SLX27843:B1",
                "sample": sample,
                "bw_dir": os.path.join(SLX27843_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX27843_DIR,
            })

    stats_dir = os.path.join(SLX28240_DIR, "stats")
    for n in (1, 2, 3):
        sample = f"{assay}_{well_norm}_BR{n}"
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": f"SLX28240:BR{n}",
                "sample": sample,
                "bw_dir": os.path.join(SLX28240_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX28240_DIR,
            })

    passing = []
    for r in reps:
        n = get_dedup_reads(r["base_dir"], r["sample"])
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(r["bw_dir"], f"{r['sample']}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                r["bw_path"] = bw_path
                passing.append(r)
    return passing


def main():
    with open(ORIGINAL_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Original gold-standard BG4 junctions loaded: {len(rows)}")

    junctions = [
        {
            "well": row["cell_line"],
            "junction_id": row["junction_id"],
            "chrom": row["chrom"],
            "start": int(row["region_start"]),
            "end": int(row["region_end"]),
        }
        for row in rows
    ]
    all_wells = sorted({j["well"] for j in junctions})
    print(f"Unique wells (cell lines) among these junctions: {len(all_wells)}")

    # ── Discover replicate bigwigs for every well x assay (the 84-well panel) ──
    well_bws = {assay: {} for assay in ASSAYS}   # assay -> well -> [bw paths]
    for assay in ASSAYS:
        for well in all_wells:
            reps = collect_replicates(well, assay)
            if reps:
                well_bws[assay][well] = [r["bw_path"] for r in reps]
        print(f"  {assay}: {len(well_bws[assay])}/{len(all_wells)} wells have data")

    # ── For each assay, open each well's bigwig(s) ONCE and query every ───────
    # junction region from them (much faster than reopening per region).
    # signal[assay][well][junction_key] = (mean_cpm, peak_cpm)  (avg across reps)
    signal = {assay: defaultdict(dict) for assay in ASSAYS}

    for assay in ASSAYS:
        for well, bw_paths in well_bws[assay].items():
            rep_values = defaultdict(list)  # junction_key -> [(mean, peak), ...] across reps
            for bw_path in bw_paths:
                bw = pyBigWig.open(bw_path)
                try:
                    chroms = bw.chroms()
                    for j in junctions:
                        key = (j["well"], j["junction_id"])
                        chrom, start, end = j["chrom"], j["start"], j["end"]
                        if chrom not in chroms:
                            continue
                        chrom_len = chroms[chrom]
                        s, e = max(0, start), min(end, chrom_len)
                        if e <= s:
                            continue
                        mean_v = bw.stats(chrom, s, e, type="mean")[0]
                        max_v = bw.stats(chrom, s, e, type="max")[0]
                        mean_v = mean_v if mean_v is not None else 0.0
                        max_v = max_v if max_v is not None else 0.0
                        rep_values[key].append((mean_v, max_v))
                finally:
                    bw.close()
            for key, vals in rep_values.items():
                means = [v[0] for v in vals]
                peaks = [v[1] for v in vals]
                signal[assay][well][key] = (float(np.mean(means)), float(np.mean(peaks)))
        print(f"  {assay}: signal extracted for {sum(len(v) for v in signal[assay].values())} (well, junction) pairs")

    # ── Build comparison rows: self vs the other 83 wells at this locus ──────
    out_rows = []
    for j in junctions:
        well = j["well"]
        junction_id = j["junction_id"]
        key = (well, junction_id)

        for assay in ASSAYS:
            self_vals = signal[assay].get(well, {}).get(key)
            others_means, others_peaks = [], []
            for other_well in all_wells:
                if other_well == well:
                    continue
                v = signal[assay].get(other_well, {}).get(key)
                if v is not None:
                    others_means.append(v[0])
                    others_peaks.append(v[1])

            if self_vals is None or not others_means:
                continue

            self_mean, self_peak = self_vals
            med_others_mean = float(np.median(others_means))
            med_others_peak = float(np.median(others_peaks))

            out_rows.append({
                "well": well, "junction_id": junction_id, "assay": assay,
                "chrom": j["chrom"], "region_start": j["start"], "region_end": j["end"],
                "self_mean_cpm": round(self_mean, 4),
                "self_peak_cpm": round(self_peak, 4),
                "n_other_wells": len(others_means),
                "others_median_mean_cpm": round(med_others_mean, 4),
                "others_median_peak_cpm": round(med_others_peak, 4),
                "others_mean_mean_cpm": round(float(np.mean(others_means)), 4),
                "others_mean_peak_cpm": round(float(np.mean(others_peaks)), 4),
                "diff_mean_cpm": round(self_mean - med_others_mean, 4),
                "diff_peak_cpm": round(self_peak - med_others_peak, 4),
            })

    header = [
        "well", "junction_id", "assay", "chrom", "region_start", "region_end",
        "self_mean_cpm", "self_peak_cpm", "n_other_wells",
        "others_median_mean_cpm", "others_median_peak_cpm",
        "others_mean_mean_cpm", "others_mean_peak_cpm",
        "diff_mean_cpm", "diff_peak_cpm",
    ]
    out_tsv = os.path.join(OUT_DIR, "insert_specificity.tsv")
    with open(out_tsv, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for r in out_rows:
            fo.write("\t".join(str(r[h]) for h in header) + "\n")
    print(f"\nWritten: {out_tsv}  ({len(out_rows)} rows)")

    # ── Plot 1: self vs others boxplots (mean CPM and peak CPM), per assay ────
    fig, axes = plt.subplots(2, 4, figsize=(16, 8), constrained_layout=True)
    for col, assay in enumerate(ASSAYS):
        assay_rows = [r for r in out_rows if r["assay"] == assay]
        self_means = [r["self_mean_cpm"] for r in assay_rows]
        other_means = [r["others_median_mean_cpm"] for r in assay_rows]
        self_peaks = [r["self_peak_cpm"] for r in assay_rows]
        other_peaks = [r["others_median_peak_cpm"] for r in assay_rows]

        ax = axes[0, col]
        bp = ax.boxplot([self_means, other_means], labels=["Self\n(insert)", "Others\n(median)"],
                         patch_artist=True, showfliers=False, widths=0.6)
        for patch, color in zip(bp["boxes"], [ASSAY_COLORS[assay], "#aaaaaa"]):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        ax.set_title(f"{assay}: mean CPM (n={len(assay_rows)})", fontsize=9)
        ax.set_ylabel("Mean CPM", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)

        ax = axes[1, col]
        bp = ax.boxplot([self_peaks, other_peaks], labels=["Self\n(insert)", "Others\n(median)"],
                         patch_artist=True, showfliers=False, widths=0.6)
        for patch, color in zip(bp["boxes"], [ASSAY_COLORS[assay], "#aaaaaa"]):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        ax.set_title(f"{assay}: peak CPM (n={len(assay_rows)})", fontsize=9)
        ax.set_ylabel("Peak (max) CPM", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle("Insert-site signal (self) vs. same locus in other 83 cell lines (others)",
                 fontsize=11, fontweight="bold")
    box_pdf = os.path.join(OUT_DIR, "insert_specificity_boxplots.pdf")
    fig.savefig(box_pdf)
    plt.close(fig)
    print(f"Saved: {box_pdf}")

    # ── Plot 2: distribution of differences (self - median(others)) ──────────
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
    for ax, metric, title in zip(axes, ["diff_mean_cpm", "diff_peak_cpm"],
                                  ["Mean CPM difference", "Peak CPM difference"]):
        data = [[r[metric] for r in out_rows if r["assay"] == assay] for assay in ASSAYS]
        bp = ax.boxplot(data, labels=ASSAYS, patch_artist=True, showfliers=True, widths=0.6)
        for patch, assay in zip(bp["boxes"], ASSAYS):
            patch.set_facecolor(ASSAY_COLORS[assay])
            patch.set_alpha(0.7)
        ax.axhline(0, color="black", lw=0.8, linestyle="--")
        ax.set_title(f"{title}\n(self - median of other 83 cell lines)", fontsize=10)
        ax.set_ylabel("CPM difference", fontsize=9)
        ax.tick_params(labelsize=8)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle("Insert specificity: signal at insert site vs. same locus without the insert\n"
                 "(120 gold-standard junctions)", fontsize=11, fontweight="bold")
    diff_pdf = os.path.join(OUT_DIR, "insert_specificity_differences.pdf")
    fig.savefig(diff_pdf)
    plt.close(fig)
    print(f"Saved: {diff_pdf}")

    # ── Summary ────────────────────────────────────────────────────────────────
    print("\nMedian difference (self - median(others)) per assay:")
    for assay in ASSAYS:
        assay_rows = [r for r in out_rows if r["assay"] == assay]
        if not assay_rows:
            continue
        med_diff_mean = np.median([r["diff_mean_cpm"] for r in assay_rows])
        med_diff_peak = np.median([r["diff_peak_cpm"] for r in assay_rows])
        n_higher_mean = sum(1 for r in assay_rows if r["diff_mean_cpm"] > 0)
        print(f"  {assay}: median diff mean CPM = {med_diff_mean:.3f}, "
              f"median diff peak CPM = {med_diff_peak:.3f}, "
              f"{n_higher_mean}/{len(assay_rows)} junctions higher than others (mean)")

    print("\nDONE.")


if __name__ == "__main__":
    main()
