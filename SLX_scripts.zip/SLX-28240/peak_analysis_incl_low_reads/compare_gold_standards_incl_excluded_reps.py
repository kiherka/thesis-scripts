#!/usr/bin/env python3
"""
Check whether including the 12 "low-read-count-excluded" BG4/CM replicates
(identified by debug_missing_replicates.py) changes the gold-standard status
of any insert junction, and whether any *new* gold-standard junctions emerge.

Background
----------
debug_missing_replicates.py showed that, of the 84 SLX-28240 deep-profiled
wells, 12 are missing one of their 6 expected BG4+CM gold-standard replicates
because that replicate falls below the MIN_MAPPED_READS (1,000,000) filter
used in analyse_replicate_peaks.py:
  - 11 wells: SLX-26997 BG4_BR1  (176k-310k mapped reads)
  - 1  well : SLX-28240 CM_BR2   (558k mapped reads, well 6C5)

This script re-examines those 12 replicates:
  - For the 11 BG4_BR1 replicates: SLX-26997 never ran peak calling for such
    low-depth samples (no SEACR/MACS2 output files exist at all), so their
    contribution CANNOT be evaluated - reported as "not evaluable".
  - For CM_6C5_BR2: peak files DO exist (peak calling ran regardless of read
    depth in the SLX-28240 pipeline), so we can directly test whether it has
    a peak at each of well 6C5's insert junctions and recompute the
    gold-standard fraction including it.

Outputs (this folder):
  gold_standard_comparison_incl_low_read_reps.tsv  - per-junction comparison
                                                       (baseline vs including
                                                       the extra replicate)
  Console summary of counts by category.
"""

import csv
import os
import subprocess
import tempfile
from collections import OrderedDict, defaultdict

# ── Paths ──────────────────────────────────────────────────────────────────────
BASELINE_TSV = "/scratche/slow/sblab/herka01/SLX-28240/peak_analysis/replicate_peak_summary.tsv"
OUT_DIR      = os.path.dirname(os.path.abspath(__file__))
OUT_TSV      = os.path.join(OUT_DIR, "gold_standard_comparison_incl_low_read_reps.tsv")

GOLD_STANDARD_THR = 0.75

# ── The 12 replicates excluded by the MIN_MAPPED_READS filter ────────────────
# (well -> [(assay, replicate, sample, peaks_dir, evaluable)])
SLX26997_PEAKS = "/scratche/slow/sblab/herka01/SLX-26997/peaks"
SLX28240_PEAKS = "/scratche/slow/sblab/herka01/SLX-28240/pipeline/peaks"

EXCLUDED_REPS = {
    "1A11": [("BG4", "BR1", "BG4_1A11_B1", SLX26997_PEAKS)],
    "1A12": [("BG4", "BR1", "BG4_1A12_B1", SLX26997_PEAKS)],
    "1A2":  [("BG4", "BR1", "BG4_1A02_B1", SLX26997_PEAKS)],
    "1A5":  [("BG4", "BR1", "BG4_1A05_B1", SLX26997_PEAKS)],
    "1A7":  [("BG4", "BR1", "BG4_1A07_B1", SLX26997_PEAKS)],
    "1A8":  [("BG4", "BR1", "BG4_1A08_B1", SLX26997_PEAKS)],
    "1B10": [("BG4", "BR1", "BG4_1B10_B1", SLX26997_PEAKS)],
    "1B11": [("BG4", "BR1", "BG4_1B11_B1", SLX26997_PEAKS)],
    "1B7":  [("BG4", "BR1", "BG4_1B07_B1", SLX26997_PEAKS)],
    "1B8":  [("BG4", "BR1", "BG4_1B08_B1", SLX26997_PEAKS)],
    "1B9":  [("BG4", "BR1", "BG4_1B09_B1", SLX26997_PEAKS)],
    "6C5":  [("CM",  "BR2", "CM_6C5_BR2",  SLX28240_PEAKS)],
}


def get_peak_file(peaks_dir, sample, caller):
    if caller == "seacr":
        p = os.path.join(peaks_dir, "seacr", f"{sample}.stringent.bed")
    else:
        p = os.path.join(peaks_dir, "macs2", f"{sample}_peaks.narrowPeak")
    return p if os.path.exists(p) else None


def filter_chr(peak_file, tmp_dir, tag):
    if peak_file is None:
        return None
    out = os.path.join(tmp_dir, os.path.basename(peak_file) + f".{tag}.chr.bed")
    with open(peak_file) as fi, open(out, "w") as fo:
        for line in fi:
            if line.startswith("chr"):
                fo.write(line)
    return out if os.path.getsize(out) > 0 else None


def bedtools_hit_names(bed_a, bed_b):
    if not bed_b:
        return set()
    try:
        res = subprocess.run(
            ["bedtools", "intersect", "-a", bed_a, "-b", bed_b, "-wa", "-u"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
        )
    except subprocess.CalledProcessError:
        return set()
    hits = set()
    for line in res.stdout.decode().strip().split("\n"):
        if line:
            hits.add(line.split("\t")[3])
    return hits


# ── Load baseline (deduplicated per well x junction) ──────────────────────────
affected_wells = set(EXCLUDED_REPS.keys())
baseline = OrderedDict()   # (well, junction_id) -> row dict

with open(BASELINE_TSV) as f:
    reader = csv.DictReader(f, delimiter="\t")
    for row in reader:
        if row["well"] not in affected_wells:
            continue
        key = (row["well"], row["junction_id"])
        if key not in baseline:
            baseline[key] = row

print(f"Baseline junction rows for the 12 affected wells: {len(baseline)}")

# ── For each affected well, evaluate the excluded replicate(s) ───────────────
results = []

with tempfile.TemporaryDirectory() as tmp_dir:
    for (well, junction_id), row in baseline.items():
        excl_list = EXCLUDED_REPS[well]

        old_gold = row["gold_standard"] == "True"
        old_frac = float(row["frac_reps_with_peak"])
        old_n_gold = int(row["n_gold_reps"])
        old_n_hit = int(row["n_reps_with_peak"])

        name = "|".join([
            row["junction_id"], row["junction_loc"],
            row["read_support"], row["orientation"],
        ])
        region_line = "\t".join([
            row["chrom"], row["region_start"], row["region_end"], name, ".", "."
        ]) + "\n"
        region_bed = os.path.join(tmp_dir, f"{well}_{junction_id}.bed")
        with open(region_bed, "w") as fo:
            fo.write(region_line)

        for assay, rep, sample, peaks_dir in excl_list:
            seacr_raw = get_peak_file(peaks_dir, sample, "seacr")
            macs2_raw = get_peak_file(peaks_dir, sample, "macs2")
            evaluable = (seacr_raw is not None) or (macs2_raw is not None)

            if not evaluable:
                results.append({
                    "well": well, "junction_id": junction_id,
                    "chrom": row["chrom"], "region_start": row["region_start"],
                    "region_end": row["region_end"], "junction_loc": row["junction_loc"],
                    "excluded_sample": sample,
                    "excluded_has_peak": "N/A (no peak calls exist)",
                    "old_n_gold_reps": old_n_gold, "old_n_reps_with_peak": old_n_hit,
                    "old_frac": round(old_frac, 3), "old_gold_standard": old_gold,
                    "new_n_gold_reps": "N/A", "new_n_reps_with_peak": "N/A",
                    "new_frac": "N/A", "new_gold_standard": "N/A",
                    "category": "NOT_EVALUABLE (excluded sample has no peak calls)",
                })
                continue

            seacr_f = filter_chr(seacr_raw, tmp_dir, f"{sample}_s")
            macs2_f = filter_chr(macs2_raw, tmp_dir, f"{sample}_m")
            seacr_hits = bedtools_hit_names(region_bed, seacr_f)
            macs2_hits = bedtools_hit_names(region_bed, macs2_f)
            has_peak = (name in seacr_hits) or (name in macs2_hits)

            new_n_gold = old_n_gold + 1
            new_n_hit = old_n_hit + (1 if has_peak else 0)
            new_frac = new_n_hit / new_n_gold
            new_gold = new_frac >= GOLD_STANDARD_THR

            if old_gold and new_gold:
                category = "STILL_GOLD"
            elif old_gold and not new_gold:
                category = "LOST_GOLD"
            elif not old_gold and new_gold:
                category = "NEWLY_GOLD"
            else:
                category = "STILL_NOT_GOLD"

            results.append({
                "well": well, "junction_id": junction_id,
                "chrom": row["chrom"], "region_start": row["region_start"],
                "region_end": row["region_end"], "junction_loc": row["junction_loc"],
                "excluded_sample": sample,
                "excluded_has_peak": has_peak,
                "old_n_gold_reps": old_n_gold, "old_n_reps_with_peak": old_n_hit,
                "old_frac": round(old_frac, 3), "old_gold_standard": old_gold,
                "new_n_gold_reps": new_n_gold, "new_n_reps_with_peak": new_n_hit,
                "new_frac": round(new_frac, 3), "new_gold_standard": new_gold,
                "category": category,
            })

# ── Write comparison TSV ───────────────────────────────────────────────────────
header = [
    "well", "junction_id", "chrom", "region_start", "region_end", "junction_loc",
    "excluded_sample", "excluded_has_peak",
    "old_n_gold_reps", "old_n_reps_with_peak", "old_frac", "old_gold_standard",
    "new_n_gold_reps", "new_n_reps_with_peak", "new_frac", "new_gold_standard",
    "category",
]
with open(OUT_TSV, "w") as fo:
    fo.write("\t".join(header) + "\n")
    for r in results:
        fo.write("\t".join(str(r[h]) for h in header) + "\n")

print(f"\nComparison rows written: {len(results)} -> {OUT_TSV}")

# ── Summary ────────────────────────────────────────────────────────────────────
cat_counts = defaultdict(int)
for r in results:
    cat_counts[r["category"]] += 1

print("\nCategory breakdown (per junction):")
for cat in ["STILL_GOLD", "NEWLY_GOLD", "LOST_GOLD", "STILL_NOT_GOLD",
            "NOT_EVALUABLE (excluded sample has no peak calls)"]:
    print(f"  {cat}: {cat_counts.get(cat, 0)}")

n_gold_already = sum(1 for r in results if r["old_gold_standard"] is True)
print(f"\nOf the {len(results)} junctions in these 12 wells, "
      f"{n_gold_already} were ALREADY gold-standard using the current (evaluable) replicates.")
print("For the 11 BG4_BR1-affected wells (no SLX-26997 peak calls at low depth), "
      "gold-standard status cannot be re-evaluated with the excluded replicate.")
print("For well 6C5 (CM_BR2 excluded), the extra replicate's contribution was directly tested.")

print("\nDONE.")
