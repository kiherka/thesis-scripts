#!/usr/bin/env python3
"""
Insert specificity re-analysis: violin plots, per-insert replicate box plots,
and KRAS-locus-normalised CPM.

Extends analyse_insert_specificity.py (in ../insert_specificity_analysis/):
  1. Redraws the self-vs-others "difference" distributions as VIOLIN plots
     (instead of box plots).
  2. Draws, for EACH of the 120 gold-standard insert junctions, a box plot
     with every individual biological replicate value marked as a point
     (one PDF, one page per insert, per assay).
  3. Normalises mean/peak CPM at each insert to the mean/peak CPM at a fixed
     reference locus: chr12:25,250,600-25,251,600 (KRAS).
       - Each cell line's own integrated genome may have additional inserts
         upstream of this locus (on chr12), which shift its coordinate by
         the length of every such insert's consensus sequence. The shift
         for a given well is computed from ALL of that well's junctions in
         SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined/
         SPLINK_{well}.junctions.bed (not just the 120 gold-standard ones),
         summing consensus_len for every junction on chr12 with
         start < 25,250,600.
       - Normalisation is per replicate, per assay: insert_signal_rep /
         KRAS_signal_rep (same replicate, same assay), then averaged.
  4. Repeats the entire self-vs-others specificity analysis using the
     normalised values.

Outputs (this folder), each produced twice - "_raw" and "_normalised":
  specificity_<raw|normalised>.tsv
  self_vs_others_boxplots_<raw|normalised>.pdf
  differences_violin_<raw|normalised>.pdf
  per_insert_replicate_boxplots_<raw|normalised>.pdf   (120 pages)
"""

import csv
import os
import re
from collections import defaultdict

import numpy as np
import pyBigWig
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# ── Paths ──────────────────────────────────────────────────────────────────────
ORIGINAL_TSV = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/gold_standard_junctions_bg4.tsv"
JUNCTIONS_BED_DIR = "/scratche/slow/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

SLX26997_DIR = "/scratche/slow/sblab/herka01/SLX-26997"
SLX27843_DIR = "/scratche/slow/sblab/herka01/SLX-27843"
SLX28240_DIR = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"

MIN_MAPPED_READS = 1_000_000
ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}

KRAS_CHROM = "chr12"
KRAS_START = 25250600
KRAS_END = 25251600


# ── Well normalisation + SLX-26997 padded-well lookup ─────────────────────────
def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well


_slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
_raw_26997_by_norm = {}
for _f in os.listdir(os.path.join(SLX26997_DIR, "stats")):
    _m = _slx26997_bg4_pat.match(_f)
    if _m:
        _raw_26997_by_norm[normalise_well(_m.group(1))] = _m.group(1)


def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (SLX-26997/SLX-27843 keep
    # these permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    # Fallback: SLX-28240's rmDups.txt is a Snakemake temp() file deleted
    # after the pipeline finished. The bigwig_cpm rule's log records the
    # post-dedup pysam mapped-read count before running bamCoverage.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def collect_replicates(well_norm, assay):
    reps = []
    if assay == "BG4":
        raw = _raw_26997_by_norm.get(well_norm)
        if raw:
            reps.append({
                "label": "SLX26997:B1", "sample": f"BG4_{raw}_B1",
                "bw_dir": os.path.join(SLX26997_DIR, "bigwigs"),
                "stats_dir": os.path.join(SLX26997_DIR, "stats"),
                "base_dir": SLX26997_DIR,
            })
    if assay in ("BG4", "CUTAC"):
        sample = f"{assay}_{well_norm}_B1"
        stats_dir = os.path.join(SLX27843_DIR, "stats")
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": "SLX27843:B1", "sample": sample,
                "bw_dir": os.path.join(SLX27843_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX27843_DIR,
            })
    stats_dir = os.path.join(SLX28240_DIR, "stats")
    for n in (1, 2, 3):
        sample = f"{assay}_{well_norm}_BR{n}"
        if os.path.exists(os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")):
            reps.append({
                "label": f"SLX28240:BR{n}", "sample": sample,
                "bw_dir": os.path.join(SLX28240_DIR, "bigwigs"),
                "stats_dir": stats_dir,
                "base_dir": SLX28240_DIR,
            })
    passing = []
    for r in reps:
        n = get_dedup_reads(r["base_dir"], r["sample"])
        if n is not None and n >= MIN_MAPPED_READS:
            bw_path = os.path.join(r["bw_dir"], f"{r['sample']}.cpm.bw")
            if os.path.exists(bw_path) and os.path.getsize(bw_path) > 0:
                r["bw_path"] = bw_path
                passing.append(r)
    return passing


def get_kras_shift(well):
    """Sum consensus_len for every junction on chr12 upstream of the KRAS
    locus in this well's OWN junctions.bed (all detected junctions, not just
    the gold-standard subset), giving the coordinate shift needed to find
    the KRAS locus in this well's integrated genome."""
    path = os.path.join(JUNCTIONS_BED_DIR, f"SPLINK_{well}.junctions.bed")
    if not os.path.exists(path):
        return 0
    shift = 0
    with open(path) as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            chrom, start, consensus_len = parts[0], int(parts[1]), int(parts[6])
            if chrom == KRAS_CHROM and start < KRAS_START:
                shift += consensus_len
    return shift


def query_region(bw, chrom, start, end):
    chroms = bw.chroms()
    if chrom not in chroms:
        return None, None
    chrom_len = chroms[chrom]
    s, e = max(0, start), min(end, chrom_len)
    if e <= s:
        return None, None
    mean_v = bw.stats(chrom, s, e, type="mean")[0]
    max_v = bw.stats(chrom, s, e, type="max")[0]
    return (mean_v if mean_v is not None else 0.0,
            max_v if max_v is not None else 0.0)


def main():
    with open(ORIGINAL_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Original gold-standard BG4 junctions loaded: {len(rows)}")

    junctions = [
        {"well": r["cell_line"], "junction_id": r["junction_id"], "chrom": r["chrom"],
         "start": int(r["region_start"]), "end": int(r["region_end"])}
        for r in rows
    ]
    all_wells = sorted({j["well"] for j in junctions})
    print(f"Unique wells (cell lines): {len(all_wells)}")

    # ── Per-well KRAS coordinate shift ────────────────────────────────────────
    kras_shift = {w: get_kras_shift(w) for w in all_wells}
    n_shifted = sum(1 for s in kras_shift.values() if s > 0)
    print(f"Wells needing a KRAS coordinate shift (chr12 insert(s) upstream): {n_shifted}/{len(all_wells)}")
    for w, s in kras_shift.items():
        if s > 0:
            print(f"  {w}: shift = +{s} bp -> KRAS at {KRAS_CHROM}:{KRAS_START+s}-{KRAS_END+s}")

    # ── Discover replicate bigwigs for every well x assay ─────────────────────
    well_bws = {assay: {} for assay in ASSAYS}
    for assay in ASSAYS:
        for well in all_wells:
            reps = collect_replicates(well, assay)
            if reps:
                well_bws[assay][well] = reps
        print(f"  {assay}: {len(well_bws[assay])}/{len(all_wells)} wells have data")

    # ── Extract per-replicate signal: insert junctions (all 120, for the ─────
    # "others" comparison) + this well's own KRAS locus, from each bigwig
    # opened exactly once.
    # raw_rep_values[assay][well][junction_key] = [(mean, peak), ...] per rep
    # kras_rep_values[assay][well] = [(mean, peak), ...] per rep
    raw_rep_values = {a: defaultdict(lambda: defaultdict(list)) for a in ASSAYS}
    kras_rep_values = {a: defaultdict(list) for a in ASSAYS}

    for assay in ASSAYS:
        for well, reps in well_bws[assay].items():
            shift = kras_shift.get(well, 0)
            k_start, k_end = KRAS_START + shift, KRAS_END + shift
            for rep in reps:
                bw = pyBigWig.open(rep["bw_path"])
                try:
                    for j in junctions:
                        key = (j["well"], j["junction_id"])
                        mean_v, max_v = query_region(bw, j["chrom"], j["start"], j["end"])
                        if mean_v is not None:
                            raw_rep_values[assay][well][key].append((mean_v, max_v))
                    k_mean, k_max = query_region(bw, KRAS_CHROM, k_start, k_end)
                    if k_mean is not None:
                        kras_rep_values[assay][well].append((k_mean, k_max))
                finally:
                    bw.close()
        n_pairs = sum(len(v) for v in raw_rep_values[assay].values())
        print(f"  {assay}: signal extracted for {n_pairs} (well, junction) pairs")

    # ── Aggregate to per-well-per-junction mean-of-reps (raw + normalised) ────
    # signal_raw[assay][well][key]  = (mean_cpm, peak_cpm)   averaged over reps
    # signal_norm[assay][well][key] = (mean_cpm, peak_cpm)   averaged ratio-to-KRAS over reps
    signal_raw = {a: defaultdict(dict) for a in ASSAYS}
    signal_norm = {a: defaultdict(dict) for a in ASSAYS}
    # per-replicate values kept for the per-insert box+dots plots
    per_rep_raw = {a: defaultdict(dict) for a in ASSAYS}    # [assay][well][key] = [mean_rep1, mean_rep2, ...] (means only, for plotting)
    per_rep_norm = {a: defaultdict(dict) for a in ASSAYS}

    for assay in ASSAYS:
        for well, by_key in raw_rep_values[assay].items():
            kras_vals = kras_rep_values[assay].get(well, [])
            n_reps = len(well_bws[assay][well])
            for key, vals in by_key.items():
                means = [v[0] for v in vals]
                peaks = [v[1] for v in vals]
                signal_raw[assay][well][key] = (float(np.mean(means)), float(np.mean(peaks)))
                per_rep_raw[assay][well][key] = means

                if kras_vals and len(kras_vals) == len(vals):
                    norm_means = [v[0] / k[0] if k[0] > 0 else np.nan for v, k in zip(vals, kras_vals)]
                    norm_peaks = [v[1] / k[1] if k[1] > 0 else np.nan for v, k in zip(vals, kras_vals)]
                    norm_means = [x for x in norm_means if not np.isnan(x)]
                    norm_peaks = [x for x in norm_peaks if not np.isnan(x)]
                    if norm_means:
                        signal_norm[assay][well][key] = (float(np.mean(norm_means)), float(np.mean(norm_peaks)))
                        per_rep_norm[assay][well][key] = norm_means

    # ── Build self-vs-others comparison rows, for both raw and normalised ─────
    def build_rows(signal_dict):
        out = []
        for j in junctions:
            well, junction_id = j["well"], j["junction_id"]
            key = (well, junction_id)
            for assay in ASSAYS:
                self_vals = signal_dict[assay].get(well, {}).get(key)
                others_means, others_peaks = [], []
                for other_well in all_wells:
                    if other_well == well:
                        continue
                    v = signal_dict[assay].get(other_well, {}).get(key)
                    if v is not None:
                        others_means.append(v[0])
                        others_peaks.append(v[1])
                if self_vals is None or not others_means:
                    continue
                self_mean, self_peak = self_vals
                med_om, med_op = float(np.median(others_means)), float(np.median(others_peaks))
                out.append({
                    "well": well, "junction_id": junction_id, "assay": assay,
                    "self_mean_cpm": round(self_mean, 5), "self_peak_cpm": round(self_peak, 5),
                    "n_other_wells": len(others_means),
                    "others_median_mean_cpm": round(med_om, 5),
                    "others_median_peak_cpm": round(med_op, 5),
                    "diff_mean_cpm": round(self_mean - med_om, 5),
                    "diff_peak_cpm": round(self_peak - med_op, 5),
                })
        return out

    rows_raw = build_rows(signal_raw)
    rows_norm = build_rows(signal_norm)

    header = ["well", "junction_id", "assay", "self_mean_cpm", "self_peak_cpm",
              "n_other_wells", "others_median_mean_cpm", "others_median_peak_cpm",
              "diff_mean_cpm", "diff_peak_cpm"]

    def write_tsv(path, out_rows):
        with open(path, "w") as fo:
            fo.write("\t".join(header) + "\n")
            for r in out_rows:
                fo.write("\t".join(str(r[h]) for h in header) + "\n")

    write_tsv(os.path.join(OUT_DIR, "specificity_raw.tsv"), rows_raw)
    write_tsv(os.path.join(OUT_DIR, "specificity_normalised.tsv"), rows_norm)
    print(f"\nWritten specificity_raw.tsv ({len(rows_raw)} rows) and "
          f"specificity_normalised.tsv ({len(rows_norm)} rows)")

    # ── Plot helpers ───────────────────────────────────────────────────────────
    def plot_self_vs_others_boxplots(out_rows, suffix, ylabel_suffix):
        fig, axes = plt.subplots(2, 4, figsize=(16, 8), constrained_layout=True)
        for col, assay in enumerate(ASSAYS):
            ar = [r for r in out_rows if r["assay"] == assay]
            self_means = [r["self_mean_cpm"] for r in ar]
            other_means = [r["others_median_mean_cpm"] for r in ar]
            self_peaks = [r["self_peak_cpm"] for r in ar]
            other_peaks = [r["others_median_peak_cpm"] for r in ar]

            ax = axes[0, col]
            bp = ax.boxplot([self_means, other_means], tick_labels=["Self", "Others"],
                             patch_artist=True, showfliers=False, widths=0.6)
            for patch, color in zip(bp["boxes"], [ASSAY_COLORS[assay], "#aaaaaa"]):
                patch.set_facecolor(color); patch.set_alpha(0.7)
            ax.set_title(f"{assay}: mean {ylabel_suffix} (n={len(ar)})", fontsize=9)
            ax.tick_params(labelsize=7)
            ax.spines[["top", "right"]].set_visible(False)

            ax = axes[1, col]
            bp = ax.boxplot([self_peaks, other_peaks], tick_labels=["Self", "Others"],
                             patch_artist=True, showfliers=False, widths=0.6)
            for patch, color in zip(bp["boxes"], [ASSAY_COLORS[assay], "#aaaaaa"]):
                patch.set_facecolor(color); patch.set_alpha(0.7)
            ax.set_title(f"{assay}: peak {ylabel_suffix} (n={len(ar)})", fontsize=9)
            ax.tick_params(labelsize=7)
            ax.spines[["top", "right"]].set_visible(False)

        fig.suptitle(f"Insert-site signal (self) vs. same locus in other 83 cell lines ({suffix})",
                     fontsize=11, fontweight="bold")
        path = os.path.join(OUT_DIR, f"self_vs_others_boxplots_{suffix}.pdf")
        fig.savefig(path)
        plt.close(fig)
        print(f"Saved: {path}")

    def plot_differences_violin(out_rows, suffix, ylabel_suffix):
        fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
        for ax, metric, title in zip(axes, ["diff_mean_cpm", "diff_peak_cpm"],
                                      [f"Mean {ylabel_suffix} difference", f"Peak {ylabel_suffix} difference"]):
            data = [[r[metric] for r in out_rows if r["assay"] == assay] for assay in ASSAYS]
            parts = ax.violinplot(data, showmedians=True, showextrema=True)
            for pc, assay in zip(parts["bodies"], ASSAYS):
                pc.set_facecolor(ASSAY_COLORS[assay])
                pc.set_alpha(0.7)
            ax.set_xticks(range(1, len(ASSAYS) + 1))
            ax.set_xticklabels(ASSAYS)
            ax.axhline(0, color="black", lw=0.8, linestyle="--")
            ax.set_title(f"{title}\n(self - median of other 83 cell lines)", fontsize=10)
            ax.set_ylabel(f"{ylabel_suffix} difference", fontsize=9)
            ax.tick_params(labelsize=8)
            ax.spines[["top", "right"]].set_visible(False)

        fig.suptitle(f"Insert specificity ({suffix}): signal at insert site vs. same locus without the insert\n"
                     "(120 gold-standard junctions)", fontsize=11, fontweight="bold")
        path = os.path.join(OUT_DIR, f"differences_violin_{suffix}.pdf")
        fig.savefig(path)
        plt.close(fig)
        print(f"Saved: {path}")

    def plot_per_insert_replicate_boxplots(per_rep_dict, suffix, ylabel_suffix):
        path = os.path.join(OUT_DIR, f"per_insert_replicate_boxplots_{suffix}.pdf")
        with PdfPages(path) as pdf:
            for j in junctions:
                well, junction_id = j["well"], j["junction_id"]
                key = (well, junction_id)
                fig, ax = plt.subplots(figsize=(7, 4))
                box_data, positions, colors, rep_points = [], [], [], []
                for i, assay in enumerate(ASSAYS):
                    vals = per_rep_dict[assay].get(well, {}).get(key, [])
                    box_data.append(vals if vals else [np.nan])
                    positions.append(i + 1)
                    colors.append(ASSAY_COLORS[assay])
                    rep_points.append(vals)

                bp = ax.boxplot(box_data, positions=positions, widths=0.5,
                                 patch_artist=True, showfliers=False)
                for patch, color in zip(bp["boxes"], colors):
                    patch.set_facecolor(color); patch.set_alpha(0.5)

                rng = np.random.default_rng(42)
                for i, vals in enumerate(rep_points):
                    if not vals:
                        continue
                    jitter = rng.uniform(-0.08, 0.08, size=len(vals))
                    ax.scatter(np.full(len(vals), positions[i]) + jitter, vals,
                               color=colors[i], edgecolor="black", linewidth=0.4,
                               s=28, zorder=3)

                ax.set_xticks(positions)
                ax.set_xticklabels(ASSAYS)
                ax.set_ylabel(f"Mean {ylabel_suffix} (per replicate)", fontsize=8)
                ax.set_title(f"{well}  {junction_id}", fontsize=9)
                ax.tick_params(labelsize=7)
                ax.spines[["top", "right"]].set_visible(False)
                plt.tight_layout()
                pdf.savefig(fig)
                plt.close(fig)
        print(f"Saved: {path}  ({len(junctions)} pages)")

    # ── Generate all plots: raw ────────────────────────────────────────────────
    plot_self_vs_others_boxplots(rows_raw, "raw", "CPM")
    plot_differences_violin(rows_raw, "raw", "CPM")
    plot_per_insert_replicate_boxplots(per_rep_raw, "raw", "CPM")

    # ── Generate all plots: normalised ─────────────────────────────────────────
    plot_self_vs_others_boxplots(rows_norm, "normalised", "CPM/KRAS")
    plot_differences_violin(rows_norm, "normalised", "CPM/KRAS")
    plot_per_insert_replicate_boxplots(per_rep_norm, "normalised", "CPM/KRAS")

    # ── Summary ────────────────────────────────────────────────────────────────
    for label, out_rows in [("RAW", rows_raw), ("NORMALISED", rows_norm)]:
        print(f"\nMedian difference (self - median(others)) per assay [{label}]:")
        for assay in ASSAYS:
            ar = [r for r in out_rows if r["assay"] == assay]
            if not ar:
                continue
            md = np.median([r["diff_mean_cpm"] for r in ar])
            mp = np.median([r["diff_peak_cpm"] for r in ar])
            n_hi = sum(1 for r in ar if r["diff_mean_cpm"] > 0)
            print(f"  {assay}: median diff mean = {md:.4f}, median diff peak = {mp:.4f}, "
                  f"{n_hi}/{len(ar)} higher than others (mean)")

    print("\nDONE.")


if __name__ == "__main__":
    main()
