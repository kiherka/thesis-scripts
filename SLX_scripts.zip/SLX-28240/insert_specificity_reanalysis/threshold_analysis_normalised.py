#!/usr/bin/env python3
"""
Threshold analysis on KRAS-normalised mean CPM (specificity_normalised.tsv).

For each of the 120 gold-standard insert junctions and each assay (BG4, CM,
CUTAC, 27ac), the mean CPM at the insert has already been normalised to
that same replicate's CPM at the KRAS locus (self_mean_cpm column).

Reports:
  - per assay: how many / which inserts have self_mean_cpm > 0.20
  - across all assays: how many / which inserts have self_mean_cpm > 0.20
    in EVERY one of BG4, CM, CUTAC and 27ac simultaneously

Output (this folder): normalised_threshold_0.20.tsv
"""

import csv
import os
from collections import defaultdict

IN_TSV = "/scratche/slow/sblab/herka01/SLX-28240/insert_specificity_reanalysis/specificity_normalised.tsv"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_TSV = os.path.join(OUT_DIR, "normalised_threshold_0.20.tsv")

ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
THRESHOLD = 0.20


def main():
    with open(IN_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Loaded {len(rows)} rows from {IN_TSV}")

    # values[(well, junction_id)][assay] = self_mean_cpm
    values = defaultdict(dict)
    for row in rows:
        key = (row["well"], row["junction_id"])
        values[key][row["assay"]] = float(row["self_mean_cpm"])

    print(f"Unique inserts: {len(values)}")

    # ── Per-assay ──────────────────────────────────────────────────────────────
    above_by_assay = {assay: [] for assay in ASSAYS}
    for key, assay_vals in values.items():
        for assay in ASSAYS:
            v = assay_vals.get(assay)
            if v is not None and v > THRESHOLD:
                above_by_assay[assay].append((key, v))

    print(f"\nInserts with normalised mean CPM > {THRESHOLD} (per assay):")
    for assay in ASSAYS:
        hits = sorted(above_by_assay[assay], key=lambda x: -x[1])
        print(f"\n{assay}: {len(hits)}/{len(values)} inserts")
        for (well, junction_id), v in hits:
            print(f"    {well}\t{junction_id}\t{v:.4f}")

    # ── All assays simultaneously ─────────────────────────────────────────────
    above_all = []
    for key, assay_vals in values.items():
        if all(assay_vals.get(assay, 0.0) > THRESHOLD for assay in ASSAYS):
            above_all.append(key)

    print(f"\nInserts with normalised mean CPM > {THRESHOLD} in ALL 4 assays "
          f"(BG4, CM, CUTAC, 27ac simultaneously): {len(above_all)}/{len(values)}")
    for well, junction_id in sorted(above_all):
        vals_str = ", ".join(f"{a}={values[(well, junction_id)].get(a, float('nan')):.4f}" for a in ASSAYS)
        print(f"    {well}\t{junction_id}\t{vals_str}")

    # ── Write output TSV ───────────────────────────────────────────────────────
    header = ["well", "junction_id"] + [f"{a}_normalised_mean_cpm" for a in ASSAYS] + \
              [f"{a}_above_{THRESHOLD}" for a in ASSAYS] + ["above_in_all_assays"]
    with open(OUT_TSV, "w") as fo:
        fo.write("\t".join(header) + "\n")
        for key in sorted(values):
            well, junction_id = key
            assay_vals = values[key]
            row_out = [well, junction_id]
            row_out += [f"{assay_vals.get(a, ''):.4f}" if a in assay_vals else "" for a in ASSAYS]
            row_out += ["True" if assay_vals.get(a, 0.0) > THRESHOLD else "False" for a in ASSAYS]
            row_out += ["True" if key in above_all else "False"]
            fo.write("\t".join(row_out) + "\n")

    print(f"\nWritten: {OUT_TSV}")
    print("\nDONE.")


if __name__ == "__main__":
    main()
