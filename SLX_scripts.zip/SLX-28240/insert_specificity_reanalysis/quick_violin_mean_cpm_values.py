#!/usr/bin/env python3
"""
Violin plot of mean CPM signal (not differences) at each insert junction:
self (insert-containing cell line) vs. the same locus in the other 83 cell
lines that do NOT contain this insert - per assay.

Uses the already-computed data from
../insert_specificity_analysis/insert_specificity.tsv (raw CPM, no bigwig
re-extraction needed).

Output (this folder): mean_cpm_self_vs_others_violin.pdf
"""

import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

IN_TSV = "/scratche/slow/sblab/herka01/SLX-28240/insert_specificity_analysis/insert_specificity.tsv"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}


def main():
    with open(IN_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Loaded {len(rows)} rows from {IN_TSV}")

    fig, axes = plt.subplots(1, 4, figsize=(16, 4.5), constrained_layout=True)
    for ax, assay in zip(axes, ASSAYS):
        ar = [r for r in rows if r["assay"] == assay]
        self_vals = [float(r["self_mean_cpm"]) for r in ar]
        other_vals = [float(r["others_median_mean_cpm"]) for r in ar]

        parts = ax.violinplot([self_vals, other_vals], showmedians=True, showextrema=True)
        for pc, color in zip(parts["bodies"], [ASSAY_COLORS[assay], "#888888"]):
            pc.set_facecolor(color)
            pc.set_alpha(0.7)

        ax.set_xticks([1, 2])
        ax.set_xticklabels(["Self\n(insert)", "Others\n(median, no insert)"], fontsize=8)
        ax.set_ylabel("Mean CPM", fontsize=9)
        ax.set_title(f"{assay} (n={len(ar)})", fontsize=10, fontweight="bold")
        ax.tick_params(labelsize=7)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle("Mean CPM at insert-containing sites vs. same locus in the other 83 cell lines\n"
                 "(120 gold-standard junctions, raw CPM)", fontsize=11, fontweight="bold")
    out_path = os.path.join(OUT_DIR, "mean_cpm_self_vs_others_violin.pdf")
    fig.savefig(out_path)
    plt.close(fig)
    print(f"Saved: {out_path}")


if __name__ == "__main__":
    main()
