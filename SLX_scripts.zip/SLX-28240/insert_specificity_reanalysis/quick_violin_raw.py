#!/usr/bin/env python3
"""
Quick violin-plot redraw of the RAW (non-normalised) insert-specificity
differences, using the already-computed data from
../insert_specificity_analysis/insert_specificity.tsv (no bigwig
re-extraction needed - this data was already extracted in a prior run).

The KRAS-normalised equivalent requires fresh bigwig extraction and is
produced by analyse_insert_specificity_v2.py (run separately, much slower).

Output (this folder): differences_violin_raw.pdf
"""

import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

IN_TSV = "/scratche/slow/sblab/herka01/SLX-28240/insert_specificity_analysis/insert_specificity.tsv"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

ASSAYS = ["BG4", "CM", "CUTAC", "27ac"]
ASSAY_COLORS = {"BG4": "#2166ac", "CM": "#cb181d", "CUTAC": "#238b45", "27ac": "#e6a817"}


def main():
    with open(IN_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Loaded {len(rows)} rows from {IN_TSV}")

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
    for ax, metric, title in zip(axes, ["diff_mean_cpm", "diff_peak_cpm"],
                                  ["Mean CPM difference", "Peak CPM difference"]):
        data = [[float(r[metric]) for r in rows if r["assay"] == assay] for assay in ASSAYS]
        parts = ax.violinplot(data, showmedians=True, showextrema=True)
        for pc, assay in zip(parts["bodies"], ASSAYS):
            pc.set_facecolor(ASSAY_COLORS[assay])
            pc.set_alpha(0.7)
        ax.set_xticks(range(1, len(ASSAYS) + 1))
        ax.set_xticklabels(ASSAYS)
        ax.axhline(0, color="black", lw=0.8, linestyle="--")
        ax.set_title(f"{title}\n(self - median of other 83 cell lines)", fontsize=10)
        ax.set_ylabel("CPM difference", fontsize=9)
        ax.tick_params(labelsize=8)
        ax.spines[["top", "right"]].set_visible(False)

    fig.suptitle("Insert specificity (raw CPM): signal at insert site vs. same locus without the insert\n"
                 "(120 gold-standard junctions)", fontsize=11, fontweight="bold")
    out_path = os.path.join(OUT_DIR, "differences_violin_raw.pdf")
    fig.savefig(out_path)
    plt.close(fig)
    print(f"Saved: {out_path}")


if __name__ == "__main__":
    main()
