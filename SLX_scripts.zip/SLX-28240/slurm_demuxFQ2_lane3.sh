#!/bin/bash

mkdir demultiplexed_lane3

sbatch --time 1-23:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-28240_lostreads_lane3_r1.fq.gz  -o ./demultiplexed_lane3  -s SLX-28240_summary2_demuxFQ_lane3_r1.txt r1.txt SLX-28240.UnspecifiedIndex.23N5K2LT4.s_6.r_1.fq.gz"

sbatch --time 1-23:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -R -r 0.01 -l 9 -b SLX-28240_lostreads_lane3_r2.fq.gz -o ./demultiplexed_lane3 -s SLX-28240_summary2_demuxFQ_lane3_r2.txt r2.txt  SLX-28240.UnspecifiedIndex.23N5K2LT4.s_6.r_2.fq.gz"
