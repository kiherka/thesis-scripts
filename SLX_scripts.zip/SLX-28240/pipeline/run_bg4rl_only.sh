#!/bin/bash
source /home/herka01/miniforge3/etc/profile.d/conda.sh
conda activate snakemake
cd /scratche/slow/sblab/herka01/SLX-28240/pipeline
mkdir -p logs/slurm
LOG="logs/slurm/smk_bg4rl_$(date +%Y%m%d_%H%M%S).log"
echo "BG4_RL contig-genome realignment started at $(date)" | tee "$LOG"
TARGETS="stats/BG4_RL_NEG_T1.r1.hg38.sort.stats stats/BG4_RL_NEG_T2.r1.hg38.sort.stats \
  stats/BG4_RL_NEG_T3.r1.hg38.sort.stats stats/BG4_RL_NEG_T4.r1.hg38.sort.stats \
  stats/BG4_RL_POS_T1.r1.hg38.sort.stats stats/BG4_RL_POS_T2.r1.hg38.sort.stats \
  stats/BG4_RL_POS_T3.r1.hg38.sort.stats stats/BG4_RL_POS_T4.r1.hg38.sort.stats \
  bigwigs/BG4_RL_NEG_T1.cpm.bw bigwigs/BG4_RL_NEG_T2.cpm.bw \
  bigwigs/BG4_RL_NEG_T3.cpm.bw bigwigs/BG4_RL_NEG_T4.cpm.bw \
  bigwigs/BG4_RL_POS_T1.cpm.bw bigwigs/BG4_RL_POS_T2.cpm.bw \
  bigwigs/BG4_RL_POS_T3.cpm.bw bigwigs/BG4_RL_POS_T4.cpm.bw \
  peaks/macs2/BG4_RL_NEG_T1_peaks.narrowPeak peaks/macs2/BG4_RL_NEG_T2_peaks.narrowPeak \
  peaks/macs2/BG4_RL_NEG_T3_peaks.narrowPeak peaks/macs2/BG4_RL_NEG_T4_peaks.narrowPeak \
  peaks/macs2/BG4_RL_POS_T1_peaks.narrowPeak peaks/macs2/BG4_RL_POS_T2_peaks.narrowPeak \
  peaks/macs2/BG4_RL_POS_T3_peaks.narrowPeak peaks/macs2/BG4_RL_POS_T4_peaks.narrowPeak \
  peaks/seacr/BG4_RL_NEG_T1.stringent.bed peaks/seacr/BG4_RL_NEG_T2.stringent.bed \
  peaks/seacr/BG4_RL_NEG_T3.stringent.bed peaks/seacr/BG4_RL_NEG_T4.stringent.bed \
  peaks/seacr/BG4_RL_POS_T1.stringent.bed peaks/seacr/BG4_RL_POS_T2.stringent.bed \
  peaks/seacr/BG4_RL_POS_T3.stringent.bed peaks/seacr/BG4_RL_POS_T4.stringent.bed"
# NOTE: target files must precede --rerun-triggers (which takes nargs='+' and
# would otherwise swallow them as invalid trigger names).
snakemake $TARGETS --profile profile --latency-wait 120 --keep-going --rerun-triggers mtime \
  2>&1 | tee -a "$LOG"
echo "BG4_RL contig-genome realignment finished at $(date)" | tee -a "$LOG"
