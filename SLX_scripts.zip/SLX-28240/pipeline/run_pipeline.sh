#!/bin/bash
# Run the Snakemake master on the submit/login node (inside tmux/screen).
#
# Usage:
#   cd /scratche/slow/sblab/herka01/SLX-28240/pipeline
#   tmux new -s smk_28240
#   bash run_pipeline.sh
#   # Ctrl-b d  to detach; re-attach: tmux attach -t smk_28240
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

mkdir -p logs/slurm
LOG="logs/slurm/smk_master_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

snakemake --profile profile 2>&1 | tee "$LOG"
