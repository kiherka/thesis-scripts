#!/bin/bash
source /home/herka01/miniforge3/etc/profile.d/conda.sh
conda activate snakemake
cd /scratche/slow/sblab/herka01/SLX-28240/pipeline
mkdir -p logs/slurm
LOG="logs/slurm/smk_master_$(date +%Y%m%d_%H%M%S).log"
echo "Pipeline started at $(date) (peaks + bigwigs)" | tee "$LOG"
snakemake --profile profile --latency-wait 120 --keep-going --rerun-triggers mtime 2>&1 | tee -a "$LOG"
echo "Pipeline finished at $(date)" | tee -a "$LOG"
