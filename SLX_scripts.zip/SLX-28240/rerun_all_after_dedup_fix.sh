#!/bin/bash
# Master rerun script after fixing the dedup-reads filter bug.
# Runs all affected analyses sequentially (many are bigwig-heavy and slow on
# this NFS), each logging to its own folder.
set -uo pipefail
source /home/herka01/miniforge3/etc/profile.d/conda.sh
conda activate base

log() { echo "=== $(date '+%Y-%m-%d %H:%M:%S') : $1 ==="; }

log "1/8 debug_missing_replicates.py"
cd /scratche/slow/sblab/herka01/SLX-28240/peak_analysis
python3 debug_missing_replicates.py > debug_missing_replicates.rerun.log 2>&1

log "2/8 analyse_replicate_peaks.py"
cd /scratche/slow/sblab/herka01/SLX-28240/peak_analysis
python3 analyse_replicate_peaks.py > analyse_replicate_peaks.rerun.log 2>&1

log "3/8 extract_gold_standard_inserts.py"
cd /scratche/slow/sblab/herka01/SLX-28240/peak_analysis
python3 extract_gold_standard_inserts.py > extract_gold_standard_inserts.rerun.log 2>&1

log "4/8 check_structure_confirmation.py"
cd /scratche/slow/sblab/herka01/SLX-28240/structure_confirmation
python3 check_structure_confirmation.py > check_structure_confirmation.rerun.log 2>&1

log "5/8 extract_assay_signal_traces.py"
cd /scratche/slow/sblab/herka01/SLX-28240/structure_confirmation/signal_traces
python3 extract_assay_signal_traces.py > extract_assay_signal_traces.rerun.log 2>&1

log "6/8 analyse_insert_specificity.py"
cd /scratche/slow/sblab/herka01/SLX-28240/insert_specificity_analysis
python3 analyse_insert_specificity.py > analyse_insert_specificity.rerun.log 2>&1

log "7/8 analyse_insert_specificity_v2.py"
cd /scratche/slow/sblab/herka01/SLX-28240/insert_specificity_reanalysis
python3 analyse_insert_specificity_v2.py > analyse_insert_specificity_v2.rerun.log 2>&1

log "8/8 quick violin scripts (using refreshed insert_specificity.tsv)"
cd /scratche/slow/sblab/herka01/SLX-28240/insert_specificity_reanalysis
python3 quick_violin_raw.py > quick_violin_raw.rerun.log 2>&1
python3 quick_violin_mean_cpm_values.py > quick_violin_mean_cpm_values.rerun.log 2>&1

log "ALL DONE"
