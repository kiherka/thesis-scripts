#!/bin/bash

mkdir demultiplexed

sbatch --time 72:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -r 0.01 -l 9 -b  SLX-28240_lostreads_r1.fq.gz  -o ./demultiplexed  -s SLX-28240_summary2_demuxFQ_r1.txt r1.txt SLX-28240.UnspecifiedIndex.BXB58701-2815.s_1.r_1.fq.gz"

sbatch --time 72:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -t 1 -r 0.01 -l 9 -b SLX-28240_lostreads_r2.fq.gz -o ./demultiplexed -s SLX-28240_summary2_demuxFQ_r2.txt r2.txt  SLX-28240.UnspecifiedIndex.BXB58701-2815.s_1.r_2.fq.gz"