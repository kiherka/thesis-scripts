#!/bin/bash
# Wait for all demux summary files (lanes 1-5, r1+r2) to exist,
# then launch the Snakemake pipeline inside a new tmux session.
#
# Usage (run from login node, outside tmux):
#   bash /scratche/slow/sblab/herka01/SLX-28240/wait_and_launch.sh

set -euo pipefail

DEMUX_DIR="/scratche/slow/sblab/herka01/SLX-28240"
PIPELINE_DIR="/scratche/slow/sblab/herka01/SLX-28240/pipeline"
SESSION="smk_28240"

SUMMARY_FILES=()
for lane in 1 2 3 4 5; do
    SUMMARY_FILES+=("${DEMUX_DIR}/SLX-28240_summary2_demuxFQ_lane${lane}_r1.txt")
    SUMMARY_FILES+=("${DEMUX_DIR}/SLX-28240_summary2_demuxFQ_lane${lane}_r2.txt")
done

echo "[$(date)] Waiting for ${#SUMMARY_FILES[@]} summary files..."

while true; do
    missing=0
    for f in "${SUMMARY_FILES[@]}"; do
        if [[ ! -s "$f" ]]; then
            missing=$((missing + 1))
        fi
    done

    if [[ "$missing" -eq 0 ]]; then
        echo "[$(date)] All summary files present. Launching pipeline."
        break
    fi

    echo "[$(date)] Still waiting — ${missing} summary file(s) missing. Checking again in 5 min..."
    sleep 300
done

# Also wait for SLURM demux jobs to clear the queue
echo "[$(date)] Waiting for demux SLURM jobs to finish..."
while squeue -u "$USER" --noheader | grep -qv "faidx"; do
    echo "[$(date)] Jobs still in queue, waiting 2 min..."
    sleep 120
done
echo "[$(date)] Queue clear. Starting pipeline."

# Launch pipeline in a new tmux session
if tmux has-session -t "$SESSION" 2>/dev/null; then
    echo "tmux session '$SESSION' already exists — attaching pipeline there"
    tmux send-keys -t "$SESSION" "cd ${PIPELINE_DIR} && bash run_pipeline.sh" Enter
else
    tmux new-session -d -s "$SESSION" -c "$PIPELINE_DIR" \
        "bash run_pipeline.sh; echo 'Pipeline finished'; exec bash"
    echo "[$(date)] Pipeline launched in tmux session '$SESSION'."
    echo "Attach with:  tmux attach -t ${SESSION}"
fi
