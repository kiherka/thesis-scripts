#!/usr/bin/env python3
"""
Extract all gold-standard insert junctions from replicate_peak_summary.tsv.

replicate_peak_summary.tsv (produced by analyse_replicate_peaks.py) has one
row per (well x assay x replicate x junction). A junction is "gold-standard"
if a peak (SEACR or MACS2) was detected in >=75% of the BG4+CM replicates for
that well (see analyse_replicate_peaks.py GOLD_STANDARD_THR / GOLD_ASSAYS).
The gold_standard/frac_reps_with_peak/n_gold_reps/n_reps_with_peak columns
are identical across all rows sharing the same (well, junction_id), so this
script simply filters + deduplicates down to one row per gold-standard
insert junction.

Output:
  gold_standard_inserts.tsv - one row per (well, junction_id) with:
    well, chrom, region_start, region_end, junction_id, junction_loc,
    read_support, orientation, n_gold_reps, n_reps_with_peak,
    frac_reps_with_peak, bg4_cm_replicates_with_peak, cutac_replicates_with_peak
"""

import csv
import os
from collections import OrderedDict, defaultdict

IN_TSV  = "/scratche/slow/sblab/herka01/SLX-28240/peak_analysis/replicate_peak_summary.tsv"
OUT_TSV = "/scratche/slow/sblab/herka01/SLX-28240/peak_analysis/gold_standard_inserts.tsv"

HEADER = [
    "well", "chrom", "region_start", "region_end", "junction_id", "junction_loc",
    "read_support", "orientation", "n_gold_reps", "n_reps_with_peak",
    "frac_reps_with_peak", "bg4_cm_replicates_with_peak", "cutac_replicates_with_peak",
]


def main():
    rows_by_junction = OrderedDict()   # (well, junction_id) -> baseline row
    bg4cm_reps = defaultdict(list)     # (well, junction_id) -> [assay_replicate, ...]
    cutac_reps = defaultdict(list)

    n_total_rows = 0
    n_gold_rows = 0

    with open(IN_TSV) as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            n_total_rows += 1
            if row["gold_standard"] != "True":
                continue
            n_gold_rows += 1

            key = (row["well"], row["junction_id"])
            if key not in rows_by_junction:
                rows_by_junction[key] = row

            label = f"{row['assay']}_{row['replicate']}"
            if row["has_peak"] == "True":
                if row["assay"] in ("BG4", "CM"):
                    bg4cm_reps[key].append(label)
                elif row["assay"] == "CUTAC":
                    cutac_reps[key].append(label)

    print(f"Total rows in {os.path.basename(IN_TSV)}: {n_total_rows:,}")
    print(f"Rows flagged gold_standard=True: {n_gold_rows:,}")
    print(f"Unique gold-standard (well, junction) pairs: {len(rows_by_junction):,}")

    os.makedirs(os.path.dirname(OUT_TSV), exist_ok=True)
    with open(OUT_TSV, "w") as fo:
        fo.write("\t".join(HEADER) + "\n")
        for key, row in rows_by_junction.items():
            bg4cm = ";".join(sorted(set(bg4cm_reps[key])))
            cutac = ";".join(sorted(set(cutac_reps[key]))) or "-"
            fo.write("\t".join([
                row["well"], row["chrom"], row["region_start"], row["region_end"],
                row["junction_id"], row["junction_loc"], row["read_support"],
                row["orientation"], row["n_gold_reps"], row["n_reps_with_peak"],
                row["frac_reps_with_peak"], bg4cm, cutac,
            ]) + "\n")

    print(f"Written: {OUT_TSV}")

    # ── Per-well summary ───────────────────────────────────────────────────────
    by_well = defaultdict(int)
    for well, junction_id in rows_by_junction:
        by_well[well] += 1
    print(f"\nWells with >=1 gold-standard junction: {len(by_well)}")
    print(f"Total unique gold-standard junctions:   {len(rows_by_junction)}")
    print("DONE.")


if __name__ == "__main__":
    main()
