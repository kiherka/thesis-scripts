#!/usr/bin/env python3
"""
Debug script: verify that every SLX-28240 "deep-profiled" well has the full
set of expected BG4+CM gold-standard replicates.

Design of the combined dataset (as used by analyse_replicate_peaks.py):
  - SLX-28240 processed a fixed subset of wells (84, as of 2026-07) with BG4
    (BR2, BR3) and CM (BR1, BR2, BR3) - 5 replicates per well.
  - SLX-26997 provides an additional BG4 replicate for (almost) every well
    in the whole collection, labelled B1 -> renamed BR1.
  - Combined, a "complete" well should have 6 gold-standard replicates:
        BG4_BR1 (SLX-26997), BG4_BR2, BG4_BR3, CM_BR1, CM_BR2, CM_BR3 (SLX-28240)

This script checks, for each of the 84 SLX-28240 wells, whether all 6 expected
replicates are present and explains any gaps:
  - sample missing entirely (no .stats file for that dataset)
  - present but below the MIN_MAPPED_READS filter used in the main analysis
  - present + passes read filter, but missing a SEACR and/or MACS2 peak file

Outputs:
  debug_missing_replicates.tsv   - one row per (well, expected replicate)
  Console summary of how many wells are complete / incomplete and why.
"""

import os
import re
from collections import defaultdict

# ── Paths (must match analyse_replicate_peaks.py) ─────────────────────────────
SLX26997_BASE  = "/scratche/slow/sblab/herka01/SLX-26997"
SLX26997_STATS = "/scratche/slow/sblab/herka01/SLX-26997/stats"
SLX26997_PEAKS = "/scratche/slow/sblab/herka01/SLX-26997/peaks"
SLX28240_BASE  = "/scratche/slow/sblab/herka01/SLX-28240/pipeline"
SLX28240_STATS = "/scratche/slow/sblab/herka01/SLX-28240/pipeline/stats"
SLX28240_PEAKS = "/scratche/slow/sblab/herka01/SLX-28240/pipeline/peaks"

OUT_DIR  = "/scratche/slow/sblab/herka01/SLX-28240/peak_analysis"
OUT_TSV  = os.path.join(OUT_DIR, "debug_missing_replicates.tsv")

MIN_MAPPED_READS = 1_000_000   # same threshold as analyse_replicate_peaks.py (now measured post-dedup)


# NOTE: the flagstat file (*.r1.hg38.sort.stats) is generated on the
# PRE-deduplication BAM and can grossly overstate usable coverage for
# low-complexity/highly-duplicated libraries. We need the post-dedup count.
def get_dedup_reads(base_dir, sample):
    # Preferred: Picard MarkDuplicates metrics (SLX-26997 keeps these
    # permanently under noDups/).
    rmdups_path = os.path.join(base_dir, "noDups", f"{sample}.r1.hg38.rmDups.txt")
    if os.path.exists(rmdups_path):
        with open(rmdups_path) as fh:
            lines = fh.readlines()
        for i, line in enumerate(lines):
            if line.startswith("LIBRARY"):
                header = line.rstrip("\n").split("\t")
                values = lines[i + 1].rstrip("\n").split("\t")
                d = dict(zip(header, values))
                pairs_examined = int(d.get("READ_PAIRS_EXAMINED", 0))
                pair_dups = int(d.get("READ_PAIR_DUPLICATES", 0))
                unpaired_examined = int(d.get("UNPAIRED_READS_EXAMINED", 0))
                unpaired_dups = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
                return 2 * (pairs_examined - pair_dups) + (unpaired_examined - unpaired_dups)

    # Fallback: SLX-28240's rmDups.txt is a Snakemake temp() file deleted
    # after the pipeline finished. The bigwig_cpm rule's log records the
    # post-dedup pysam mapped-read count before running bamCoverage.
    log_path = os.path.join(base_dir, "logs", "bigwig", f"{sample}.cpm.log")
    if os.path.exists(log_path):
        with open(log_path) as fh:
            for line in fh:
                m = re.search(r"READ_COUNT=(\d+)", line)
                if m:
                    return int(m.group(1))
    return None


def has_peak_files(peaks_dir, sample):
    seacr = os.path.join(peaks_dir, "seacr", f"{sample}.stringent.bed")
    macs2 = os.path.join(peaks_dir, "macs2", f"{sample}_peaks.narrowPeak")
    return os.path.exists(seacr), os.path.exists(macs2)


# ── Discover the 84 SLX-28240 "deep-profiled" wells (from CM, which always
#    has BR1-3 for every such well) ────────────────────────────────────────────
cm_pat = re.compile(r"^CM_(.+)_BR\d+\.r1\.hg38\.sort\.stats$")
deep_wells = sorted({
    cm_pat.match(f).group(1)
    for f in os.listdir(SLX28240_STATS)
    if cm_pat.match(f)
})
print(f"SLX-28240 deep-profiled wells (from CM samples): {len(deep_wells)}")

# ── Expected replicate definitions per well ───────────────────────────────────
EXPECTED = [
    ("BG4", "BR1", SLX26997_BASE, SLX26997_STATS, SLX26997_PEAKS, lambda w: f"BG4_{w}_B1"),
    ("BG4", "BR2", SLX28240_BASE, SLX28240_STATS, SLX28240_PEAKS, lambda w: f"BG4_{w}_BR2"),
    ("BG4", "BR3", SLX28240_BASE, SLX28240_STATS, SLX28240_PEAKS, lambda w: f"BG4_{w}_BR3"),
    ("CM",  "BR1", SLX28240_BASE, SLX28240_STATS, SLX28240_PEAKS, lambda w: f"CM_{w}_BR1"),
    ("CM",  "BR2", SLX28240_BASE, SLX28240_STATS, SLX28240_PEAKS, lambda w: f"CM_{w}_BR2"),
    ("CM",  "BR3", SLX28240_BASE, SLX28240_STATS, SLX28240_PEAKS, lambda w: f"CM_{w}_BR3"),
]

# NOTE: SLX-26997 wells use zero-padded well IDs (e.g. 1A02), while SLX-28240
# wells are unpadded (e.g. 1A2). Build a lookup from normalised -> raw well
# name for SLX-26997 so we can find the right stats/peaks file.
def normalise_well(well):
    m = re.match(r"^(\d+[A-H])0*(\d+)$", well)
    return f"{m.group(1)}{m.group(2)}" if m else well

slx26997_bg4_pat = re.compile(r"^BG4_(.+)_B1\.r1\.hg38\.sort\.stats$")
raw_26997_by_norm = {}
for f in os.listdir(SLX26997_STATS):
    m = slx26997_bg4_pat.match(f)
    if m:
        raw = m.group(1)
        raw_26997_by_norm[normalise_well(raw)] = raw

# ── Main check ─────────────────────────────────────────────────────────────────
rows = []
well_status = defaultdict(list)  # well -> list of problem strings

for well in deep_wells:
    for assay, rep, base_dir, stats_dir, peaks_dir, sample_fn in EXPECTED:
        if assay == "BG4" and rep == "BR1":
            # SLX-26997 uses zero-padded well names
            raw_well = raw_26997_by_norm.get(well)
            if raw_well is None:
                rows.append({
                    "well": well, "assay": assay, "replicate": rep,
                    "sample": f"BG4_{well}_B1", "dataset": "SLX-26997",
                    "stats_exists": False, "mapped_reads": "",
                    "passes_read_filter": False,
                    "seacr_exists": False, "macs2_exists": False,
                    "status": "MISSING: no stats file (sample not sequenced/aligned)",
                })
                well_status[well].append("BG4_BR1: no stats file")
                continue
            sample = f"BG4_{raw_well}_B1"
        else:
            sample = sample_fn(well)

        mapped = get_dedup_reads(base_dir, sample)
        stats_exists = mapped is not None
        passes = stats_exists and mapped >= MIN_MAPPED_READS
        seacr_exists, macs2_exists = has_peak_files(peaks_dir, sample)

        if not stats_exists:
            status = "MISSING: no dedup metrics found (sample not sequenced/aligned)"
            well_status[well].append(f"{assay}_{rep}: no dedup metrics")
        elif not passes:
            status = f"EXCLUDED: mapped_reads={mapped:,} < {MIN_MAPPED_READS:,} threshold"
            well_status[well].append(f"{assay}_{rep}: low reads ({mapped:,})")
        elif not (seacr_exists and macs2_exists):
            missing_callers = []
            if not seacr_exists:
                missing_callers.append("SEACR")
            if not macs2_exists:
                missing_callers.append("MACS2")
            status = f"INCOMPLETE PEAKS: missing {'/'.join(missing_callers)} output"
            well_status[well].append(f"{assay}_{rep}: missing {'/'.join(missing_callers)} peaks")
        else:
            status = "OK"

        rows.append({
            "well": well, "assay": assay, "replicate": rep,
            "sample": sample, "dataset": "SLX-26997" if (assay == "BG4" and rep == "BR1") else "SLX-28240",
            "stats_exists": stats_exists,
            "mapped_reads": mapped if mapped is not None else "",
            "passes_read_filter": passes,
            "seacr_exists": seacr_exists, "macs2_exists": macs2_exists,
            "status": status,
        })

# ── Write detail TSV ───────────────────────────────────────────────────────────
os.makedirs(OUT_DIR, exist_ok=True)
header = ["well", "assay", "replicate", "sample", "dataset", "stats_exists",
          "mapped_reads", "passes_read_filter", "seacr_exists", "macs2_exists", "status"]
with open(OUT_TSV, "w") as fo:
    fo.write("\t".join(header) + "\n")
    for r in rows:
        fo.write("\t".join(str(r[h]) for h in header) + "\n")

print(f"Detail rows written: {len(rows)} -> {OUT_TSV}")

# ── Summary ────────────────────────────────────────────────────────────────────
n_complete = sum(1 for w in deep_wells if w not in well_status)
n_incomplete = len(deep_wells) - n_complete
print(f"\nWells with all 6 expected BG4+CM replicates OK: {n_complete}/{len(deep_wells)}")
print(f"Wells with at least one missing/excluded/incomplete replicate: {n_incomplete}/{len(deep_wells)}")

# Breakdown of problem types
problem_counts = defaultdict(int)
for r in rows:
    if r["status"] != "OK":
        if r["status"].startswith("MISSING"):
            problem_counts["missing stats file"] += 1
        elif r["status"].startswith("EXCLUDED"):
            problem_counts["excluded (low mapped reads)"] += 1
        elif r["status"].startswith("INCOMPLETE"):
            problem_counts["incomplete peak calling"] += 1

print("\nProblem breakdown (across all well x replicate combos):")
for k, v in sorted(problem_counts.items(), key=lambda x: -x[1]):
    print(f"  {k}: {v}")

if n_incomplete:
    print(f"\nFirst 20 incomplete wells and their issues:")
    for well in list(well_status.keys())[:20]:
        print(f"  {well}: {'; '.join(well_status[well])}")

print("\nDONE.")
