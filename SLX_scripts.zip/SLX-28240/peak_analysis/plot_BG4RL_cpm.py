"""
Plot CPM signal for all BG4_RL samples across insert site regions (+/- 5kb).
"""

import pyBigWig
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

# ── regions (from image) ──────────────────────────────────────────────────────
REGIONS = [
    ("Chr 2 site 1", "chr2",  104941714, 104941978),
    ("Chr 2 site 2", "chr2",  168374974, 168375175),
    ("Chr 5 site",   "chr5",  134521192, 134521451),
    ("Chr 9 site",   "chr9",  137626501, 137626702),
    ("Chr 10 site",  "chr10",  87030690,  87030891),
    ("KRAS",  "chr12",  25250702,  25251567),
]
FLANK = 5_000   # bp either side

# ── bigwig files ──────────────────────────────────────────────────────────────
BW_DIR = Path("/scratche/slow/sblab/herka01/SLX-28240/pipeline/bigwigs")
SAMPLES = [
    "BG4_RL_NEG_T1", "BG4_RL_NEG_T2", "BG4_RL_NEG_T3", "BG4_RL_NEG_T4",
    "BG4_RL_POS_T1", "BG4_RL_POS_T2", "BG4_RL_POS_T3", "BG4_RL_POS_T4",
]

# colours: NEG = blues, POS = reds
COLORS = {
    "BG4_RL_NEG_T1": "#a8d1f0",
    "BG4_RL_NEG_T2": "#5baad4",
    "BG4_RL_NEG_T3": "#2171b5",
    "BG4_RL_NEG_T4": "#08306b",
    "BG4_RL_POS_T1": "#fcae91",
    "BG4_RL_POS_T2": "#fb6a4a",
    "BG4_RL_POS_T3": "#cb181d",
    "BG4_RL_POS_T4": "#67000d",
}

OUT_DIR = Path("/scratche/slow/sblab/herka01/SLX-28240/peak_analysis")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ── helpers ───────────────────────────────────────────────────────────────────
def fetch_signal(bw, chrom, start, end, bins=500):
    """Return (x positions, CPM values) across [start, end], binned."""
    stats = bw.stats(chrom, start, end, type="mean", nBins=bins)
    # replace None with 0
    vals = np.array([v if v is not None else 0.0 for v in stats])
    x = np.linspace(start, end, bins)
    return x, vals

# ── open all bigwigs ──────────────────────────────────────────────────────────
bws = {}
for s in SAMPLES:
    path = BW_DIR / f"{s}.cpm.bw"
    if not path.exists():
        raise FileNotFoundError(f"Missing bigwig: {path}")
    bws[s] = pyBigWig.open(str(path))

# ── plot ──────────────────────────────────────────────────────────────────────
n_regions = len(REGIONS)
fig, axes = plt.subplots(n_regions, 1, figsize=(12, 3.5 * n_regions),
                         constrained_layout=True)
if n_regions == 1:
    axes = [axes]

for ax, (name, chrom, ins_start, ins_end) in zip(axes, REGIONS):
    win_start = ins_start - FLANK
    win_end   = ins_end   + FLANK

    for s in SAMPLES:
        x, vals = fetch_signal(bws[s], chrom, win_start, win_end)
        lw = 1.0 if "NEG" in s else 1.2
        ax.fill_between(x, vals, alpha=0.18, color=COLORS[s])
        ax.plot(x, vals, color=COLORS[s], lw=lw, label=s)

    # shade insert region
    ax.axvspan(ins_start, ins_end, color="gold", alpha=0.35, zorder=0,
               label="Insert site")
    ax.axvline(ins_start, color="goldenrod", lw=0.8, ls="--")
    ax.axvline(ins_end,   color="goldenrod", lw=0.8, ls="--")

    # x-axis: position in kb relative to insert midpoint
    mid = (ins_start + ins_end) / 2
    xticks = np.linspace(win_start, win_end, 11)
    ax.set_xticks(xticks)
    ax.set_xticklabels([f"{(t - mid)/1000:+.1f}" for t in xticks], fontsize=8)
    ax.set_xlabel("Distance from insert midpoint (kb)", fontsize=9)
    ax.set_ylabel("CPM", fontsize=9)
    ax.set_title(f"{name}  [{chrom}:{ins_start:,}–{ins_end:,}]", fontsize=10,
                 fontweight="bold")
    ax.set_xlim(win_start, win_end)
    ax.spines[["top", "right"]].set_visible(False)

# ── legend (once, at top) ─────────────────────────────────────────────────────
handles = [mpatches.Patch(color=COLORS[s], label=s) for s in SAMPLES]
handles.append(mpatches.Patch(color="gold", alpha=0.6, label="Insert site"))
axes[0].legend(handles=handles, ncol=3, fontsize=8, loc="upper right",
               framealpha=0.8)

out_png = OUT_DIR / "BG4RL_CPM_insert_regions.png"
out_pdf = OUT_DIR / "BG4RL_CPM_insert_regions.pdf"
fig.savefig(out_png, dpi=150)
fig.savefig(out_pdf)
print(f"Saved:\n  {out_png}\n  {out_pdf}")

for bw in bws.values():
    bw.close()
