#!/bin/bash

mkdir demultiplexed-br3

sbatch --time 12:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -o ./demultiplexed-br3  -s SLX-27392_summary2_demuxFQ_r1.txt BR3_r1.txt SLX-27392.UnspecifiedIndex.222CCJCNX.s_1.r_1.fq.gz"

sbatch --mem 32G --time 12:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -o ./demultiplexed-br3 -s SLX-27392_summary2_demuxFQ_r2.txt BR3_r2.txt  SLX-27392.UnspecifiedIndex.222CCJCNX.s_1.r_2.fq.gz"
