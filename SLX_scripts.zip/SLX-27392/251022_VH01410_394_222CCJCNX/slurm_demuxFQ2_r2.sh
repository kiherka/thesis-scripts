#!/bin/bash

sbatch --mem 32G --time 12:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -b SLX-27392_lostreads_r2.fq.gz -o ./demultiplexed -s SLX-27392_summary2_demuxFQ_r2.txt SLX-27392_demultiplex_r2.txt  SLX-27392.UnspecifiedIndex.222CCJCNX.s_1.r_2.fq.gz"
