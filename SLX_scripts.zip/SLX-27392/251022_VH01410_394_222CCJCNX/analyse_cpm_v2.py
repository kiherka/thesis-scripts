#!/usr/bin/env python3
"""
Analyse CPM bigwig files from SLX-27925 pipeline.  VERSION 2.

Identical to analyse_cpm.py except that specific BG4 replicates are excluded
before averaging, track plotting, and statistical analysis.
CUTAC samples are unchanged.

Excluded BG4 replicates (replicate-level QC; see excluded_bg4_replicates.tsv):
  BG4_KH-14-N12-1_B3, BG4_KH-14-N12-9_B2,
  BG4_KH-14-N13-2_B1, BG4_KH-14-N13-3_B2, BG4_KH-14-N13-3_B3,
  BG4_KH-14-N13-4_B1, BG4_KH-14-N14-2_B1, BG4_KH-14-N14-2_B2,
  BG4_KH-14-N14-3_B3, BG4_KH-14-N14-6_B1, BG4_KH-17-C-1_B1,
  BG4_KH-17-C-2_B1,   BG4_KH-17-N12-1_B1, BG4_KH-WT-N13-4_B2,
  BG4_KH-WT-N13-6_B2, BG4_KH-WT-N15-7_B1, BG4_KH-WT-N15-7_B3,
  BG4_KH-WT-N15-8_B1, BG4_KH-WT-N15-8_B3

Outputs are written to OUT_DIR with a _v2 suffix where needed.
"""

import re
import glob
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import pyBigWig
from scipy import stats
from statsmodels.stats.multitest import multipletests
from itertools import combinations

# ── Regions ───────────────────────────────────────────────────────────────────
TARGET_CHR   = "chr16"
PEAK_START   = 113670
PEAK_END     = 113696

WINDOWS = {
    "500bp": (PEAK_START - 500,  PEAK_END + 500),
    "10kb":  (PEAK_START - 10000, PEAK_END + 10000),
}
TARGET_START = WINDOWS["500bp"][0]
TARGET_END   = WINDOWS["500bp"][1]

REF_CHR   = "chr12"
REF_START = 25_250_600
REF_END   = 25_251_600

BIGWIG_DIR    = "/scratche/slow/sblab/herka01/SLX-27925/pipeline/bigwigs"
DEDUP_LOG_DIR = "/scratche/slow/sblab/herka01/SLX-27925/pipeline/logs/dedup"
OUT_DIR       = "/scratche/slow/sblab/herka01/SLX-27925/cpm_analysis/excluded_samples_analysis"
BIN_SIZE      = 25
MIN_DEDUP_READS = 1_000_000

os.makedirs(OUT_DIR, exist_ok=True)

# ── BG4 replicate exclusions ──────────────────────────────────────────────────
BG4_EXCLUDED_STEMS = {
    "BG4_KH-14-N12-1_B3":  "low dedup reads (2.6M) + elevated CPM vs other reps",
    "BG4_KH-14-N12-9_B2":  "CPM outlier vs B1/B3",
    "BG4_KH-14-N13-2_B1":  "extreme CPM outlier (1.68 vs 0.037 for B3)",
    "BG4_KH-14-N13-3_B2":  "low dedup reads (1.1M) + elevated CPM",
    "BG4_KH-14-N13-3_B3":  "excluded by QC",
    "BG4_KH-14-N13-4_B1":  "zero CPM with low dedup reads (1.1M)",
    "BG4_KH-14-N14-2_B1":  "low dedup reads (1.3M) + low CPM outlier",
    "BG4_KH-14-N14-2_B2":  "CPM outlier (0.47 vs 0.057 for B3)",
    "BG4_KH-14-N14-3_B3":  "excluded by QC",
    "BG4_KH-14-N14-6_B1":  "zero CPM; only replicate — clone fully dropped",
    "BG4_KH-17-C-1_B1":    "CPM outlier (0.49); only replicate — clone fully dropped",
    "BG4_KH-17-C-2_B1":    "zero CPM with low dedup reads (2.6M)",
    "BG4_KH-17-N12-1_B1":  "zero CPM with low dedup reads (1.5M)",
    "BG4_KH-WT-N13-4_B2":  "anomalously high dedup reads (55M) + CPM outlier",
    "BG4_KH-WT-N13-6_B2":  "excluded by QC",
    "BG4_KH-WT-N15-7_B1":  "low dedup reads (9.1M) + elevated CPM vs B2/B3",
    "BG4_KH-WT-N15-7_B3":  "zero CPM with low dedup reads (1.3M)",
    "BG4_KH-WT-N15-8_B1":  "low dedup reads (1.4M)",
    "BG4_KH-WT-N15-8_B3":  "excluded by QC",
}

# ── Sample parsing ─────────────────────────────────────────────────────────────
def parse_sample(stem):
    m = re.match(r'^(BG4|CUTAC)_(.+)_(B\d+)$', stem)
    if not m:
        return None
    assay, middle, biorep = m.group(1), m.group(2), m.group(3)
    cell_line = f"{assay}_{middle}"
    edit_category = re.sub(r'-\d+$', '', middle)
    return dict(stem=stem, assay=assay, cell_line=cell_line,
                edit_category=edit_category, biorep=biorep)

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "*.cpm.bw")))
records = []
for path in bw_files:
    stem = os.path.basename(path).replace(".cpm.bw", "")
    info = parse_sample(stem)
    if info:
        info["path"] = path
        records.append(info)

meta_all = pd.DataFrame(records)

# ── Dedup reads filter ─────────────────────────────────────────────────────────
def parse_dedup_reads(stem):
    log_path = os.path.join(DEDUP_LOG_DIR, f"{stem}.log")
    if not os.path.exists(log_path):
        return None
    total, dups = None, None
    with open(log_path) as fh:
        for line in fh:
            m = re.search(r'Read (\d+) records\. \d+ pairs never matched', line)
            if m:
                total = int(m.group(1))
            m = re.search(r'Marking ([\d,]+) records as duplicates', line)
            if m:
                dups = int(m.group(1).replace(',', ''))
    if total is not None and dups is not None:
        return total - dups
    return None

meta_all["dedup_reads"] = meta_all["stem"].apply(parse_dedup_reads)

low = meta_all[meta_all["dedup_reads"].lt(MIN_DEDUP_READS) | meta_all["dedup_reads"].isna()]
if len(low):
    print(f"\nExcluding {len(low)} sample(s) with < {MIN_DEDUP_READS:,} deduplicated reads:")
    print(low[["stem", "dedup_reads"]].to_string(index=False))

meta_all = meta_all[meta_all["dedup_reads"].ge(MIN_DEDUP_READS)].copy()

# ── Apply BG4 replicate exclusions ────────────────────────────────────────────
bg4_excl_mask = (
    (meta_all["assay"] == "BG4") &
    (meta_all["stem"].isin(BG4_EXCLUDED_STEMS))
)
excl_df = meta_all[bg4_excl_mask].copy()
excl_df["reason"] = excl_df["stem"].map(BG4_EXCLUDED_STEMS)
excl_df[["stem", "assay", "cell_line", "biorep", "dedup_reads", "reason"]]\
    .sort_values("stem")\
    .to_csv(os.path.join(OUT_DIR, "excluded_bg4_replicates_v2.tsv"), sep="\t", index=False)

meta = meta_all[~bg4_excl_mask].copy()

print(f"\n{len(meta)} samples retained after ≥{MIN_DEDUP_READS:,} filter + BG4 exclusions")
print(f"  ({len(excl_df)} BG4 replicates excluded)")
print(meta.groupby(["assay", "edit_category"]).size().to_string())

# Clones fully dropped (all replicates removed)
bg4_clones_before = set(meta_all[meta_all["assay"]=="BG4"]["cell_line"])
bg4_clones_after  = set(meta[meta["assay"]=="BG4"]["cell_line"])
fully_dropped = bg4_clones_before - bg4_clones_after
if fully_dropped:
    print(f"\nBG4 clones fully dropped: {sorted(fully_dropped)}")

# ── Helper ─────────────────────────────────────────────────────────────────────
def fetch_mean(bw, chrom, start, end):
    try:
        val = bw.stats(chrom, start, end, type="mean", exact=True)[0]
        return float(val) if val is not None else 0.0
    except RuntimeError:
        return 0.0

# ── Extract CPM ───────────────────────────────────────────────────────────────
print("\nExtracting CPM values …")
target_cpms, ref_cpms = [], []
track_bins = {win: np.arange(s, e, BIN_SIZE) for win, (s, e) in WINDOWS.items()}
track_data = {win: {} for win in WINDOWS}

for _, row in meta.iterrows():
    bw = pyBigWig.open(row["path"])
    for win, bins in track_bins.items():
        sig = [fetch_mean(bw, TARGET_CHR, int(b), int(b + BIN_SIZE)) for b in bins]
        track_data[win][row["stem"]] = np.array(sig)
    target_cpms.append(fetch_mean(bw, TARGET_CHR, TARGET_START, TARGET_END))
    ref_cpms.append(fetch_mean(bw, REF_CHR, REF_START, REF_END))
    bw.close()

meta["target_cpm"] = target_cpms
meta["ref_cpm"]    = ref_cpms
meta["norm_cpm"]   = meta.apply(
    lambda r: r["target_cpm"] / r["ref_cpm"] if r["ref_cpm"] > 0 else np.nan, axis=1
)
meta.to_csv(os.path.join(OUT_DIR, "per_sample_cpm_v2.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm_v2.tsv")

# ── Colour palettes ────────────────────────────────────────────────────────────
def make_palette(keys):
    n = len(keys)
    colors = sns.color_palette("tab20", n) if n <= 20 else sns.color_palette("husl", n)
    return dict(zip(sorted(keys), colors))

edit_cats = sorted(meta["edit_category"].unique())
cat_palette = make_palette(edit_cats)

# ── 1. Track plots ─────────────────────────────────────────────────────────────
print("Plotting CPM tracks …")

for assay in ["BG4", "CUTAC"]:
    sub = meta[meta["assay"] == assay].sort_values("cell_line")
    n_samples = len(sub)

    for win_label, (win_start, win_end) in WINDOWS.items():
        bins = track_bins[win_label]
        x = bins - win_start
        peak_rel_s = PEAK_START - win_start
        peak_rel_e = PEAK_END   - win_start

        all_vals = np.concatenate([track_data[win_label][r["stem"]]
                                   for _, r in sub.iterrows()])
        ymax = np.nanpercentile(all_vals, 99) * 1.15
        ymax = max(ymax, 0.01)

        fig, axes = plt.subplots(
            n_samples, 1,
            figsize=(14, max(4, 0.38 * n_samples + 1.5)),
            sharex=True, sharey=False,
            gridspec_kw={"hspace": 0.05}
        )
        if n_samples == 1:
            axes = [axes]

        for ax, (_, row) in zip(axes, sub.iterrows()):
            sig = track_data[win_label][row["stem"]]
            color = cat_palette[row["edit_category"]]
            ax.fill_between(x, sig, alpha=0.85, color=color, linewidth=0)
            ax.axvspan(peak_rel_s, peak_rel_e, color="red", alpha=0.15, linewidth=0)
            ax.set_ylim(0, ymax)
            ax.set_ylabel(row["cell_line"], fontsize=4.5, rotation=0,
                          ha="right", va="center", labelpad=2)
            ax.set_yticks([round(ymax, 2)])
            ax.set_yticklabels([f"{ymax:.2f}"], fontsize=3.5)
            ax.spines[["top", "right", "left"]].set_visible(False)
            ax.tick_params(left=False)

        axes[-1].set_xlabel(f"{TARGET_CHR} offset from window start (bp)")
        wlen = win_end - win_start
        fig.suptitle(
            f"{assay}: CPM signal – {win_label} window  "
            f"({TARGET_CHR}:{win_start:,}–{win_end:,}, {wlen:,} bp)\n"
            f"Red band = peak ({TARGET_CHR}:{PEAK_START:,}–{PEAK_END:,})  |  "
            f"All tracks: same Y scale (max = {ymax:.2f} CPM)"
            + (f"\n[v2: {len(BG4_EXCLUDED_STEMS)} BG4 replicates excluded]"
               if assay == "BG4" else ""),
            fontsize=8
        )
        cats_here = sorted(sub["edit_category"].unique())
        handles = [plt.Rectangle((0,0),1,1, color=cat_palette[c]) for c in cats_here]
        axes[0].legend(handles, cats_here, loc="upper right", fontsize=5,
                       ncol=max(1, len(cats_here)//4), framealpha=0.7)

        out = os.path.join(OUT_DIR, f"01_tracks_{assay}_{win_label}_v2.pdf")
        fig.savefig(out, bbox_inches="tight", dpi=150)
        plt.close(fig)
        print(f"  Saved {out}")

# ── 3. Cell line plot ──────────────────────────────────────────────────────────
print("Plotting normalised CPM per cell line …")

cell_line_stats = (
    meta.groupby(["assay", "cell_line", "edit_category"])["norm_cpm"]
    .agg(mean="mean", sem="sem", n="count")
    .reset_index()
)
cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_norm_cpm_v2.tsv"), sep="\t", index=False)

for assay in ["BG4", "CUTAC"]:
    sub = cell_line_stats[cell_line_stats["assay"] == assay].sort_values("cell_line")
    fig, ax = plt.subplots(figsize=(max(8, len(sub) * 0.35 + 2), 5))
    colors = [cat_palette[c] for c in sub["edit_category"]]
    ax.bar(range(len(sub)), sub["mean"], yerr=sub["sem"],
           color=colors, capsize=3, width=0.7, error_kw=dict(linewidth=1))
    ax.set_xticks(range(len(sub)))
    ax.set_xticklabels(sub["cell_line"], rotation=60, ha="right", fontsize=6)
    ax.set_ylabel("Normalised CPM (target / reference)")
    ax.set_title(f"{assay}: Mean normalised CPM per cell line  [v2]\n"
                 f"(mean ± SEM across bio-replicates)")
    cats_here = sorted(sub["edit_category"].unique())
    handles = [plt.Rectangle((0,0),1,1, color=cat_palette[c]) for c in cats_here]
    ax.legend(handles, cats_here, loc="upper right", fontsize=7,
              ncol=max(1, len(cats_here)//4))
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, f"03_cell_line_{assay}_v2.pdf")
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"  Saved {out}")

# ── 4 & 5. Edit category plot + statistics ────────────────────────────────────
print("Plotting normalised CPM per edit category + statistics …")

cat_stats = (
    meta.groupby(["assay", "edit_category"])["norm_cpm"]
    .agg(mean="mean", std="std", sem="sem", n="count", values=list)
    .reset_index()
)
cat_stats.to_csv(os.path.join(OUT_DIR, "edit_category_norm_cpm_v2.tsv"), sep="\t", index=False)

all_stats = []
for assay in ["BG4", "CUTAC"]:
    sub_meta = meta[meta["assay"] == assay]
    groups = {cat: grp["norm_cpm"].dropna().values
              for cat, grp in sub_meta.groupby("edit_category")}
    vals = [v for v in groups.values() if len(v) >= 2]
    h_stat, kw_p = (stats.kruskal(*vals) if len(vals) >= 2 else (np.nan, np.nan))
    for g1, g2 in combinations(sorted(groups.keys()), 2):
        v1, v2 = groups[g1], groups[g2]
        u, p = (stats.mannwhitneyu(v1, v2, alternative="two-sided")
                if len(v1) >= 2 and len(v2) >= 2 else (np.nan, np.nan))
        all_stats.append(dict(assay=assay, group1=g1, group2=g2, U=u, p_raw=p,
                              kw_H=h_stat, kw_p=kw_p))

stats_df = pd.DataFrame(all_stats)
if not stats_df.empty:
    for assay in ["BG4", "CUTAC"]:
        mask = stats_df["assay"] == assay
        p_vals = stats_df.loc[mask, "p_raw"].values
        valid = ~np.isnan(p_vals)
        padj = np.full(len(p_vals), np.nan)
        if valid.sum() > 1:
            _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
        elif valid.sum() == 1:
            padj[valid] = p_vals[valid]
        stats_df.loc[mask, "p_adj_BH"] = padj
        stats_df.loc[mask, "significant"] = padj < 0.05
    stats_df.to_csv(os.path.join(OUT_DIR, "statistics_pairwise_v2.tsv"), sep="\t", index=False)
    print("Saved statistics_pairwise_v2.tsv")
    sig = stats_df[stats_df.get("significant", False) == True]
    print(f"{len(sig)} significant pairwise comparisons (FDR<0.05):")
    if not sig.empty:
        print(sig[["assay","group1","group2","p_raw","p_adj_BH"]].to_string(index=False))

def sig_stars(p):
    if np.isnan(p): return ""
    if p < 0.001: return "***"
    if p < 0.01:  return "**"
    if p < 0.05:  return "*"
    return "ns"

for assay in ["BG4", "CUTAC"]:
    sub_cat   = cat_stats[cat_stats["assay"] == assay].sort_values("edit_category")
    sub_stats = stats_df[stats_df["assay"] == assay] if not stats_df.empty else pd.DataFrame()
    n_cats    = len(sub_cat)
    fig, ax   = plt.subplots(figsize=(max(6, n_cats * 0.8 + 2), 6))
    colors    = [cat_palette[c] for c in sub_cat["edit_category"]]
    positions = np.arange(n_cats)

    ax.bar(positions, sub_cat["mean"], yerr=sub_cat["sem"],
           color=colors, alpha=0.75, capsize=4, width=0.6,
           error_kw=dict(linewidth=1.5), zorder=2)

    sub_meta2 = meta[meta["assay"] == assay]
    for i, cat in enumerate(sub_cat["edit_category"]):
        pts = sub_meta2[sub_meta2["edit_category"] == cat]["norm_cpm"].dropna()
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

    if not sub_stats.empty:
        y_max = sub_cat["mean"].max() + sub_cat["sem"].max()
        cats_ordered = list(sub_cat["edit_category"])
        step = y_max * 0.12
        level = 0
        for _, row_s in sub_stats[sub_stats.get("p_adj_BH", pd.Series()) < 0.05].iterrows():
            if row_s["group1"] not in cats_ordered or row_s["group2"] not in cats_ordered:
                continue
            x1 = cats_ordered.index(row_s["group1"])
            x2 = cats_ordered.index(row_s["group2"])
            y  = y_max + step * (level + 1)
            ax.plot([x1, x1, x2, x2], [y - step*0.1, y, y, y - step*0.1],
                    color="black", linewidth=0.8)
            ax.text((x1 + x2) / 2, y + step*0.05,
                    sig_stars(row_s["p_adj_BH"]), ha="center", va="bottom", fontsize=8)
            level += 1

    ax.set_xticks(positions)
    ax.set_xticklabels(sub_cat["edit_category"], rotation=30, ha="right", fontsize=8)
    ax.set_ylabel("Normalised CPM (target / reference)")
    kw_row  = sub_stats.drop_duplicates("kw_p") if not sub_stats.empty else None
    kw_text = ""
    if kw_row is not None and not kw_row.empty and not np.isnan(kw_row.iloc[0]["kw_p"]):
        kw_text = f"  (Kruskal-Wallis p={kw_row.iloc[0]['kw_p']:.3g})"
    excl_note = f"\n[v2: {len(BG4_EXCLUDED_STEMS)} BG4 replicates excluded]" if assay=="BG4" else ""
    ax.set_title(f"{assay}: Mean normalised CPM per edit category{kw_text}\n"
                 f"(bar = mean ± SEM; dots = all samples; * FDR<0.05){excl_note}")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, f"04_edit_category_{assay}_v2.pdf")
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"  Saved {out}")

print(f"\nAll outputs written to: {OUT_DIR}")
