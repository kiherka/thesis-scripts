#!/bin/bash
# Run the Snakemake master on the submit/login node (inside tmux/screen)
# so that localrules (fetch_genome_from_nas, etc.) can access /mnt/nas-data.
#
# Usage:  screen -S smk27843
#         bash run_master.sh          # runs in foreground
#         # Ctrl-a d  to detach       # re-attach: screen -r smk27843
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27843

LOG=logs/slurm/smk_master_local_$(date +%Y%m%d_%H%M%S).log
echo "Logging to $LOG"

snakemake --profile profile --jobs 100 2>&1 | tee "$LOG"
