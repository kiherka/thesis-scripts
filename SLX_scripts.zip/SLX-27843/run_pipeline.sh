#!/bin/bash
#SBATCH --partition=cuda
#SBATCH --job-name=smk_master_27843
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/slurm/snakemake_master_%j.out
#SBATCH --error=logs/slurm/snakemake_master_%j.err

set -euo pipefail

cd /mnt/scratchc/sblab/herka01/SLX-27843

mkdir -p logs/slurm

# Activate snakemake environment
eval "$(conda shell.bash hook)"
conda activate snakemake

# Run Snakemake with the SLURM profile
snakemake --profile profile/ 2>&1 | tee logs/snakemake_master.log
