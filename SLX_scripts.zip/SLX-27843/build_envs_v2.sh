#!/bin/bash
# Build the SEACR conda env manually, then launch the pipeline.
# Run in screen:  screen -dmS build_envs bash build_envs_v2.sh
# Logs: logs/build_envs_v2.log

set -euo pipefail

cd /mnt/scratchc/sblab/herka01/SLX-27843
mkdir -p logs

LOGFILE="logs/build_envs_v2.log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "=== $(date) === Building SEACR conda env manually ==="

eval "$(conda shell.bash hook)"
conda activate snakemake

PREFIX="/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/.snakemake/conda/581439e6214383971a888f0abd7dba49_"

# Remove any partial state
rm -rf "$PREFIX"

# Build env with mamba create (not 'env create' which hangs)
mamba create --prefix "$PREFIX" \
    -c conda-forge -c bioconda \
    seacr=1.3 bedtools=2.31.1 samtools=1.21 \
    -y 2>&1

echo "=== $(date) === SEACR env built at: $PREFIX ==="
ls "$PREFIX/bin/" | grep -E "SEACR|bedtools|samtools" || true

# Unlock snakemake dir (in case locked)
snakemake --unlock 2>&1 || true

# Launch the pipeline
echo "=== $(date) === Submitting pipeline ==="
sbatch run_pipeline.sh
echo "=== $(date) === Done ==="
