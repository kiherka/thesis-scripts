#!/bin/bash
# Pre-build conda environments for Snakemake on the login node.
# Run inside screen so it persists if SSH drops:
#   screen -dmS build_envs bash build_envs.sh
# Attach with:  screen -r build_envs
# Logs written to: logs/build_envs.log

set -euo pipefail

cd /mnt/scratchc/sblab/herka01/SLX-27843
mkdir -p logs

LOGFILE="logs/build_envs.log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "=== $(date) === Starting conda env pre-build ==="

# Activate snakemake
eval "$(conda shell.bash hook)"
conda activate snakemake

# Let Snakemake create all conda environments without running any jobs
echo "--- Building all conda environments via snakemake --conda-create-envs-only ---"
snakemake --conda-create-envs-only --use-conda \
    --conda-prefix /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/.snakemake/conda \
    --cores 1 \
    2>&1

echo "=== $(date) === All conda environments built successfully ==="
echo ""
echo "Ready to launch pipeline. Run:"
echo "  cd /mnt/scratchc/sblab/herka01/SLX-27843 && sbatch run_pipeline.sh"

# Auto-launch the pipeline
echo "=== $(date) === Auto-submitting pipeline ==="
sbatch run_pipeline.sh
echo "=== $(date) === Pipeline submitted ==="
