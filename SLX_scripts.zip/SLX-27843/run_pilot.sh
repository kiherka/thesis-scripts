#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --job-name=smk_pilot_27843
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=2-00:00:00
#SBATCH --output=logs/slurm/snakemake_pilot_%j.out
#SBATCH --error=logs/slurm/snakemake_pilot_%j.err
#SBATCH --dependency=afterany:48118394

set -euo pipefail

cd /mnt/scratchc/sblab/herka01/SLX-27843

mkdir -p logs/slurm

# Activate snakemake environment
eval "$(conda shell.bash hook)"
conda activate snakemake

# Run only the pilot bigwig targets
snakemake --profile profile/ --rerun-incomplete 2>&1 | tee logs/snakemake_pilot.log
