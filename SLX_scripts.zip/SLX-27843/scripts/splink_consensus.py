#!/usr/bin/env python3
"""
splink_consensus.py – Identify insert-genome junctions from noise-filtered
BAMs, build per-junction consensus sequences, and create a new reference
genome with the insert integrated at each junction site.

Usage (called by Snakemake):
    python splink_consensus.py junctions  <filtered_bam> <ref_fasta> <out_bed> <out_consensus_fa> <out_stats>
    python splink_consensus.py integrate  <ref_fasta> <junction_bed> <insert_fasta> <out_genome_fa>

The 'junctions' subcommand:
  1. Scans supplementary (SA:Z) and discordant read alignments in the
     noise-filtered BAM to locate genomic breakpoints adjacent to the
     SPLINK_INSERT_500bp contig.
  2. Clusters nearby breakpoints (within --merge-dist bp, default 500)
     into single junction sites.
  3. For each cluster, builds a junction-spanning consensus from the
     full query sequences of chimeric reads, capturing both the
     genomic flank and the insert sequence across the breakpoint.
  4. Outputs:
     - BED file of junction sites (chrom, start, end, junction_id,
       n_reads, strand, consensus_length, orientation, clip_pos)
     - FASTA of junction-spanning consensus sequences
       (insert side + junction + genome side)
     - Stats text file

The 'integrate' subcommand:
  1. Reads the junction BED and insert sequence.
  2. For each junction, splices the insert at the breakpoint.
  3. Writes a new genome FASTA with modified chromosomes.
"""

import argparse
import collections
import os
import re
import sys
from pathlib import Path

try:
    import pysam
except ImportError:
    sys.exit("ERROR: pysam is required. Install via conda: conda install -c bioconda pysam")


INSERT_CONTIG = "SPLINK_INSERT_500bp"
DEFAULT_MERGE_DIST = 500
CONSENSUS_FLANK = 200  # max bp on each side of the junction for consensus


# ──────────────────────── Junction detection ─────────────────────────

Junction = collections.namedtuple(
    "Junction",
    ["chrom", "pos", "strand", "insert_end", "read_name", "sa_strand"]
)


def parse_sa_tag(sa_string):
    """Parse SA:Z: tag -> list of (rname, pos, strand, cigar, mapq, nm)."""
    entries = []
    for part in sa_string.rstrip(";").split(";"):
        fields = part.split(",")
        if len(fields) >= 4:
            entries.append({
                "rname": fields[0],
                "pos": int(fields[1]),
                "strand": fields[2],
                "cigar": fields[3],
                "mapq": int(fields[4]) if len(fields) > 4 else 0,
            })
    return entries


def extract_junctions(bam_path):
    """Scan BAM for junctions between genomic chroms and INSERT contig."""
    junctions = []
    bam = pysam.AlignmentFile(bam_path, "rb")

    for read in bam.fetch(until_eof=True):
        if read.is_unmapped:
            continue

        rname = read.reference_name
        mate_rname = read.next_reference_name if read.is_paired else None

        # --- Case A: Supplementary alignments with SA:Z tag ---
        if read.has_tag("SA"):
            sa_entries = parse_sa_tag(read.get_tag("SA"))
            for sa in sa_entries:
                # One end on INSERT, other on genome (or vice versa)
                if rname == INSERT_CONTIG and sa["rname"] != INSERT_CONTIG:
                    # Genomic breakpoint is on the SA entry side
                    strand = sa["strand"]
                    # This read is mapped to INSERT — its own strand on
                    # the insert tells us the insert orientation.
                    insert_strand = "-" if read.is_reverse else "+"
                    junctions.append(Junction(
                        chrom=sa["rname"],
                        pos=sa["pos"],
                        strand=strand,
                        insert_end="sa_genomic",
                        read_name=read.query_name,
                        sa_strand=insert_strand,
                    ))
                elif rname != INSERT_CONTIG and sa["rname"] == INSERT_CONTIG:
                    # This read is on a genomic chrom, SA is on insert
                    # Breakpoint is at the clipping point of this read
                    clip_pos = _get_clip_position(read)
                    junctions.append(Junction(
                        chrom=rname,
                        pos=clip_pos,
                        strand="+" if not read.is_reverse else "-",
                        insert_end="primary_genomic",
                        read_name=read.query_name,
                        sa_strand=sa["strand"],
                    ))

        # --- Case B: Discordant pairs (mate on INSERT, read on genome) ---
        if read.is_paired and mate_rname:
            if rname != INSERT_CONTIG and mate_rname == INSERT_CONTIG:
                # Read is on genome, mate on insert — junction near this read
                junctions.append(Junction(
                    chrom=rname,
                    pos=read.reference_end if read.reference_end else read.reference_start,
                    strand="+" if not read.is_reverse else "-",
                    insert_end="discordant_mate_on_insert",
                    read_name=read.query_name,
                    sa_strand=None,
                ))

    bam.close()
    return junctions


def _get_clip_position(read):
    """Return the genomic position of the soft/hard clip (junction boundary)."""
    cigar = read.cigartuples
    if not cigar:
        return read.reference_start
    # Check if clipped at start (left)
    if cigar[0][0] in (4, 5):  # S or H at start
        return read.reference_start
    # Check if clipped at end (right)
    if cigar[-1][0] in (4, 5):
        return read.reference_end
    return read.reference_end


def cluster_junctions(junctions, merge_dist=DEFAULT_MERGE_DIST):
    """Cluster nearby junction positions on the same chrom+strand."""
    if not junctions:
        return []

    # Group by chrom
    by_chrom = collections.defaultdict(list)
    for j in junctions:
        by_chrom[j.chrom].append(j)

    clusters = []
    for chrom in sorted(by_chrom.keys()):
        # Skip the insert contig itself
        if chrom == INSERT_CONTIG:
            continue
        chrom_juncs = sorted(by_chrom[chrom], key=lambda x: x.pos)
        current_cluster = [chrom_juncs[0]]
        for j in chrom_juncs[1:]:
            if j.pos - current_cluster[-1].pos <= merge_dist:
                current_cluster.append(j)
            else:
                clusters.append(current_cluster)
                current_cluster = [j]
        clusters.append(current_cluster)

    return clusters


def build_junction_spanning_consensus(bam_path, chrom, clip_pos,
                                      flank=CONSENSUS_FLANK):
    """Build a consensus spanning both genomic and insert sides of a junction.

    For each chimeric read (SA:Z tag pointing to the insert contig) near
    *clip_pos*, the full query sequence contains both the genome-aligned
    portion and the soft-clipped insert portion.  By anchoring every read
    at its clip boundary and taking a majority vote at each offset we
    obtain a single sequence that crosses the breakpoint::

        ...INSERT_BASES -> JUNCTION -> GENOME_BASES...

    Parameters
    ----------
    bam_path : str
        Path to the noise-filtered junction BAM.
    chrom : str
        Genomic chromosome of the junction.
    clip_pos : int
        Chimeric clip position on the genome (= junction coordinate).
    flank : int
        Maximum number of bases to include on each side of the junction.

    Returns
    -------
    consensus_seq : str
        The junction-spanning consensus.
    junction_offset : int
        0-based index in *consensus_seq* where the junction sits.
        ``consensus_seq[:junction_offset]`` is one side (insert or
        genome); ``consensus_seq[junction_offset:]`` is the other.
    n_reads_used : int
        Number of chimeric reads that contributed.
    insert_side : str
        ``"left"`` if the insert is to the left of the junction in the
        consensus string, ``"right"`` if to the right.
    """
    bam = pysam.AlignmentFile(bam_path, "rb")

    # Collect bases at each offset from the junction.
    # Negative offsets -> before the junction in the read (insert side
    # for left-clipped reads).  Positive -> after (genome side).
    offset_bases = collections.defaultdict(collections.Counter)
    n_reads_used = 0
    insert_left = 0
    insert_right = 0

    search_start = max(0, clip_pos - flank - 200)
    search_end = clip_pos + flank + 200

    for read in bam.fetch(chrom, search_start, search_end):
        if read.is_unmapped or not read.has_tag("SA"):
            continue
        if INSERT_CONTIG not in read.get_tag("SA"):
            continue

        ct = read.cigartuples
        seq = read.query_sequence
        if not seq or not ct:
            continue

        left_clip = ct[0][1] if ct[0][0] in (4, 5) else 0
        right_clip = ct[-1][1] if ct[-1][0] in (4, 5) else 0

        # Identify which clip is the insert (its genomic edge must be
        # close to clip_pos) and exclude any adapter clip on the far side.
        if left_clip > 0 and abs(read.reference_start - clip_pos) <= 20:
            # Insert on the left, genome on the right
            junction_in_read = left_clip
            usable_start = 0
            usable_end = len(seq) - (right_clip if right_clip > 0 else 0)
            insert_left += 1
        elif right_clip > 0 and abs(read.reference_end - clip_pos) <= 20:
            # Genome on the left, insert on the right
            junction_in_read = len(seq) - right_clip
            usable_start = left_clip if left_clip > 0 else 0
            usable_end = len(seq)
            insert_right += 1
        else:
            continue

        n_reads_used += 1
        for i in range(usable_start, usable_end):
            offset = i - junction_in_read
            if -flank <= offset <= flank:
                offset_bases[offset][seq[i].upper()] += 1

    bam.close()

    if not offset_bases:
        return "", 0, 0, "unknown"

    min_off = max(min(offset_bases.keys()), -flank)
    max_off = min(max(offset_bases.keys()), flank)

    consensus = []
    for offset in range(min_off, max_off + 1):
        if offset in offset_bases:
            consensus.append(offset_bases[offset].most_common(1)[0][0])
        else:
            consensus.append("N")

    junction_offset = -min_off  # 0-based position of junction in string
    insert_side = "left" if insert_left >= insert_right else "right"

    return "".join(consensus), junction_offset, n_reads_used, insert_side


def determine_orientation(cluster):
    """Determine insert orientation at junction from SA:Z strand.

    The SA strand tells us the alignment orientation of the insert
    portion: '+' means the insert is integrated in forward orientation,
    '-' means reverse complement.

    Returns
    -------
    dominant_strand : str
        Most common read mapping strand on the genome ('+' or '-').
    insert_orientation : str
        'forward' if the insert is in FWD orientation, 'reverse' if RC.
    """
    strand_counts = collections.Counter()
    sa_strand_counts = collections.Counter()
    for j in cluster:
        strand_counts[j.strand] += 1
        if j.sa_strand is not None:
            sa_strand_counts[j.sa_strand] += 1

    dominant_strand = strand_counts.most_common(1)[0][0]

    # Determine insert orientation from the SA strand on the insert contig
    if sa_strand_counts:
        dominant_sa = sa_strand_counts.most_common(1)[0][0]
        insert_orientation = "forward" if dominant_sa == "+" else "reverse"
    else:
        # Fallback for discordant-only clusters (shouldn't reach here
        # since those are skipped, but be safe)
        insert_orientation = "forward"

    return dominant_strand, insert_orientation


def run_junctions(args):
    """Main entry for 'junctions' subcommand."""
    bam_path = args.filtered_bam
    ref_fasta = args.ref_fasta
    out_bed = args.out_bed
    out_consensus = args.out_consensus_fa
    out_stats = args.out_stats

    print(f"Scanning {bam_path} for insert-genome junctions...")

    # Extract raw junctions
    raw_junctions = extract_junctions(bam_path)
    print(f"  Raw junction observations: {len(raw_junctions)}")

    # Keep only chimeric reads — discard discordant reads entirely.
    chimeric_types = {"sa_genomic", "primary_genomic"}
    chimeric_junctions = [j for j in raw_junctions if j.insert_end in chimeric_types]
    discordant_count = len(raw_junctions) - len(chimeric_junctions)
    print(f"  Chimeric observations: {len(chimeric_junctions)}  "
          f"(discarded {discordant_count} discordant)")

    # Group chimeric reads by exact (chrom, clip_pos).  Each unique
    # position becomes its own junction — no distance-based merging.
    by_pos = collections.defaultdict(list)
    for j in chimeric_junctions:
        if j.chrom == INSERT_CONTIG:
            continue
        by_pos[(j.chrom, j.pos)].append(j)

    # Sort by (chrom, pos) for deterministic output
    sorted_positions = sorted(by_pos.keys())
    print(f"  Distinct junction positions: {len(sorted_positions)}")

    # Build output
    bed_lines = []
    consensus_records = []
    stats_lines = [
        f"sample\t{Path(bam_path).stem.replace('.insertJunctions.noiseFiltered', '')}",
        f"raw_junction_observations\t{len(raw_junctions)}",
        f"chimeric_observations\t{len(chimeric_junctions)}",
        f"discordant_discarded\t{discordant_count}",
        f"distinct_junction_positions\t{len(sorted_positions)}",
    ]

    for idx, (chrom, clip_pos) in enumerate(sorted_positions, 1):
        group = by_pos[(chrom, clip_pos)]
        n_reads = len(group)
        dominant_strand, orientation = determine_orientation(group)

        junction_id = f"junction_{idx}_{chrom}_{clip_pos}"

        # Build junction-spanning consensus from chimeric read sequences.
        consensus_seq, junc_off, n_cons_reads, ins_side = \
            build_junction_spanning_consensus(bam_path, chrom, clip_pos)

        bed_lines.append(
            f"{chrom}\t{clip_pos}\t{clip_pos + 1}\t{junction_id}\t{n_reads}\t"
            f"{dominant_strand}\t{len(consensus_seq)}\t{orientation}\t{clip_pos}"
        )

        if consensus_seq:
            consensus_records.append(
                f">{junction_id} {chrom}:{clip_pos} "
                f"n_reads={n_reads} n_consensus_reads={n_cons_reads} "
                f"orientation={orientation} clip_pos={clip_pos} "
                f"junction_offset={junc_off} insert_side={ins_side}\n"
                f"{consensus_seq}"
            )

        stats_lines.append(
            f"junction_{idx}\t{chrom}:{clip_pos}\t"
            f"reads={n_reads}\tstrand={dominant_strand}\t"
            f"orientation={orientation}\tconsensus_len={len(consensus_seq)}\t"
            f"clip_pos={clip_pos}\tjunction_offset={junc_off}\t"
            f"insert_side={ins_side}"
        )

    # Write outputs
    os.makedirs(os.path.dirname(out_bed) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(out_consensus) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(out_stats) or ".", exist_ok=True)

    with open(out_bed, "w") as f:
        f.write("#chrom\tstart\tend\tjunction_id\tn_reads\tstrand\tconsensus_len\torientation\tclip_pos\n")
        f.write("\n".join(bed_lines) + "\n" if bed_lines else "")

    with open(out_consensus, "w") as f:
        f.write("\n".join(consensus_records) + "\n" if consensus_records else "")

    with open(out_stats, "w") as f:
        f.write("\n".join(stats_lines) + "\n")

    print(f"  Wrote {len(bed_lines)} junction(s) to {out_bed}")
    print(f"  Wrote {len(consensus_records)} consensus sequence(s) to {out_consensus}")
    print(f"  Stats: {out_stats}")


# ──────────────────────── Integration ────────────────────────────────

def parse_junction_bed(bed_path):
    """Parse junction BED file -> list of dicts."""
    sites = []
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split("\t")
            sites.append({
                "chrom": parts[0],
                "start": int(parts[1]),
                "end": int(parts[2]),
                "junction_id": parts[3],
                "n_reads": int(parts[4]),
                "strand": parts[5],
                "consensus_len": int(parts[6]) if len(parts) > 6 else 0,
                "orientation": parts[7] if len(parts) > 7 else "forward",
                "clip_pos": int(parts[8]) if len(parts) > 8 else None,
            })
    return sites


def reverse_complement(seq):
    """Return reverse complement of a DNA sequence."""
    comp = str.maketrans("ACGTacgt", "TGCAtgca")
    return seq.translate(comp)[::-1]


def read_fasta_dict(fasta_path):
    """Read a FASTA file into an ordered dict of {name: sequence}."""
    seqs = collections.OrderedDict()
    current_name = None
    current_seq = []

    with open(fasta_path) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if current_name is not None:
                    seqs[current_name] = "".join(current_seq)
                current_name = line[1:].split()[0]  # first word after >
                current_seq = []
            else:
                current_seq.append(line)
        if current_name is not None:
            seqs[current_name] = "".join(current_seq)

    return seqs


def write_fasta(seqs_dict, out_path, line_width=60):
    """Write an ordered dict of sequences to FASTA format."""
    with open(out_path, "w") as f:
        for name, seq in seqs_dict.items():
            f.write(f">{name}\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")


def run_integrate(args):
    """Main entry for 'integrate' subcommand."""
    ref_fasta = args.ref_fasta
    junction_bed = args.junction_bed
    insert_fasta = args.insert_fasta
    out_genome = args.out_genome_fa

    print(f"Reading reference: {ref_fasta}")
    ref_seqs = read_fasta_dict(ref_fasta)
    print(f"  {len(ref_seqs)} contigs")

    print(f"Reading insert sequence: {insert_fasta}")
    insert_seqs = read_fasta_dict(insert_fasta)
    # Use the first (and typically only) sequence
    insert_name = list(insert_seqs.keys())[0]
    insert_seq = insert_seqs[insert_name]
    print(f"  Insert contig: {insert_name} ({len(insert_seq)} bp)")

    print(f"Reading junction sites: {junction_bed}")
    sites = parse_junction_bed(junction_bed)
    print(f"  {len(sites)} junction site(s)")

    if not sites:
        print("  No junction sites found. Writing unmodified reference.")
        write_fasta(ref_seqs, out_genome)
        return

    # Group junction sites by chromosome and sort by position (descending)
    # so that inserting from right to left preserves coordinates
    by_chrom = collections.defaultdict(list)
    for site in sites:
        by_chrom[site["chrom"]].append(site)

    # For each chromosome, junction sites are paired or standalone.
    # Strategy:
    #   - If two junctions on the same chrom cluster closely (suggesting a
    #     deletion+insertion), the insert replaces the region between them.
    #   - If a single junction, the insert is spliced at that breakpoint.
    #
    # Paired junctions: if the gap between two sites on the same chrom is
    # < 10kb, treat them as a pair (left and right boundaries of integration).

    PAIR_MAX_DIST = 10000
    modifications = []  # list of (chrom, left_pos, right_pos, insert_to_splice)

    for chrom in sorted(by_chrom.keys()):
        chrom_sites = sorted(by_chrom[chrom], key=lambda s: s["start"])

        i = 0
        while i < len(chrom_sites):
            site = chrom_sites[i]

            # Try to pair with next site
            if i + 1 < len(chrom_sites):
                next_site = chrom_sites[i + 1]
                gap = next_site["start"] - site["end"]
                if gap < PAIR_MAX_DIST:
                    # Paired integration — insert replaces region between
                    # the two clip positions (true junction boundaries)
                    left_clip = site["clip_pos"]
                    right_clip = next_site["clip_pos"]
                    insert_to_use = insert_seq
                    # Check orientation
                    if site["orientation"] == "reverse":
                        insert_to_use = reverse_complement(insert_seq)

                    modifications.append({
                        "chrom": chrom,
                        "left": left_clip,
                        "right": right_clip,
                        "insert_seq": insert_to_use,
                        "junction_ids": f"{site['junction_id']};{next_site['junction_id']}",
                    })
                    i += 2
                    continue

            # Unpaired — insert at the chimeric clip position
            clip = site["clip_pos"]
            insert_to_use = insert_seq
            if site["orientation"] == "reverse":
                insert_to_use = reverse_complement(insert_seq)

            modifications.append({
                "chrom": chrom,
                "left": clip,
                "right": clip,  # no deletion, pure insertion
                "insert_seq": insert_to_use,
                "junction_ids": site["junction_id"],
            })
            i += 1

    # Apply modifications to reference (process each chrom's edits right-to-left)
    new_seqs = collections.OrderedDict(ref_seqs)

    # Remove the insert contig from the output (it's now integrated)
    if INSERT_CONTIG in new_seqs:
        del new_seqs[INSERT_CONTIG]

    # Group mods by chrom, sort by left descending to preserve coordinates
    mods_by_chrom = collections.defaultdict(list)
    for mod in modifications:
        mods_by_chrom[mod["chrom"]].append(mod)

    integration_log = []
    for chrom in sorted(mods_by_chrom.keys()):
        chrom_mods = sorted(mods_by_chrom[chrom], key=lambda m: m["left"], reverse=True)
        seq = new_seqs[chrom]
        for mod in chrom_mods:
            left = mod["left"]
            right = mod["right"]
            insert_s = mod["insert_seq"]

            original_len = len(seq)
            # Splice: seq[:left] + insert + seq[right:]
            seq = seq[:left] + insert_s + seq[right:]
            new_len = len(seq)

            log_entry = (
                f"  {chrom}:{left}-{right} "
                f"(replaced {right - left} bp with {len(insert_s)} bp insert) "
                f"genome {original_len} -> {new_len} bp "
                f"[{mod['junction_ids']}]"
            )
            integration_log.append(log_entry)
            print(log_entry)

        new_seqs[chrom] = seq

    # Write output
    os.makedirs(os.path.dirname(out_genome) or ".", exist_ok=True)
    write_fasta(new_seqs, out_genome)
    print(f"\nWrote integrated genome: {out_genome}")
    print(f"  Contigs: {len(new_seqs)}")
    total_bp = sum(len(s) for s in new_seqs.values())
    print(f"  Total size: {total_bp:,} bp")
    print(f"  Integration events: {len(modifications)}")


# ──────────────────── Local extraction ───────────────────────────────

DEFAULT_FLANK_MB = 1_000_000  # 1 Mb either side of the junction


def run_extract_local(args):
    """
    Extract ±flank bp around each junction site, splice the insert at
    the breakpoint, and write one contig per junction to a new FASTA.

    For paired junctions (two sites on the same chrom within 10 kb),
    the extracted window spans from (left_site - flank) to
    (right_site + flank) with the insert replacing the gap between them.

    Output contigs are named:
        <chrom>_<window_start>_<window_end>_<junction_id>
    so they can be mapped back to their genomic origin.
    """
    ref_fasta = args.ref_fasta
    junction_bed = args.junction_bed
    insert_fasta = args.insert_fasta
    out_fa = args.out_fa
    flank = args.flank

    print(f"Reading reference: {ref_fasta}")
    ref_seqs = read_fasta_dict(ref_fasta)
    print(f"  {len(ref_seqs)} contigs")

    print(f"Reading insert sequence: {insert_fasta}")
    insert_seqs = read_fasta_dict(insert_fasta)
    insert_name = list(insert_seqs.keys())[0]
    insert_seq = insert_seqs[insert_name]
    print(f"  Insert contig: {insert_name} ({len(insert_seq)} bp)")

    print(f"Reading junction sites: {junction_bed}")
    sites = parse_junction_bed(junction_bed)
    print(f"  {len(sites)} junction site(s)")
    print(f"  Flank size: {flank:,} bp")

    if not sites:
        print("  No junction sites found. Writing empty FASTA.")
        with open(out_fa, "w") as f:
            pass
        return

    # Group by chromosome
    by_chrom = collections.defaultdict(list)
    for site in sites:
        by_chrom[site["chrom"]].append(site)

    PAIR_MAX_DIST = 10000
    out_seqs = collections.OrderedDict()

    for chrom in sorted(by_chrom.keys()):
        if chrom not in ref_seqs:
            print(f"  WARNING: {chrom} not in reference, skipping")
            continue

        chrom_seq = ref_seqs[chrom]
        chrom_len = len(chrom_seq)
        chrom_sites = sorted(by_chrom[chrom], key=lambda s: s["start"])

        i = 0
        while i < len(chrom_sites):
            site = chrom_sites[i]

            # Try to pair with next site
            if i + 1 < len(chrom_sites):
                next_site = chrom_sites[i + 1]
                gap = next_site["start"] - site["end"]
                if gap < PAIR_MAX_DIST:
                    # Paired: window spans both sites, use clip positions
                    left_clip = site["clip_pos"]
                    right_clip = next_site["clip_pos"]
                    win_start = max(0, left_clip - flank)
                    win_end = min(chrom_len, right_clip + flank)

                    insert_to_use = insert_seq
                    if site["orientation"] == "reverse":
                        insert_to_use = reverse_complement(insert_seq)

                    # Build: left_flank + insert + right_flank
                    left_flank = chrom_seq[win_start:left_clip]
                    right_flank = chrom_seq[right_clip:win_end]
                    local_seq = left_flank + insert_to_use + right_flank

                    jid = f"{site['junction_id']};{next_site['junction_id']}"
                    contig_name = (
                        f"{chrom}_{win_start}_{win_end}_{jid}"
                    )
                    out_seqs[contig_name] = local_seq

                    print(
                        f"  Paired: {chrom}:{win_start}-{win_end} "
                        f"({len(local_seq):,} bp, insert at "
                        f"{left_clip}-{right_clip}) [{jid}]"
                    )
                    i += 2
                    continue

            # Unpaired: single junction — use chimeric clip position
            clip = site["clip_pos"]
            win_start = max(0, clip - flank)
            win_end = min(chrom_len, clip + flank)

            insert_to_use = insert_seq
            if site["orientation"] == "reverse":
                insert_to_use = reverse_complement(insert_seq)

            # Build: left_flank + insert + right_flank
            left_flank = chrom_seq[win_start:clip]
            right_flank = chrom_seq[clip:win_end]
            local_seq = left_flank + insert_to_use + right_flank

            jid = site["junction_id"]
            contig_name = f"{chrom}_{win_start}_{win_end}_{jid}"
            out_seqs[contig_name] = local_seq

            print(
                f"  Single: {chrom}:{win_start}-{win_end} "
                f"({len(local_seq):,} bp, insert at {clip}) [{jid}]"
            )
            i += 1

    # Write output
    os.makedirs(os.path.dirname(out_fa) or ".", exist_ok=True)
    write_fasta(out_seqs, out_fa)
    print(f"\nWrote local reference: {out_fa}")
    print(f"  Contigs: {len(out_seqs)}")
    total_bp = sum(len(s) for s in out_seqs.values())
    print(f"  Total size: {total_bp:,} bp")


# ──────────────────────── CLI ────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    subparsers = parser.add_subparsers(dest="command")

    # --- junctions ---
    p_junc = subparsers.add_parser("junctions",
                                    help="Detect junctions and build consensus")
    p_junc.add_argument("filtered_bam", help="Noise-filtered junction BAM")
    p_junc.add_argument("ref_fasta", help="Reference FASTA")
    p_junc.add_argument("out_bed", help="Output junction BED")
    p_junc.add_argument("out_consensus_fa", help="Output consensus FASTA")
    p_junc.add_argument("out_stats", help="Output stats file")

    # --- integrate ---
    p_int = subparsers.add_parser("integrate",
                                   help="Build new genome with insert integrated")
    p_int.add_argument("ref_fasta", help="Reference FASTA (hg38+eco)")
    p_int.add_argument("junction_bed", help="Junction BED from 'junctions' step")
    p_int.add_argument("insert_fasta", help="Insert sequence FASTA")
    p_int.add_argument("out_genome_fa", help="Output integrated genome FASTA")

    # --- extract_local ---
    p_loc = subparsers.add_parser("extract_local",
                                   help="Extract local regions around junctions "
                                        "and splice insert (small reference)")
    p_loc.add_argument("ref_fasta", help="Reference FASTA (hg38+eco)")
    p_loc.add_argument("junction_bed", help="Junction BED from 'junctions' step")
    p_loc.add_argument("insert_fasta", help="Insert sequence FASTA")
    p_loc.add_argument("out_fa", help="Output local reference FASTA")
    p_loc.add_argument("--flank", type=int, default=DEFAULT_FLANK_MB,
                        help=f"Flank size in bp (default: {DEFAULT_FLANK_MB})")

    args = parser.parse_args()
    if args.command == "junctions":
        run_junctions(args)
    elif args.command == "integrate":
        run_integrate(args)
    elif args.command == "extract_local":
        run_extract_local(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
