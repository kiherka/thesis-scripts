#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --job-name=smk_master_27843
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/slurm/smk_master_%j.out
#SBATCH --error=logs/slurm/smk_master_%j.err

set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27843

snakemake --profile profile --jobs 100
