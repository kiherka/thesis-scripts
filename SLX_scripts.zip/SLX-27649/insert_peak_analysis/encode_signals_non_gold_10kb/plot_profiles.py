#!/usr/bin/env python3
"""Plot individual ENCODE signal profiles at non-gold insert sites (10kb).

Creates separate profile plots for specified targets from the per-target
NPZ cache (produced by extract_encode_signals_non_gold.py).
"""

import os
import sys

import numpy as np

OUT_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis/encode_signals_non_gold_10kb/profiles"
CACHE_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis/encode_signals_non_gold_10kb/per_target_cache"

WINDOW = 10000
REGION_SIZE = 2 * WINDOW
NUM_BINS = 2000

TARGETS = [
    # Histone marks
    "H3K4me1", "H3K4me2", "H3K4me3",
    "H3K9ac", "H3K9me1", "H3K9me3",
    "H3K27ac", "H3K27me3",
    "H3K36me3", "H3K79me2",
    "H4K20me1", "H2AFZ",
    # TFs
    "SP1", "SMARCA4",
]


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(OUT_DIR, exist_ok=True)

    x = np.linspace(-WINDOW, WINDOW, NUM_BINS)

    for target in TARGETS:
        npz_path = os.path.join(CACHE_DIR, f"{target}.npz")
        if not os.path.exists(npz_path):
            print(f"SKIP {target}: no cache file")
            continue

        d = np.load(npz_path)
        median = d["median"]
        n_sites = int(d["n_sites"])

        if target in ("H3K4me1", "H3K4me2", "H3K4me3", "H3K9ac", "H3K27ac", "H2AFZ"):
            color = "#d73027"
        elif target in ("H3K9me3", "H3K27me3"):
            color = "#4575b4"
        elif target in ("H3K36me3", "H3K79me2", "H4K20me1", "H3K9me1"):
            color = "#ff7f00"
        else:
            color = "#2ca02c"

        fig, ax = plt.subplots(figsize=(8, 3.5))
        ax.plot(x, median, color=color, linewidth=1.5)
        ax.fill_between(x, 0, median, color=color, alpha=0.15)

        ax.axvline(0, color="grey", linestyle="--", linewidth=0.8, alpha=0.6)

        ax.set_xlabel("Distance from insert clip position (bp)")
        ax.set_ylabel("Median fold-change over control")
        ax.set_title(f"{target} signal at non-gold insert sites (10kb) (n={n_sites})")
        ax.set_xlim(-WINDOW, WINDOW)
        ax.set_ylim(bottom=0)

        plt.tight_layout()

        for ext in ("pdf", "png"):
            out_path = os.path.join(OUT_DIR, f"{target}_profile.{ext}")
            fig.savefig(out_path, dpi=200 if ext == "png" else None)
        plt.close()

        peak_val = np.max(median)
        peak_pos = x[np.argmax(median)]
        print(f"{target}: peak={peak_val:.3f} at {peak_pos:+.0f}bp, n={n_sites}")

    print(f"\nProfiles saved to {OUT_DIR}")


if __name__ == "__main__":
    main()
