#!/usr/bin/env python3
"""
Recompute fold-enrichment only, using the already-annotated insert data in
SLX-27649/insert_peak_analysis/location_analysis_new (all_inserts_summary.tsv
and gold_inserts_summary.tsv), producing SEPARATE fold-enrichment plots (and
TSVs) for all inserts and for BG4 gold-standard inserts.

Skips the expensive per-insert bedtools annotation step (already done and
saved in location_analysis_new/*_annotations.tsv & *_summary.tsv); only
rebuilds the reference feature BEDs needed to compute expected genome
background fractions, then computes observed/expected fold enrichment.
"""

import csv
import os
import shutil
import subprocess
import sys
import tempfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Reuse GTF/feature-BED-building helpers from the sibling location_analysis module.
LOCATION_ANALYSIS_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/location_analysis"
)
sys.path.insert(0, LOCATION_ANALYSIS_DIR)
from location_analysis import (  # noqa: E402
    CATEGORIES, BEDTOOLS, ENHANCER_PATH,
    gtf_to_bed, make_utr_beds, make_promoter_bed,
    compute_background_fractions, log,
)

NEW_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis/location_analysis_new"
)


def read_summary(path):
    """Read a *_summary.tsv into (counts dict, total)."""
    counts = {}
    total = 0
    with open(path) as f:
        reader = csv.DictReader(f, delimiter="\t")
        for r in reader:
            if r["annotation"] == "Total":
                total = int(r["count"])
            else:
                counts[r["annotation"]] = int(r["count"])
    return counts, total


def build_feature_beds(tmpdir):
    """Rebuild the reference annotation BED files needed for background fractions."""
    log("Preparing reference annotation BED files...")
    feature_beds_paths = {}

    gtf_to_bed("exon", os.path.join(tmpdir, "exon.bed"))
    feature_beds_paths["Exon"] = os.path.join(tmpdir, "exon.bed")

    gtf_to_bed("CDS", os.path.join(tmpdir, "cds.bed"))
    feature_beds_paths["CDS"] = os.path.join(tmpdir, "cds.bed")

    make_utr_beds(os.path.join(tmpdir, "utr5.bed"), os.path.join(tmpdir, "utr3.bed"))
    feature_beds_paths["5'UTR"] = os.path.join(tmpdir, "utr5.bed")
    feature_beds_paths["3'UTR"] = os.path.join(tmpdir, "utr3.bed")

    gtf_to_bed("gene", os.path.join(tmpdir, "gene.bed"))
    feature_beds_paths["Intron"] = os.path.join(tmpdir, "gene.bed")

    make_promoter_bed(os.path.join(tmpdir, "promoter.bed"))
    feature_beds_paths["Promoter"] = os.path.join(tmpdir, "promoter.bed")

    enhancer_sorted = os.path.join(tmpdir, "enhancer.bed")
    subprocess.check_call(
        "{} sort -i {} | {} merge -i - > {}".format(
            BEDTOOLS, ENHANCER_PATH, BEDTOOLS, enhancer_sorted
        ),
        shell=True
    )
    feature_beds_paths["Enhancer"] = enhancer_sorted

    return feature_beds_paths


def _style_ax(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def plot_fold_enrichment_single(counts, total, expected_fracs, title, color, out_path):
    """Bar chart of fold enrichment (observed/expected) for a single insert set."""
    cats = [c for c in CATEGORIES if expected_fracs.get(c, 0) > 0]
    obs = [counts.get(c, 0) / total if total > 0 else 0 for c in cats]
    expected = [expected_fracs.get(c, 0) for c in cats]
    fe = [o / e if e > 0 else 0 for o, e in zip(obs, expected)]

    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.bar(cats, fe, color=color, alpha=0.85, edgecolor="white", linewidth=0.6)
    ax.axhline(1.0, color="black", linestyle="--", linewidth=0.8, label="Expected (random)")
    for bar, v in zip(bars, fe):
        ax.text(bar.get_x() + bar.get_width() / 2, v + max(fe) * 0.02 if max(fe) > 0 else 0.02,
                 "{:.2f}x".format(v), ha="center", va="bottom", fontsize=8)

    ax.set_xticks(range(len(cats)))
    ax.set_xticklabels(cats, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel("Fold enrichment over random", fontsize=12)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    _style_ax(ax)

    fig.tight_layout()
    fig.savefig(out_path)
    plt.close()
    log("Saved {}".format(out_path))

    return cats, obs, expected, fe


def save_fold_enrichment_table(cats, obs, expected, fe, out_path):
    with open(out_path, "w") as f:
        f.write("annotation\tobserved_fraction\texpected_fraction\tfold_enrichment\n")
        for c, o, e, v in zip(cats, obs, expected, fe):
            f.write("{}\t{:.6f}\t{:.6f}\t{:.4f}\n".format(c, o, e, v))
    log("Saved {}".format(out_path))


def main():
    tmpdir = tempfile.mkdtemp(prefix="fold_enrichment_only_")

    all_counts, total_all = read_summary(os.path.join(NEW_DIR, "all_inserts_summary.tsv"))
    gold_counts, total_gold = read_summary(os.path.join(NEW_DIR, "gold_inserts_summary.tsv"))
    log("All inserts: n={}".format(total_all))
    log("Gold-standard inserts: n={}".format(total_gold))

    feature_beds_paths = build_feature_beds(tmpdir)

    log("\n=== FOLD ENRICHMENT (background) ===")
    expected_fracs = compute_background_fractions(feature_beds_paths, tmpdir)

    log("\n=== FOLD ENRICHMENT: ALL INSERTS ===")
    cats, obs, expected, fe = plot_fold_enrichment_single(
        all_counts, total_all, expected_fracs,
        "Fold enrichment of all inserts over random genomic background (n={})".format(total_all),
        "#4C72B0",
        os.path.join(NEW_DIR, "fold_enrichment_all.pdf"),
    )
    save_fold_enrichment_table(cats, obs, expected, fe, os.path.join(NEW_DIR, "fold_enrichment_all.tsv"))

    log("\n=== FOLD ENRICHMENT: GOLD-STANDARD INSERTS ===")
    cats, obs, expected, fe = plot_fold_enrichment_single(
        gold_counts, total_gold, expected_fracs,
        "Fold enrichment of BG4 gold-standard inserts over random genomic background (n={})".format(total_gold),
        "#55A868",
        os.path.join(NEW_DIR, "fold_enrichment_gold.pdf"),
    )
    save_fold_enrichment_table(cats, obs, expected, fe, os.path.join(NEW_DIR, "fold_enrichment_gold.tsv"))

    shutil.rmtree(tmpdir)
    log("\nDONE.")


if __name__ == "__main__":
    main()
