#!/usr/bin/env python3
"""Download ENCODE K562 bigwigs and extract signal at non-gold insert sites.

Same pipeline as encode_signals/extract_encode_signals.py but for all
non-gold-standard junctions from insert_peak_summary_bg4.tsv.
Uses hg38 clip positions (junction_location column) with a ±1kb window.

Resume-safe: per-target NPZ cache. Bigwigs are deleted after extraction.
"""

import csv
import os
import shutil
import sys
import time

import numpy as np

try:
    from urllib.request import urlretrieve
except ImportError:
    from urllib import urlretrieve

import pyBigWig

# -- Paths -------------------------------------------------------------------
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
SUMMARY_TSV = os.path.join(ANALYSIS_DIR, "insert_peak_summary_bg4.tsv")
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
MANIFEST = os.path.join(ANALYSIS_DIR, "encode_signals", "encode_bigwig_manifest.tsv")
BW_DIR = os.path.join(ANALYSIS_DIR, "encode_k562")
OUT_DIR = os.path.join(ANALYSIS_DIR, "encode_signals_non_gold")
CACHE_DIR = os.path.join(OUT_DIR, "per_target_cache")

WINDOW = 1000
REGION_SIZE = 2 * WINDOW
NUM_BINS = 400
MAX_RETRIES = 3


# -- Helpers -----------------------------------------------------------------
def parse_non_gold_sites(summary_tsv, gold_tsv):
    """Load all BG4 junctions, exclude gold-standard, return hg38 clip sites."""
    # Build gold keys
    gold_keys = set()
    with open(gold_tsv) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            gold_keys.add((row["sample"], row["chrom"],
                           row["region_start"], row["region_end"]))

    sites = []
    with open(summary_tsv) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            key = (row["sample"], row["chrom"],
                   row["region_start"], row["region_end"])
            if key in gold_keys:
                continue
            loc = row["junction_location"]
            chrom, pos = loc.split(":")
            sites.append((chrom, int(pos), row["orientation"]))
    return sites


def parse_manifest(tsv_path):
    entries = []
    with open(tsv_path) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            entries.append(row)
    return entries


def download_bigwig(url, dest, retries=MAX_RETRIES):
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return True
    tmp = dest + ".tmp"
    for attempt in range(1, retries + 1):
        try:
            urlretrieve(url, tmp)
            shutil.move(tmp, dest)
            return True
        except Exception as e:
            print(f"    attempt {attempt}/{retries} FAILED: {e}")
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            if attempt < retries:
                time.sleep(5 * attempt)
    return False


def extract_all_sites(bw_path, sites, window, num_bins):
    signals = []
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        for chrom, pos, orientation in sites:
            if chrom not in chroms:
                continue
            chrom_len = chroms[chrom]
            start = max(0, pos - window)
            end = min(chrom_len, pos + window)
            if end - start < window:
                continue
            vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
            arr = np.array([v if v is not None else 0.0 for v in vals])
            if orientation == "reverse":
                arr = arr[::-1]
            signals.append(arr)
    finally:
        bw.close()
    if not signals:
        return None
    return np.vstack(signals)


def cache_path(target):
    safe = target.replace("/", "_").replace(" ", "_")
    return os.path.join(CACHE_DIR, f"{safe}.npz")


# -- Main --------------------------------------------------------------------
def main():
    os.makedirs(BW_DIR, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)

    sites = parse_non_gold_sites(SUMMARY_TSV, GOLD_TSV)
    print(f"Non-gold insert sites: {len(sites)}")

    manifest = parse_manifest(MANIFEST)
    print(f"Manifest entries: {len(manifest)}")

    results = {}
    failed = []
    skipped_cached = 0

    for i, entry in enumerate(manifest):
        target = entry["target"]
        assay = entry["assay_category"]
        acc = entry["file_accession"]
        url = entry["url"]
        bw_file = os.path.join(BW_DIR, f"{acc}.bigWig")
        cp = cache_path(target)

        tag = f"[{i+1}/{len(manifest)}] {assay} / {target}"

        # Resume: load from cache
        if os.path.exists(cp):
            try:
                d = np.load(cp)
                results[target] = {
                    "assay": assay,
                    "median": d["median"],
                    "n_sites": int(d["n_sites"]),
                }
                skipped_cached += 1
                print(f"{tag}: cached (n={int(d['n_sites'])})")
                if os.path.exists(bw_file):
                    os.remove(bw_file)
                continue
            except Exception:
                pass

        # Download
        print(f"{tag}: downloading...", end=" ", flush=True)
        if not download_bigwig(url, bw_file):
            failed.append(target)
            continue

        # Extract
        print("extracting...", end=" ", flush=True)
        try:
            sigs = extract_all_sites(bw_file, sites, WINDOW, NUM_BINS)
        except Exception as e:
            print(f"EXTRACT ERROR: {e}")
            failed.append(target)
            continue

        if sigs is None or len(sigs) == 0:
            print("no signal")
            failed.append(target)
            if os.path.exists(bw_file):
                os.remove(bw_file)
            continue

        median_sig = np.median(sigs, axis=0)
        results[target] = {
            "assay": assay,
            "median": median_sig,
            "n_sites": sigs.shape[0],
        }

        # Cache per-target
        np.savez_compressed(cp, median=median_sig, n_sites=sigs.shape[0])

        # Delete bigwig to save disk
        try:
            os.remove(bw_file)
        except OSError:
            pass

        print(f"OK ({sigs.shape[0]} sites, peak={median_sig.max():.3f})")

    print(f"\nExtracted: {len(results)}, cached: {skipped_cached}, "
          f"failed: {len(failed)}")

    if not results:
        print("Nothing extracted -- exiting.")
        sys.exit(1)

    # -- Save combined profiles -----------------------------------------------
    targets_sorted = sorted(results.keys(),
                            key=lambda t: (results[t]["assay"], t))
    assays = [results[t]["assay"] for t in targets_sorted]
    medians = np.vstack([results[t]["median"] for t in targets_sorted])

    npz_path = os.path.join(OUT_DIR, "encode_signal_profiles.npz")
    np.savez_compressed(npz_path,
                        targets=np.array(targets_sorted),
                        assays=np.array(assays),
                        medians=medians,
                        window=WINDOW,
                        num_bins=NUM_BINS)
    print(f"Saved profiles: {npz_path}")

    # -- Summary TSV ----------------------------------------------------------
    tsv_path = os.path.join(OUT_DIR, "encode_signal_summary.tsv")
    with open(tsv_path, "w") as f:
        f.write("target\tassay\tn_sites\tmax_median\tmean_median\n")
        for t in targets_sorted:
            r = results[t]
            f.write(f"{t}\t{r['assay']}\t{r['n_sites']}\t"
                    f"{r['median'].max():.4f}\t{r['median'].mean():.4f}\n")
    print(f"Summary TSV: {tsv_path}")

    # -- Plots ----------------------------------------------------------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(-WINDOW, WINDOW, NUM_BINS)

    # 1) Heatmap
    fig, ax = plt.subplots(figsize=(10, max(6, len(targets_sorted) * 0.06)))
    normed = medians.copy()
    row_max = normed.max(axis=1, keepdims=True)
    row_max[row_max == 0] = 1
    normed = normed / row_max

    im = ax.imshow(normed, aspect="auto", cmap="RdYlBu_r",
                   extent=[-WINDOW, WINDOW, len(targets_sorted), 0],
                   interpolation="nearest")
    ax.axvline(0, color="black", linewidth=0.5, linestyle="--")
    ax.set_xlabel("Distance from insert clip position (bp)")
    ax.set_ylabel(f"ENCODE target (n={len(targets_sorted)})")
    ax.set_title("ENCODE K562 signal at non-gold insert sites\n"
                 "(row-normalised median fold-change)")

    prev_assay = None
    for idx, a in enumerate(assays):
        if a != prev_assay and prev_assay is not None:
            ax.axhline(idx, color="white", linewidth=1.5)
        prev_assay = a

    plt.colorbar(im, ax=ax, label="Normalised signal", shrink=0.6)
    plt.tight_layout()
    hm_path = os.path.join(OUT_DIR, "encode_heatmap_all.png")
    fig.savefig(hm_path, dpi=200)
    plt.close()
    print(f"Heatmap: {hm_path}")

    # 2) Category-aggregated traces
    cat_signals = {}
    for t in targets_sorted:
        a = results[t]["assay"]
        cat_signals.setdefault(a, []).append(results[t]["median"])

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = {"ATAC-seq": "#e41a1c", "DNase-seq": "#ff7f00",
              "Histone ChIP-seq": "#4daf4a", "TF ChIP-seq": "#377eb8"}
    for cat in ["ATAC-seq", "DNase-seq", "Histone ChIP-seq", "TF ChIP-seq"]:
        if cat not in cat_signals:
            continue
        stacked = np.vstack(cat_signals[cat])
        med = np.median(stacked, axis=0)
        ax.plot(x, med, label=f"{cat} (n={stacked.shape[0]})",
                color=colors.get(cat, "grey"), linewidth=1.5)
    ax.axvline(0, color="red", linewidth=0.8, linestyle="--", label="Clip position")
    ax.set_xlabel("Distance from insert clip position (bp)")
    ax.set_ylabel("Median fold-change over control")
    ax.set_title("ENCODE K562 signal at non-gold insert sites")
    ax.legend(fontsize=8)
    plt.tight_layout()
    cat_path = os.path.join(OUT_DIR, "encode_category_traces.png")
    fig.savefig(cat_path, dpi=200)
    plt.close()
    print(f"Category traces: {cat_path}")

    # 3) Top 20 enriched targets
    top_n = 20
    by_peak = sorted(results.items(), key=lambda x: x[1]["median"].max(),
                     reverse=True)
    fig, ax = plt.subplots(figsize=(10, 5))
    for rank, (t, r) in enumerate(by_peak[:top_n]):
        ax.plot(x, r["median"], linewidth=1.0, alpha=0.8,
                label=f"{t} ({r['assay'].split()[0]})")
    ax.axvline(0, color="red", linewidth=0.8, linestyle="--")
    ax.set_xlabel("Distance from insert clip position (bp)")
    ax.set_ylabel("Median fold-change over control")
    ax.set_title(f"Top {top_n} ENCODE targets by peak signal at non-gold insert sites")
    ax.legend(fontsize=6, ncol=2, loc="upper right")
    plt.tight_layout()
    top_path = os.path.join(OUT_DIR, "encode_top20_traces.png")
    fig.savefig(top_path, dpi=200)
    plt.close()
    print(f"Top-{top_n} traces: {top_path}")

    # 4) Histone marks
    histone_targets = [t for t in targets_sorted
                       if results[t]["assay"] == "Histone ChIP-seq"]
    if histone_targets:
        fig, ax = plt.subplots(figsize=(10, 5))
        for t in histone_targets:
            ax.plot(x, results[t]["median"], linewidth=1.2, label=t)
        ax.axvline(0, color="red", linewidth=0.8, linestyle="--")
        ax.set_xlabel("Distance from insert clip position (bp)")
        ax.set_ylabel("Median fold-change over control")
        ax.set_title("Histone marks at non-gold insert sites (K562)")
        ax.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        h_path = os.path.join(OUT_DIR, "encode_histone_traces.png")
        fig.savefig(h_path, dpi=200)
        plt.close()
        print(f"Histone traces: {h_path}")

    # 5) Open chromatin (ATAC + DNase)
    open_targets = [t for t in targets_sorted
                    if results[t]["assay"] in ("ATAC-seq", "DNase-seq")]
    if open_targets:
        fig, ax = plt.subplots(figsize=(10, 4))
        for t in open_targets:
            ax.plot(x, results[t]["median"], linewidth=1.5,
                    label=f"{t} ({results[t]['assay']})")
        ax.axvline(0, color="red", linewidth=0.8, linestyle="--")
        ax.set_xlabel("Distance from insert clip position (bp)")
        ax.set_ylabel("Median fold-change over control")
        ax.set_title("Open chromatin signal at non-gold insert sites (K562)")
        ax.legend(fontsize=8)
        plt.tight_layout()
        o_path = os.path.join(OUT_DIR, "encode_open_chromatin_traces.png")
        fig.savefig(o_path, dpi=200)
        plt.close()
        print(f"Open chromatin traces: {o_path}")

    print("\nDONE.")


if __name__ == "__main__":
    main()
