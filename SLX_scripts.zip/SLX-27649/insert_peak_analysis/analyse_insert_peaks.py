#!/usr/bin/env python3
"""
Analyse whether insert junction 2kb regions overlap with called peaks.

Scans peaks from **both** SLX-26997 (BG4 only) and SLX-27843
(BG4SIZE / BG4 / CUTAC), treating all wells as one batch.

For each sample whose well has a BED region file:
  - Check if the 2kb junction regions overlap SEACR and MACS2 peaks
  - Check how many EMPTY cell lines also have a peak at that same region
  - Empty controls are pooled across datasets per assay

Samples with < 1 M mapped reads (from flagstat) are excluded.

Outputs (per assay and combined):
  insert_peak_summary_<assay>.tsv
  gold_standard_junctions_<assay>.tsv
  insert_peak_summary_all.tsv / gold_standard_junctions_all.tsv
"""

import glob
import os
import re
import subprocess
import sys
import tempfile
from collections import defaultdict

# ── Paths ──────────────────────────────────────────────────────────────────────
BED_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis/bed_regions"
OUT_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"

# Integrated-genome directory (defines which wells have inserts)
INTEGRATED_DIR = (
    "/mnt/scratchc/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/integrated_genomes_combined"
)

MIN_MAPPED_READS = 1_000_000   # skip samples below this threshold
MAX_EMPTY_FRAC = 0.20          # gold-standard: peak in ≤20% of empty controls

# ── Datasets ──────────────────────────────────────────────────────────────────
DATASETS = {
    "SLX-26997": {
        "peaks_dir": "/mnt/scratchc/sblab/herka01/SLX-26997/peaks",
        "stats_dir": "/mnt/scratchc/sblab/herka01/SLX-26997/stats",
    },
    "SLX-27843": {
        "peaks_dir": "/mnt/scratchc/sblab/herka01/SLX-27843/peaks",
        "stats_dir": "/mnt/scratchc/sblab/herka01/SLX-27843/stats",
    },
}

# ── Well normalisation (strip leading zeros: 1A01 → 1A1) ──────────────────────
def normalise_well(well):
    m = re.match(r'^(\d+[A-H])0*(\d+)$', well)
    return f"{m.group(1)}{m.group(2)}" if m else well


def extract_well(sample_name):
    """BG4_1A01_B1 → 1A01 (raw, as in filename)."""
    m = re.match(r'^(?:BG4SIZE|BG4|CUTAC|SMARCA4)_(\w+)_B\d+$', sample_name)
    return m.group(1) if m else None


def extract_assay(sample_name):
    m = re.match(r'^(BG4SIZE|BG4|CUTAC|SMARCA4)', sample_name)
    return m.group(1) if m else None


# ── Identify insert wells (have a BED region file with real junctions) ─────────
_INSERT_WELLS_NORM = set()
for bed in glob.glob(os.path.join(BED_DIR, "SPLINK_*.insert_regions.bed")):
    w = os.path.basename(bed).replace("SPLINK_", "").replace(".insert_regions.bed", "")
    _INSERT_WELLS_NORM.add(normalise_well(w))

print(f"Insert wells (with BED region files): {len(_INSERT_WELLS_NORM)}")


def is_insert_well(well):
    return normalise_well(well) in _INSERT_WELLS_NORM


# ── Read mapped-read count from flagstat ──────────────────────────────────────
def get_mapped_reads(stats_dir, sample):
    """Parse 'primary mapped' count from samtools flagstat output."""
    path = os.path.join(stats_dir, f"{sample}.r1.hg38.sort.stats")
    if not os.path.exists(path):
        return None
    with open(path) as f:
        for line in f:
            if "primary mapped" in line:
                return int(line.split()[0])
    return None


# ── Discover samples across datasets ─────────────────────────────────────────
def discover_samples():
    """Walk both peak directories and build a full sample list."""
    samples = []
    for ds_name, ds in DATASETS.items():
        seacr_dir = os.path.join(ds["peaks_dir"], "seacr")
        if not os.path.isdir(seacr_dir):
            continue
        for fname in sorted(os.listdir(seacr_dir)):
            if not fname.endswith(".stringent.bed"):
                continue
            sample = fname.replace(".stringent.bed", "")
            assay = extract_assay(sample)
            well_raw = extract_well(sample)
            if well_raw is None or assay is None:
                continue
            if assay == "SMARCA4":
                continue
            well_norm = normalise_well(well_raw)
            samples.append({
                "dataset": ds_name,
                "assay": assay,
                "sample": sample,
                "well_raw": well_raw,
                "well_norm": well_norm,
                "peaks_dir": ds["peaks_dir"],
                "stats_dir": ds["stats_dir"],
            })
    return samples


all_samples = discover_samples()
print(f"Total samples discovered: {len(all_samples)}")

# ── Group into insert / empty ─────────────────────────────────────────────────
insert_samples = [s for s in all_samples if is_insert_well(s["well_raw"])]
empty_samples  = [s for s in all_samples if not is_insert_well(s["well_raw"])]
print(f"  Insert-well samples: {len(insert_samples)}")
print(f"  Empty-well samples:  {len(empty_samples)}")

# ── Filter by mapped reads ────────────────────────────────────────────────────
skipped_low_reads = 0
skipped_no_stats = 0


def passes_read_filter(s):
    global skipped_low_reads, skipped_no_stats
    n = get_mapped_reads(s["stats_dir"], s["sample"])
    if n is None:
        skipped_no_stats += 1
        return False
    if n < MIN_MAPPED_READS:
        skipped_low_reads += 1
        return False
    s["mapped_reads"] = n
    return True


insert_samples = [s for s in insert_samples if passes_read_filter(s)]
empty_samples  = [s for s in empty_samples if passes_read_filter(s)]
print(f"After ≥{MIN_MAPPED_READS:,} mapped-reads filter:")
print(f"  Insert-well samples: {len(insert_samples)}")
print(f"  Empty-well samples:  {len(empty_samples)}")
print(f"  Skipped (low reads): {skipped_low_reads}")
print(f"  Skipped (no stats):  {skipped_no_stats}")


# ── Helper: peak file lookup ──────────────────────────────────────────────────
def get_seacr_peak_file(peaks_dir, sample):
    path = os.path.join(peaks_dir, "seacr", f"{sample}.stringent.bed")
    return path if os.path.exists(path) else None


def get_macs2_peak_file(peaks_dir, sample):
    path = os.path.join(peaks_dir, "macs2", f"{sample}_peaks.narrowPeak")
    return path if os.path.exists(path) else None


def filter_chr_bed(peak_file, tmp_dir, tag=""):
    """Keep only chr* lines from a peak file (drop e.g. U00096.3)."""
    if peak_file is None:
        return None
    filtered = os.path.join(tmp_dir, os.path.basename(peak_file) + f".{tag}.chr.bed")
    with open(peak_file) as fin, open(filtered, "w") as fout:
        for line in fin:
            if line.startswith("chr"):
                fout.write(line)
    return filtered if os.path.getsize(filtered) > 0 else None


def bedtools_intersect_count(bed_a, bed_b):
    """Return set of region names in bed_a that overlap bed_b."""
    if not bed_b or not os.path.exists(bed_b):
        return set()
    try:
        result = subprocess.run(
            ["bedtools", "intersect", "-a", bed_a, "-b", bed_b, "-wa", "-u"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
        )
    except subprocess.CalledProcessError:
        return set()
    hit_names = set()
    for line in result.stdout.decode().strip().split("\n"):
        if line:
            hit_names.add(line.split("\t")[3])
    return hit_names


# ── Index empty samples by assay (pooled across all datasets) ─────────────────
empty_by_assay = defaultdict(list)
for s in empty_samples:
    empty_by_assay[s["assay"]].append(s)
for assay, elist in sorted(empty_by_assay.items()):
    print(f"  Empty controls for {assay}: {len(elist)}")


# ── Main analysis ─────────────────────────────────────────────────────────────
all_rows = []
gold_rows = []

with tempfile.TemporaryDirectory() as tmp_dir:
    for s in sorted(insert_samples,
                    key=lambda x: (x["dataset"], x["assay"], x["well_norm"])):
        well_norm = s["well_norm"]
        bed_file = os.path.join(BED_DIR, f"SPLINK_{well_norm}.insert_regions.bed")
        if not os.path.exists(bed_file):
            continue

        regions = []
        with open(bed_file) as f:
            for line in f:
                fields = line.strip().split("\t")
                regions.append({
                    "chrom": fields[0],
                    "start": int(fields[1]),
                    "end":   int(fields[2]),
                    "name":  fields[3],
                    "n_reads": fields[4],
                    "strand": fields[5],
                })
        if not regions:
            continue

        sample  = s["sample"]
        dataset = s["dataset"]
        assay   = s["assay"]

        # Peak files for this insert sample
        seacr_raw  = get_seacr_peak_file(s["peaks_dir"], sample)
        macs2_raw  = get_macs2_peak_file(s["peaks_dir"], sample)
        seacr_file = filter_chr_bed(seacr_raw, tmp_dir, tag=f"{sample}_s")
        macs2_file = filter_chr_bed(macs2_raw, tmp_dir, tag=f"{sample}_m")

        seacr_exists = seacr_file is not None
        macs2_exists = macs2_file is not None

        seacr_hits = (bedtools_intersect_count(bed_file, seacr_file)
                      if seacr_exists else set())
        macs2_hits = (bedtools_intersect_count(bed_file, macs2_file)
                      if macs2_exists else set())

        # Count overlaps from empty samples (same assay, pooled across datasets)
        empty_seacr_counts = defaultdict(int)
        empty_macs2_counts = defaultdict(int)
        n_empty_tested = 0

        for es in empty_by_assay[assay]:
            e_seacr = filter_chr_bed(
                get_seacr_peak_file(es["peaks_dir"], es["sample"]),
                tmp_dir, tag=f"{es['sample']}_es",
            )
            e_macs2 = filter_chr_bed(
                get_macs2_peak_file(es["peaks_dir"], es["sample"]),
                tmp_dir, tag=f"{es['sample']}_em",
            )
            n_empty_tested += 1
            if e_seacr:
                for name in bedtools_intersect_count(bed_file, e_seacr):
                    empty_seacr_counts[name] += 1
            if e_macs2:
                for name in bedtools_intersect_count(bed_file, e_macs2):
                    empty_macs2_counts[name] += 1

        # Build output rows
        for region in regions:
            name = region["name"]
            has_seacr = name in seacr_hits
            has_macs2 = name in macs2_hits
            n_empty_seacr = empty_seacr_counts.get(name, 0)
            n_empty_macs2 = empty_macs2_counts.get(name, 0)

            parts = name.split("|")
            junction_id  = parts[0]
            junction_loc = parts[1] if len(parts) > 1 else ""
            read_support = parts[2] if len(parts) > 2 else ""
            orient       = parts[3] if len(parts) > 3 else ""

            row = {
                "cell_line": well_norm,
                "dataset": dataset,
                "assay": assay,
                "sample": sample,
                "mapped_reads": s.get("mapped_reads", ""),
                "chrom": region["chrom"],
                "region_start": region["start"],
                "region_end": region["end"],
                "junction_id": junction_id,
                "junction_location": junction_loc,
                "read_support": read_support,
                "orientation": orient,
                "seacr_peak": has_seacr,
                "macs2_peak": has_macs2,
                "n_empty_seacr": n_empty_seacr,
                "n_empty_macs2": n_empty_macs2,
                "n_empty_total": n_empty_tested,
            }
            all_rows.append(row)

            # Gold standard: both callers detect peak AND peak absent
            # in ≥80 % of empty controls (present in ≤20 %)
            max_empty_allowed = int(MAX_EMPTY_FRAC * n_empty_tested)
            if (has_seacr and has_macs2
                    and n_empty_seacr <= max_empty_allowed
                    and n_empty_macs2 <= max_empty_allowed):
                gold_rows.append(row)

        # Print per-sample summary
        n_seacr = sum(1 for r in regions if r["name"] in seacr_hits)
        n_macs2 = sum(1 for r in regions if r["name"] in macs2_hits)
        n_both  = sum(1 for r in regions if r["name"] in seacr_hits
                      and r["name"] in macs2_hits)
        pk = (f"SEACR={'present' if seacr_exists else 'MISSING'}, "
              f"MACS2={'present' if macs2_exists else 'MISSING'}")
        print(
            f"  {dataset} {sample}: "
            f"{n_seacr}/{len(regions)} SEACR, "
            f"{n_macs2}/{len(regions)} MACS2, "
            f"{n_both} both  [{pk}]  "
            f"({s.get('mapped_reads', '?'):,} reads, "
            f"{n_empty_tested} empty controls)"
        )


# ── Write tables ──────────────────────────────────────────────────────────────
HEADER = [
    "cell_line", "dataset", "assay", "sample", "mapped_reads",
    "chrom", "region_start", "region_end",
    "junction_id", "junction_location", "read_support", "orientation",
    "seacr_peak", "macs2_peak",
    "n_empty_seacr", "n_empty_macs2", "n_empty_total",
]


def write_table(filepath, rows):
    with open(filepath, "w") as f:
        f.write("\t".join(HEADER) + "\n")
        for row in rows:
            f.write("\t".join(str(row[h]) for h in HEADER) + "\n")


# Per assay (pooled across datasets)
assays = sorted(set(r["assay"] for r in all_rows))
for assay in assays:
    tag = assay.lower()
    subset = [r for r in all_rows if r["assay"] == assay]
    gold   = [r for r in gold_rows if r["assay"] == assay]

    sf = os.path.join(OUT_DIR, f"insert_peak_summary_{tag}.tsv")
    gf = os.path.join(OUT_DIR, f"gold_standard_junctions_{tag}.tsv")
    write_table(sf, subset)
    write_table(gf, gold)
    print(f"\n{assay}: summary {len(subset)} rows → {sf}")
    print(f"{assay}: gold    {len(gold)} rows → {gf}")

# Combined
sf = os.path.join(OUT_DIR, "insert_peak_summary_all.tsv")
gf = os.path.join(OUT_DIR, "gold_standard_junctions_all.tsv")
write_table(sf, all_rows)
write_table(gf, gold_rows)
print(f"\nCombined summary: {sf}  ({len(all_rows)} rows)")
print(f"Combined gold:    {gf}  ({len(gold_rows)} rows)")
print("\nDONE.")
