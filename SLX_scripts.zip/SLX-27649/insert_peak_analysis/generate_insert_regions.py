#!/usr/bin/env python3
"""Generate BED regions around each insert integration site (integrated genome coords).

Each junction is an independent insert at clip_pos.
In the integrated genome the insert occupies [clip_pos, clip_pos + INSERT_LEN).
The BED region captures 1kb from either end of the insert:
  [clip_pos - 1kb, clip_pos + INSERT_LEN + 1kb).

Uses clip_pos (column 9) and orientation from the consensus junction BEDs.
"""

import glob
import os
from collections import defaultdict

# ── Paths ──────────────────────────────────────────────────────────────────────
CONSENSUS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined"
OUT_DIR       = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis/bed_regions"
FLANK         = 1000   # 1kb either side of the insert boundaries
INSERT_LEN    = 525    # DONOR_G3T1_108352 length (525 bp)

# Integrated genomes directory (per-well FAI files for boundary clipping)
INTEGRATED_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/integrated_genomes_combined"

# Clean output directory to remove stale files from previous runs
import shutil
if os.path.isdir(OUT_DIR):
    shutil.rmtree(OUT_DIR)
os.makedirs(OUT_DIR, exist_ok=True)


def load_chrom_sizes(well):
    """Load chromosome sizes from the integrated genome FAI for *well*."""
    fai = os.path.join(INTEGRATED_DIR, f"SPLINK_{well}.integrated.fa.fai")
    sizes = {}
    if os.path.exists(fai):
        with open(fai) as f:
            for line in f:
                parts = line.strip().split("\t")
                sizes[parts[0]] = int(parts[1])
    return sizes

# ── Parse a junction BED file (same as splink_consensus.py) ───────────────────
def parse_junction_bed(bed_path):
    sites = []
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split("\t")
            sites.append({
                "chrom":         parts[0],
                "start":         int(parts[1]),
                "end":           int(parts[2]),
                "junction_id":   parts[3],
                "n_reads":       int(parts[4]),
                "strand":        parts[5],
                "consensus_len": int(parts[6]) if len(parts) > 6 else 0,
                "orientation":   parts[7] if len(parts) > 7 else "forward",
                "clip_pos":      int(parts[8]) if len(parts) > 8 else int(parts[1]),
            })
    return sites

# ── Build one event per junction (each insert treated individually) ────────────
def make_events(sites):
    """Convert each junction site into an independent integration event."""
    events = []
    for site in sites:
        events.append({
            "chrom": site["chrom"],
            "left": site["clip_pos"],
            "junction_ids": site["junction_id"],
            "n_reads": site["n_reads"],
            "orientation": site["orientation"],
            "junction_locs": f"{site['chrom']}:{site['clip_pos']}",
        })
    return events

# ── Collect all wells with consensus junctions ────────────────────────────────
insert_wells = set()
for bed_file in glob.glob(os.path.join(CONSENSUS_DIR, "SPLINK_*.junctions.bed")):
    well = os.path.basename(bed_file).replace("SPLINK_", "").replace(".junctions.bed", "")
    insert_wells.add(well)

print(f"Wells with consensus junctions: {len(insert_wells)}")

# ── Generate BED regions for each cell line ───────────────────────────────────
total_regions = 0
for well in sorted(insert_wells):
    junctions_file = os.path.join(CONSENSUS_DIR, f"SPLINK_{well}.junctions.bed")
    if not os.path.exists(junctions_file):
        print(f"  WARNING: {junctions_file} not found, skipping well {well}")
        continue

    sites = parse_junction_bed(junctions_file)
    if not sites:
        print(f"  {well}: 0 junctions, skipping")
        continue

    events = make_events(sites)

    # ── Adjust for coordinate shift in the integrated genome ──────────
    # splink_consensus.py splices inserts right-to-left, so for N inserts
    # on the same chromosome sorted by hg38 position (p0 < p1 < … < pN),
    # the integrated-genome position of insert i is p_i + i * INSERT_LEN.
    by_chrom = defaultdict(list)
    for ev in events:
        by_chrom[ev["chrom"]].append(ev)
    for chrom_evts in by_chrom.values():
        chrom_evts.sort(key=lambda e: e["left"])
        for i, ev in enumerate(chrom_evts):
            ev["left"] += i * INSERT_LEN

    # Load per-well integrated-genome chromosome sizes
    chrom_len = load_chrom_sizes(well)

    out_file = os.path.join(OUT_DIR, f"SPLINK_{well}.insert_regions.bed")
    n = 0
    with open(out_file, "w") as fout:
        for ev in events:
            chrom = ev["chrom"]
            left  = ev["left"]

            # In the integrated genome the insert occupies
            # [left, left + INSERT_LEN).  Capture 1kb from either end:
            # region = [left - FLANK, left + INSERT_LEN + FLANK)
            region_start = left - FLANK
            region_end   = left + INSERT_LEN + FLANK

            # Clip to chromosome bounds
            region_start = max(0, region_start)
            if chrom in chrom_len:
                region_end = min(region_end, chrom_len[chrom])

            # Name encodes integration event info
            name = (
                f"{ev['junction_ids']}|{ev['junction_locs']}"
                f"|{ev['n_reads']}reads|{ev['orientation']}"
            )
            strand = "+" if ev["orientation"] == "forward" else "-"
            fout.write(f"{chrom}\t{region_start}\t{region_end}\t{name}\t{ev['n_reads']}\t{strand}\n")
            n += 1

    total_regions += n
    print(f"  {well}: {len(sites)} junctions → {n} insert regions → {out_file}")

print(f"\nTotal: {total_regions} insert regions generated across {len(insert_wells)} cell lines")
