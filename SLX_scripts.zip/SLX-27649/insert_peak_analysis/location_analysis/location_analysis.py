#!/usr/bin/env python3
"""
Genomic location analysis of insert sites using GENCODE annotation.

Annotates each insert's clip_pos against GENCODE features (enhancer, promoter,
exon/CDS/UTR, intron, intergenic) and produces pie charts and bar charts for:
  1. All inserts (3,871 across 679 cell lines)
  2. BG4 gold-standard inserts only (120 across 84 cell lines)

Uses bedtools CLI for intersections (pybedtools not available in Python 3.6 venv).
"""

import csv
import glob
import os
import re
import subprocess
import sys
import tempfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# ── Paths ──────────────────────────────────────────────────────────────────────
CONSENSUS_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/consensus_combined"
)
GTF_PATH = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/reference/gencode.v44.annotation.gtf"
)
ENHANCER_PATH = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/reference/fantom5_enhancers_hg38.bed"
)
GOLD_TSV = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "insert_peak_analysis/gold_standard_junctions_bg4.tsv"
)
OUT_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "insert_peak_analysis/location_analysis"
)
BEDTOOLS = "/home/herka01/miniforge3/bin/bedtools"

# Annotation priority (highest to lowest)
CATEGORIES = ["Enhancer", "Promoter", "CDS", "5'UTR", "3'UTR", "Exon", "Intron", "Intergenic"]
COLOURS = {
    "Enhancer":    "#e41a1c",
    "Promoter":    "#ff7f00",
    "CDS":         "#377eb8",
    "5'UTR":       "#4daf4a",
    "3'UTR":       "#984ea3",
    "Exon":        "#a65628",
    "Intron":      "#f781bf",
    "Intergenic":  "#999999",
}


# ── Helpers ────────────────────────────────────────────────────────────────────

def log(msg):
    print("[INFO] {}".format(msg), flush=True)


def collect_all_inserts():
    """Return list of dicts with chrom, clip_pos, well from all junction BEDs."""
    inserts = []
    for bed in sorted(glob.glob(os.path.join(CONSENSUS_DIR, "SPLINK_*.junctions.bed"))):
        well = os.path.basename(bed).replace("SPLINK_", "").replace(".junctions.bed", "")
        with open(bed) as f:
            for line in f:
                if line.startswith("#") or not line.strip():
                    continue
                parts = line.strip().split("\t")
                chrom = parts[0]
                clip_pos = int(parts[8]) if len(parts) > 8 else int(parts[1])
                inserts.append({
                    "well": well,
                    "chrom": chrom,
                    "clip_pos": clip_pos,
                })
    return inserts


def collect_gold_inserts():
    """Return list of dicts with chrom, clip_pos, well from gold-standard TSV."""
    inserts = []
    with open(GOLD_TSV) as f:
        reader = csv.DictReader(f, delimiter="\t")
        for r in reader:
            chrom, pos_str = r["junction_location"].split(":")
            inserts.append({
                "well": r["cell_line"],
                "chrom": chrom,
                "clip_pos": int(pos_str),
            })
    return inserts


def write_sites_bed(inserts, path):
    """Write inserts as a sorted BED file (single-bp at clip_pos)."""
    with open(path, "w") as f:
        for ins in inserts:
            f.write("{}\t{}\t{}\n".format(ins["chrom"], ins["clip_pos"], ins["clip_pos"] + 1))
    # Sort the BED
    sorted_path = path + ".sorted"
    subprocess.check_call(
        "{} sort -i {} > {}".format(BEDTOOLS, path, sorted_path),
        shell=True
    )
    os.rename(sorted_path, path)


def gtf_to_bed(feature_type, out_path):
    """Extract a feature type from GTF and write as sorted BED."""
    log("  Extracting {} from GTF...".format(feature_type))
    n = 0
    with open(GTF_PATH) as fin, open(out_path, "w") as fout:
        for line in fin:
            if line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) < 9:
                continue
            if fields[2] == feature_type:
                chrom = fields[0]
                start = int(fields[3]) - 1
                end = int(fields[4])
                fout.write("{}\t{}\t{}\n".format(chrom, start, end))
                n += 1
    # Sort and merge
    merged_path = out_path + ".merged"
    subprocess.check_call(
        "{} sort -i {} | {} merge -i - > {}".format(
            BEDTOOLS, out_path, BEDTOOLS, merged_path
        ),
        shell=True
    )
    os.rename(merged_path, out_path)
    log("    {} -> merged BED".format(n))


def make_utr_beds(utr5_path, utr3_path):
    """Create 5'UTR and 3'UTR BED files from GENCODE UTR + CDS + strand info.

    Strategy: for each transcript with CDS entries, the UTR regions before the
    CDS (in genomic coordinates considering strand) are 5'UTR, and after are 3'UTR.
    For + strand: UTR before CDS start = 5'UTR, UTR after CDS end = 3'UTR.
    For - strand: UTR after CDS end = 5'UTR, UTR before CDS start = 3'UTR.
    """
    log("  Building 5'UTR and 3'UTR from UTR + CDS...")

    # Collect CDS range per transcript
    tx_cds = {}  # transcript_id -> (min_start, max_end)
    tx_strand = {}
    with open(GTF_PATH) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) < 9 or fields[2] != "CDS":
                continue
            attrs = fields[8]
            m = re.search(r'transcript_id "([^"]+)"', attrs)
            if not m:
                continue
            tx_id = m.group(1)
            start = int(fields[3]) - 1
            end = int(fields[4])
            strand = fields[6]
            tx_strand[tx_id] = strand
            if tx_id not in tx_cds:
                tx_cds[tx_id] = (start, end)
            else:
                tx_cds[tx_id] = (min(tx_cds[tx_id][0], start), max(tx_cds[tx_id][1], end))

    n5, n3 = 0, 0
    with open(GTF_PATH) as f, open(utr5_path, "w") as f5, open(utr3_path, "w") as f3:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) < 9 or fields[2] != "UTR":
                continue
            attrs = fields[8]
            m = re.search(r'transcript_id "([^"]+)"', attrs)
            if not m:
                continue
            tx_id = m.group(1)
            if tx_id not in tx_cds:
                continue
            chrom = fields[0]
            start = int(fields[3]) - 1
            end = int(fields[4])
            strand = tx_strand.get(tx_id, "+")
            cds_start, cds_end = tx_cds[tx_id]

            if strand == "+":
                if end <= cds_start:
                    f5.write("{}\t{}\t{}\n".format(chrom, start, end))
                    n5 += 1
                elif start >= cds_end:
                    f3.write("{}\t{}\t{}\n".format(chrom, start, end))
                    n3 += 1
            else:
                if start >= cds_end:
                    f5.write("{}\t{}\t{}\n".format(chrom, start, end))
                    n5 += 1
                elif end <= cds_start:
                    f3.write("{}\t{}\t{}\n".format(chrom, start, end))
                    n3 += 1

    for path, label, count in [(utr5_path, "5'UTR", n5), (utr3_path, "3'UTR", n3)]:
        merged = path + ".merged"
        subprocess.check_call(
            "{} sort -i {} | {} merge -i - > {}".format(BEDTOOLS, path, BEDTOOLS, merged),
            shell=True
        )
        os.rename(merged, path)
        log("    {} entries -> {}: merged BED".format(count, label))


def make_promoter_bed(out_path):
    """Create promoter regions (1kb either side of gene TSS)."""
    log("  Creating promoter regions...")
    n = 0
    with open(GTF_PATH) as fin, open(out_path, "w") as fout:
        for line in fin:
            if line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) < 9:
                continue
            if fields[2] == "gene":
                chrom = fields[0]
                strand = fields[6]
                if strand == "+":
                    tss = int(fields[3]) - 1
                else:
                    tss = int(fields[4]) - 1
                start = max(0, tss - 1000)
                end = tss + 1000
                fout.write("{}\t{}\t{}\n".format(chrom, start, end))
                n += 1
    merged_path = out_path + ".merged"
    subprocess.check_call(
        "{} sort -i {} | {} merge -i - > {}".format(
            BEDTOOLS, out_path, BEDTOOLS, merged_path
        ),
        shell=True
    )
    os.rename(merged_path, out_path)
    log("    {} promoters -> merged BED".format(n))


def bedtools_intersect_count(sites_bed, feature_bed):
    """Return set of (chrom, start) that overlap feature_bed."""
    result = subprocess.check_output(
        "{} intersect -a {} -b {} -wa".format(BEDTOOLS, sites_bed, feature_bed),
        shell=True
    )
    hits = set()
    for line in result.decode().strip().split("\n"):
        if not line:
            continue
        parts = line.split("\t")
        hits.add((parts[0], int(parts[1])))
    return hits


def annotate_inserts(inserts, sites_bed, feature_beds):
    """Annotate each insert with genomic location by priority."""
    # Get overlap sets for each feature
    log("Running bedtools intersections...")
    overlap = {}
    for name, bed_path in feature_beds:
        hits = bedtools_intersect_count(sites_bed, bed_path)
        overlap[name] = hits
        log("  {}: {} overlaps".format(name, len(hits)))

    # Assign annotation by priority
    annotations = []
    priority = ["Enhancer", "Promoter", "CDS", "5'UTR", "3'UTR", "Exon", "Intron"]
    for ins in inserts:
        key = (ins["chrom"], ins["clip_pos"])
        ann = "Intergenic"
        for cat in priority:
            if cat in overlap and key in overlap[cat]:
                ann = cat
                break
        annotations.append(ann)
    return annotations


def count_annotations(annotations):
    """Return ordered dict of {category: count}."""
    counts = {}
    for cat in CATEGORIES:
        counts[cat] = 0
    for ann in annotations:
        counts[ann] = counts.get(ann, 0) + 1
    return counts


def _style_ax(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def plot_pie(counts, title, out_path):
    """Pie chart with percentages."""
    labels = [c for c in CATEGORIES if counts.get(c, 0) > 0]
    values = [counts[c] for c in labels]
    colors = [COLOURS[c] for c in labels]
    total = sum(values)

    fig, ax = plt.subplots(figsize=(8, 8))
    wedges, texts, autotexts = ax.pie(
        values, labels=labels, autopct=lambda p: "{:.1f}%\n({:d})".format(p, int(round(p * total / 100))),
        startangle=90, counterclock=False, colors=colors,
        textprops={"fontsize": 10}
    )
    for t in autotexts:
        t.set_fontsize(8)
    ax.set_title(title, fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close()
    log("Saved {}".format(out_path))


def plot_bar(counts, title, out_path):
    """Bar chart with absolute numbers and percentages on top."""
    labels = [c for c in CATEGORIES if counts.get(c, 0) > 0]
    values = [counts[c] for c in labels]
    colors = [COLOURS[c] for c in labels]
    total = sum(values)

    fig, ax = plt.subplots(figsize=(10, 5))
    bars = ax.bar(labels, values, color=colors, edgecolor="white", linewidth=0.6, alpha=0.85)
    for bar, v in zip(bars, values):
        pct = 100.0 * v / total if total > 0 else 0
        ax.text(bar.get_x() + bar.get_width() / 2, v + max(values) * 0.01,
                "{}\n({:.1f}%)".format(v, pct),
                ha="center", va="bottom", fontsize=8)
    ax.set_xlabel("Genomic annotation", fontsize=12)
    ax.set_ylabel("Number of inserts", fontsize=12)
    ax.set_title(title, fontsize=13, fontweight="bold")
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close()
    log("Saved {}".format(out_path))


def save_table(inserts, annotations, out_path):
    """Save per-insert annotation TSV."""
    with open(out_path, "w") as f:
        f.write("cell_line\tchrom\tclip_pos\tannotation\n")
        for ins, ann in zip(inserts, annotations):
            f.write("{}\t{}\t{}\t{}\n".format(ins["well"], ins["chrom"], ins["clip_pos"], ann))
    log("Saved {}".format(out_path))


def save_summary(counts, total, out_path):
    """Save summary TSV with counts and percentages."""
    with open(out_path, "w") as f:
        f.write("annotation\tcount\tpercentage\n")
        for cat in CATEGORIES:
            c = counts.get(cat, 0)
            pct = 100.0 * c / total if total > 0 else 0
            f.write("{}\t{}\t{:.2f}\n".format(cat, c, pct))
        f.write("Total\t{}\t100.00\n".format(total))
    log("Saved {}".format(out_path))


def compute_background_fractions(feature_beds_paths, tmpdir):
    """Compute expected genome fraction for each annotation category (priority-adjusted).

    Subtracts higher-priority categories from lower-priority beds so each
    genomic base is counted only once, matching the annotation priority logic.
    Uses GRCh38 primary assembly size for the intergenic fraction.

    Returns dict: category -> fraction of genome.
    """
    log("Computing background genome fractions...")
    HG38_GENOME_SIZE = 3_088_269_832  # GRCh38 primary assembly (chr1-22, X, Y, MT)

    priority = ["Enhancer", "Promoter", "CDS", "5'UTR", "3'UTR", "Exon", "Intron"]
    bed_map = {
        "Enhancer": feature_beds_paths["Enhancer"],
        "Promoter": feature_beds_paths["Promoter"],
        "CDS":      feature_beds_paths["CDS"],
        "5'UTR":    feature_beds_paths["5'UTR"],
        "3'UTR":    feature_beds_paths["3'UTR"],
        "Exon":     feature_beds_paths["Exon"],
        "Intron":   feature_beds_paths["Intron"],
    }

    fracs = {}
    accumulated = []  # higher-priority BED paths, built up as we go

    for cat in priority:
        bed = bed_map[cat]
        if accumulated:
            # Subtract all higher-priority regions in one bedtools call
            cmd = "{} subtract -a {} -b {} | awk '{{sum += $3-$2}} END {{print sum+0}}'".format(
                BEDTOOLS, bed, " ".join(accumulated)
            )
        else:
            cmd = "awk '{{sum += $3-$2}} END {{print sum+0}}' {}".format(bed)
        size = int(subprocess.check_output(cmd, shell=True).decode().strip() or "0")
        fracs[cat] = size / HG38_GENOME_SIZE
        log("  {}: {:,} bp ({:.2f}%)".format(cat, size, fracs[cat] * 100))
        accumulated.append(bed)

    intergenic_bp = max(0, HG38_GENOME_SIZE - sum(int(f * HG38_GENOME_SIZE) for f in fracs.values()))
    fracs["Intergenic"] = intergenic_bp / HG38_GENOME_SIZE
    log("  Intergenic: {:,} bp ({:.2f}%)".format(intergenic_bp, fracs["Intergenic"] * 100))

    return fracs


def plot_fold_enrichment(all_counts, gold_counts, total_all, total_gold, expected_fracs, out_path):
    """Bar chart showing fold enrichment (observed fraction / expected fraction) per category."""
    cats = [c for c in CATEGORIES if expected_fracs.get(c, 0) > 0]

    all_obs  = [all_counts.get(c, 0)  / total_all  if total_all  > 0 else 0 for c in cats]
    gold_obs = [gold_counts.get(c, 0) / total_gold if total_gold > 0 else 0 for c in cats]
    expected = [expected_fracs.get(c, 0) for c in cats]

    all_fe  = [o / e if e > 0 else 0 for o, e in zip(all_obs,  expected)]
    gold_fe = [o / e if e > 0 else 0 for o, e in zip(gold_obs, expected)]

    x = np.arange(len(cats))
    w = 0.35

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(x - w / 2, all_fe,  w, color="#4C72B0", alpha=0.85, label="All inserts (n={})".format(total_all))
    ax.bar(x + w / 2, gold_fe, w, color="#55A868", alpha=0.85, label="BG4 gold-standard (n={})".format(total_gold))
    ax.axhline(1.0, color="black", linestyle="--", linewidth=0.8, label="Expected (random)")

    ax.set_xticks(x)
    ax.set_xticklabels(cats, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel("Fold enrichment over random", fontsize=12)
    ax.set_title("Fold enrichment of insert sites over random genomic background",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    _style_ax(ax)

    fig.tight_layout()
    fig.savefig(out_path)
    plt.close()
    log("Saved {}".format(out_path))


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    tmpdir = tempfile.mkdtemp(prefix="location_analysis_")
    # Stage all outputs to fast local /tmp to avoid Lustre write hangs;
    # copy to OUT_DIR in one step at the very end.
    stagedir = tempfile.mkdtemp(prefix="location_analysis_out_")

    # ── Prepare reference BED files ────────────────────────────────────────
    log("Preparing reference annotation BED files...")
    feature_beds_paths = {}

    gtf_to_bed("exon", os.path.join(tmpdir, "exon.bed"))
    feature_beds_paths["Exon"] = os.path.join(tmpdir, "exon.bed")

    gtf_to_bed("CDS", os.path.join(tmpdir, "cds.bed"))
    feature_beds_paths["CDS"] = os.path.join(tmpdir, "cds.bed")

    make_utr_beds(os.path.join(tmpdir, "utr5.bed"), os.path.join(tmpdir, "utr3.bed"))
    feature_beds_paths["5'UTR"] = os.path.join(tmpdir, "utr5.bed")
    feature_beds_paths["3'UTR"] = os.path.join(tmpdir, "utr3.bed")

    gtf_to_bed("gene", os.path.join(tmpdir, "gene.bed"))
    feature_beds_paths["Intron"] = os.path.join(tmpdir, "gene.bed")

    make_promoter_bed(os.path.join(tmpdir, "promoter.bed"))
    feature_beds_paths["Promoter"] = os.path.join(tmpdir, "promoter.bed")

    # Copy enhancer BED (already in BED format)
    enhancer_sorted = os.path.join(tmpdir, "enhancer.bed")
    subprocess.check_call(
        "{} sort -i {} | {} merge -i - > {}".format(
            BEDTOOLS, ENHANCER_PATH, BEDTOOLS, enhancer_sorted
        ),
        shell=True
    )
    feature_beds_paths["Enhancer"] = enhancer_sorted

    # Build ordered list for intersection
    feature_list = [
        ("Enhancer", feature_beds_paths["Enhancer"]),
        ("Promoter", feature_beds_paths["Promoter"]),
        ("CDS", feature_beds_paths["CDS"]),
        ("5'UTR", feature_beds_paths["5'UTR"]),
        ("3'UTR", feature_beds_paths["3'UTR"]),
        ("Exon", feature_beds_paths["Exon"]),
        ("Intron", feature_beds_paths["Intron"]),
    ]

    # ── All inserts ────────────────────────────────────────────────────────
    log("\n=== ALL INSERTS ===")
    all_inserts = collect_all_inserts()
    log("Total inserts: {}".format(len(all_inserts)))

    all_bed = os.path.join(tmpdir, "all_sites.bed")
    write_sites_bed(all_inserts, all_bed)

    all_annotations = annotate_inserts(all_inserts, all_bed, feature_list)
    all_counts = count_annotations(all_annotations)
    total_all = len(all_annotations)

    log("All inserts annotation summary:")
    for cat in CATEGORIES:
        c = all_counts.get(cat, 0)
        log("  {}: {} ({:.1f}%)".format(cat, c, 100.0 * c / total_all))

    save_table(all_inserts, all_annotations, os.path.join(stagedir, "all_inserts_annotations.tsv"))
    save_summary(all_counts, total_all, os.path.join(stagedir, "all_inserts_summary.tsv"))
    plot_pie(all_counts, "Genomic location of all inserts (n={})".format(total_all),
             os.path.join(stagedir, "all_inserts_pie.svg"))
    plot_bar(all_counts, "Genomic location of all inserts (n={})".format(total_all),
             os.path.join(stagedir, "all_inserts_bar.svg"))

    # ── Gold-standard inserts ──────────────────────────────────────────────
    log("\n=== GOLD-STANDARD INSERTS ===")
    gold_inserts = collect_gold_inserts()
    log("Gold-standard inserts: {}".format(len(gold_inserts)))

    gold_bed = os.path.join(tmpdir, "gold_sites.bed")
    write_sites_bed(gold_inserts, gold_bed)

    gold_annotations = annotate_inserts(gold_inserts, gold_bed, feature_list)
    gold_counts = count_annotations(gold_annotations)
    total_gold = len(gold_annotations)

    log("Gold-standard annotation summary:")
    for cat in CATEGORIES:
        c = gold_counts.get(cat, 0)
        log("  {}: {} ({:.1f}%)".format(cat, c, 100.0 * c / total_gold))

    save_table(gold_inserts, gold_annotations, os.path.join(stagedir, "gold_inserts_annotations.tsv"))
    save_summary(gold_counts, total_gold, os.path.join(stagedir, "gold_inserts_summary.tsv"))
    plot_pie(gold_counts, "Genomic location of BG4 gold-standard inserts (n={})".format(total_gold),
             os.path.join(stagedir, "gold_inserts_pie.svg"))
    plot_bar(gold_counts, "Genomic location of BG4 gold-standard inserts (n={})".format(total_gold),
             os.path.join(stagedir, "gold_inserts_bar.svg"))

    # ── Side-by-side comparison ────────────────────────────────────────────
    log("\n=== COMPARISON PLOT ===")
    cats = [c for c in CATEGORIES if all_counts.get(c, 0) > 0 or gold_counts.get(c, 0) > 0]

    # Percentage comparison
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    x = np.arange(len(cats))
    w = 0.35
    all_pcts = [100.0 * all_counts.get(c, 0) / total_all for c in cats]
    gold_pcts = [100.0 * gold_counts.get(c, 0) / total_gold for c in cats]

    ax1.bar(x - w / 2, all_pcts, w, color="#4C72B0", alpha=0.85, label="All (n={})".format(total_all))
    ax1.bar(x + w / 2, gold_pcts, w, color="#55A868", alpha=0.85, label="Gold (n={})".format(total_gold))
    ax1.set_xticks(x)
    ax1.set_xticklabels(cats, rotation=30, ha="right", fontsize=9)
    ax1.set_ylabel("Percentage (%)", fontsize=11)
    ax1.set_title("Genomic location (percentage)", fontsize=12)
    ax1.legend(fontsize=9)
    _style_ax(ax1)

    # Absolute comparison
    all_abs = [all_counts.get(c, 0) for c in cats]
    gold_abs = [gold_counts.get(c, 0) for c in cats]

    ax2.bar(x - w / 2, all_abs, w, color="#4C72B0", alpha=0.85, label="All (n={})".format(total_all))
    ax2.bar(x + w / 2, gold_abs, w, color="#55A868", alpha=0.85, label="Gold (n={})".format(total_gold))
    ax2.set_xticks(x)
    ax2.set_xticklabels(cats, rotation=30, ha="right", fontsize=9)
    ax2.set_ylabel("Number of inserts", fontsize=11)
    ax2.set_title("Genomic location (absolute)", fontsize=12)
    ax2.legend(fontsize=9)
    _style_ax(ax2)

    fig.suptitle("All inserts vs BG4 gold-standard", fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(os.path.join(stagedir, "comparison_all_vs_gold.svg"))
    plt.close()
    log("Saved comparison plot")

    # ── Fold enrichment vs random ──────────────────────────────────────────
    log("\n=== FOLD ENRICHMENT ===")
    expected_fracs = compute_background_fractions(feature_beds_paths, tmpdir)
    plot_fold_enrichment(
        all_counts, gold_counts, total_all, total_gold,
        expected_fracs,
        os.path.join(stagedir, "fold_enrichment.svg")
    )

    # Copy staged outputs to Lustre OUT_DIR in one bulk operation
    import shutil
    log("\nCopying output files to {}...".format(OUT_DIR))
    os.makedirs(OUT_DIR, exist_ok=True)
    for fname in os.listdir(stagedir):
        src = os.path.join(stagedir, fname)
        dst = os.path.join(OUT_DIR, fname)
        shutil.copy2(src, dst)
        log("  copied {}".format(fname))

    # Cleanup temp files
    shutil.rmtree(tmpdir)
    shutil.rmtree(stagedir)

    log("\nDONE.")


if __name__ == "__main__":
    main()
