#!/usr/bin/env python3
"""
Histograms of insert counts per cell line from consensus junction BED files.

Counts the number of inserts (junctions with unique clip_pos) per cell line
from the consensus_combined SPLINK_*.junctions.bed files.

Generates:
  1. All samples – integer-bin histogram + binned bar chart
  2. Plates 1–4 vs Plates 5–8 – side-by-side binned bar charts
  3. BG4 gold-standard cell lines only (84) – integer-bin + binned

Usage:
    python insert_number_analysis.py
"""

import os
import re
import glob

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

matplotlib.rcParams['font.family'] = 'Helvetica Neue'
matplotlib.rcParams['svg.fonttype'] = 'none'

# ── Paths ──────────────────────────────────────────────────────────────────────
CONSENSUS_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/consensus_combined"
)
GOLD_TSV = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "insert_peak_analysis/gold_standard_junctions_bg4.tsv"
)
OUT_DIR = (
    "/scratche/slow/sblab/herka01/SLX-27649/"
    "insert_peak_analysis/insert_number_analysis"
)

# Bin definitions
BIN_EDGES = [(0, 0), (1, 1), (2, 3), (4, 6), (7, 10), (11, 15), (16, None)]
BIN_LABELS = ["0", "1", "2–3", "4–6", "7–10", "11–15", "16+"]


# ── Helpers ────────────────────────────────────────────────────────────────────

def count_inserts_per_well():
    """Return {well: n_inserts} from consensus junction BED files."""
    counts = {}
    for bed in sorted(glob.glob(os.path.join(CONSENSUS_DIR, "SPLINK_*.junctions.bed"))):
        well = os.path.basename(bed).replace("SPLINK_", "").replace(".junctions.bed", "")
        n = 0
        with open(bed) as f:
            for line in f:
                if line.startswith("#") or not line.strip():
                    continue
                n += 1
        counts[well] = n
    return counts


def get_plate(well):
    """Extract plate number from well name, e.g. '3A7' → 3."""
    m = re.match(r"^(\d+)", well)
    return int(m.group(1)) if m else None


def load_gold_wells():
    """Return set of gold-standard cell line names from BG4 TSV."""
    wells = set()
    with open(GOLD_TSV) as f:
        header = f.readline()
        for line in f:
            parts = line.strip().split("\t")
            wells.add(parts[0])
    return wells



def _style_ax(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def _assign_bin(value, edges, labels):
    for (lo, hi), lab in zip(edges, labels):
        if hi is None:
            if value >= lo:
                return lab
        elif lo <= value <= hi:
            return lab
    return labels[-1]


def _binned_bar(ax, values, edges, bin_labels, colour, label):
    counts = {lab: 0 for lab in bin_labels}
    for v in values:
        counts[_assign_bin(v, edges, bin_labels)] += 1
    heights = [counts[lab] for lab in bin_labels]
    bars = ax.bar(bin_labels, heights, color=colour, edgecolor="white",
                  linewidth=0.6, alpha=0.85, label=label)
    for bar, h in zip(bars, heights):
        if h > 0:
            ax.text(bar.get_x() + bar.get_width() / 2, h + 0.5, str(h),
                    ha="center", va="bottom", fontsize=8)


def _print_summary(label, values):
    arr = np.array(values)
    print("  {}: n={} median={:.0f} mean={:.1f} min={} max={} total={}".format(
        label, len(arr), np.median(arr), arr.mean(), arr.min(), arr.max(), arr.sum()))


# ── Plot functions ─────────────────────────────────────────────────────────────

def plot_all_standard(counts, out):
    """Integer-bin histogram for all samples."""
    vals = list(counts.values())
    lo, hi = min(vals), max(vals)
    bins = np.arange(lo - 0.5, hi + 1.5, 1)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(vals, bins=bins, color="#4C72B0", edgecolor="white",
            linewidth=0.5, alpha=0.85, label="All samples (n={})".format(len(vals)))
    ax.set_xlabel("Number of inserts per cell line", fontsize=12)
    ax.set_ylabel("Number of cell lines", fontsize=12)
    ax.set_title("Insert counts per cell line – all samples", fontsize=13)
    ax.legend(fontsize=10)
    xticks = np.arange(lo, hi + 1)
    if len(xticks) > 30:
        xticks = xticks[::max(1, len(xticks) // 20)]
    ax.set_xticks(xticks)
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out)
    plt.close()
    print("Saved {}".format(out))
    _print_summary("All samples", vals)


def plot_all_binned(counts, out):
    """Binned bar chart for all samples."""
    vals = list(counts.values())

    fig, ax = plt.subplots(figsize=(8, 5))
    _binned_bar(ax, vals, BIN_EDGES, BIN_LABELS, "#4C72B0",
                "All samples (n={})".format(len(vals)))
    ax.set_xlabel("Number of inserts", fontsize=12)
    ax.set_ylabel("Number of cell lines", fontsize=12)
    ax.set_title("Insert counts per cell line – binned (all samples)", fontsize=13)
    ax.legend(fontsize=10)
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out)
    plt.close()
    print("Saved {}".format(out))


def plot_plates(counts, out):
    """Side-by-side binned bar charts for Plates 1–4 vs Plates 5–8."""
    p14 = [v for w, v in counts.items() if get_plate(w) in (1, 2, 3, 4)]
    p58 = [v for w, v in counts.items() if get_plate(w) in (5, 6, 7, 8)]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    _binned_bar(ax1, p14, BIN_EDGES, BIN_LABELS, "#4C72B0",
                "Plates 1–4 (n={})".format(len(p14)))
    ax1.set_xlabel("Number of inserts", fontsize=12)
    ax1.set_ylabel("Number of cell lines", fontsize=12)
    ax1.set_title("Plates 1–4", fontsize=13)
    ax1.legend(fontsize=10)
    _style_ax(ax1)

    _binned_bar(ax2, p58, BIN_EDGES, BIN_LABELS, "#DD8452",
                "Plates 5–8 (n={})".format(len(p58)))
    ax2.set_xlabel("Number of inserts", fontsize=12)
    ax2.set_ylabel("Number of cell lines", fontsize=12)
    ax2.set_title("Plates 5–8", fontsize=13)
    ax2.legend(fontsize=10)
    _style_ax(ax2)

    fig.suptitle("Insert counts by plate group", fontsize=14, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(out)
    plt.close()
    print("Saved {}".format(out))
    _print_summary("Plates 1-4", p14)
    _print_summary("Plates 5-8", p58)


def plot_plates_standard(counts, out):
    """Integer-bin histograms for Plates 1–4 vs Plates 5–8."""
    p14 = [v for w, v in counts.items() if get_plate(w) in (1, 2, 3, 4)]
    p58 = [v for w, v in counts.items() if get_plate(w) in (5, 6, 7, 8)]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5), sharey=True)

    all_vals = p14 + p58
    lo, hi = min(all_vals), max(all_vals)
    bins = np.arange(lo - 0.5, hi + 1.5, 1)

    ax1.hist(p14, bins=bins, color="#4C72B0", edgecolor="white",
             linewidth=0.5, alpha=0.85, label="Plates 1–4 (n={})".format(len(p14)))
    ax1.set_xlabel("Number of inserts", fontsize=12)
    ax1.set_ylabel("Number of cell lines", fontsize=12)
    ax1.set_title("Plates 1–4", fontsize=13)
    ax1.legend(fontsize=10)
    _style_ax(ax1)

    ax2.hist(p58, bins=bins, color="#DD8452", edgecolor="white",
             linewidth=0.5, alpha=0.85, label="Plates 5–8 (n={})".format(len(p58)))
    ax2.set_xlabel("Number of inserts", fontsize=12)
    ax2.set_title("Plates 5–8", fontsize=13)
    ax2.legend(fontsize=10)
    _style_ax(ax2)

    xticks = np.arange(lo, hi + 1)
    if len(xticks) > 30:
        step = max(1, len(xticks) // 20)
        xticks = xticks[::step]
    ax1.set_xticks(xticks)
    ax2.set_xticks(xticks)

    fig.suptitle("Insert counts by plate group", fontsize=14, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(out)
    plt.close()
    print("Saved {}".format(out))


def plot_gold_standard(counts, gold_wells, out_standard, out_binned):
    """Histograms for the 84 BG4 gold-standard cell lines only."""
    gold_counts = {w: counts[w] for w in gold_wells if w in counts}
    missing = gold_wells - set(gold_counts.keys())
    if missing:
        print("  Warning: {} gold wells not in junction files: {}".format(
            len(missing), sorted(missing)))

    vals = list(gold_counts.values())
    print("Gold-standard cell lines with junction data: {}".format(len(vals)))
    _print_summary("Gold standard", vals)

    # Integer-bin histogram
    lo, hi = min(vals), max(vals)
    bins = np.arange(lo - 0.5, hi + 1.5, 1)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(vals, bins=bins, color="#55A868", edgecolor="white",
            linewidth=0.5, alpha=0.85,
            label="Gold standard (n={})".format(len(vals)))
    ax.set_xlabel("Number of inserts per cell line", fontsize=12)
    ax.set_ylabel("Number of cell lines", fontsize=12)
    ax.set_title("Insert counts – BG4 gold-standard cell lines", fontsize=13)
    ax.legend(fontsize=10)
    xticks = np.arange(lo, hi + 1)
    if len(xticks) > 30:
        xticks = xticks[::max(1, len(xticks) // 20)]
    ax.set_xticks(xticks)
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out_standard)
    plt.close()
    print("Saved {}".format(out_standard))

    # Binned bar chart
    fig, ax = plt.subplots(figsize=(8, 5))
    _binned_bar(ax, vals, BIN_EDGES, BIN_LABELS, "#55A868",
                "Gold standard (n={})".format(len(vals)))
    ax.set_xlabel("Number of inserts", fontsize=12)
    ax.set_ylabel("Number of cell lines", fontsize=12)
    ax.set_title("Insert counts – BG4 gold-standard cell lines (binned)", fontsize=13)
    ax.legend(fontsize=10)
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out_binned)
    plt.close()
    print("Saved {}".format(out_binned))


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Count inserts per well (all 679 with junction files, including
    # those with zero inserts)
    counts = count_inserts_per_well()
    print("Total cell lines with junction files: {}".format(len(counts)))
    n_zero = sum(1 for v in counts.values() if v == 0)
    print("  ({} with zero inserts, {} with at least one)".format(
        n_zero, len(counts) - n_zero))

    # Summary TSV
    tsv_path = os.path.join(OUT_DIR, "insert_counts_per_cell_line.tsv")
    with open(tsv_path, "w") as f:
        f.write("cell_line\tplate\tn_inserts\n")
        for w in sorted(counts.keys(), key=lambda x: (get_plate(x) or 0, x)):
            f.write("{}\t{}\t{}\n".format(w, get_plate(w), counts[w]))
    print("Saved {}".format(tsv_path))

    # 1. All samples
    plot_all_standard(counts, os.path.join(OUT_DIR, "all_samples_standard.pdf"))
    plot_all_binned(counts, os.path.join(OUT_DIR, "all_samples_binned.pdf"))

    # 2. Plates 1–4 vs Plates 5–8
    plot_plates(counts, os.path.join(OUT_DIR, "plates_1_4_vs_5_8_binned.pdf"))
    plot_plates_standard(counts, os.path.join(OUT_DIR, "plates_1_4_vs_5_8_standard.pdf"))

    # 3. Gold-standard cell lines
    gold_wells = load_gold_wells()
    print("Gold-standard cell lines: {}".format(len(gold_wells)))
    plot_gold_standard(
        counts, gold_wells,
        os.path.join(OUT_DIR, "gold_standard_standard.pdf"),
        os.path.join(OUT_DIR, "gold_standard_binned.pdf"),
    )

    print("\nDONE.")


if __name__ == "__main__":
    main()
