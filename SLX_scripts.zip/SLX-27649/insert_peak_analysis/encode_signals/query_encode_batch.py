#!/usr/bin/env python3
"""Query ENCODE files API directly for K562 signal bigwigs (batch approach).

Uses the ENCODE file search endpoint to get all bigWig signal files for K562
in a single query per assay type. Much faster than per-experiment queries.
"""

import json
import os
import sys

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode

ENCODE_BASE = "https://www.encodeproject.org"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_TSV = os.path.join(OUT_DIR, "encode_bigwig_manifest.tsv")


def encode_file_search(assay_title):
    """Query ENCODE for all released hg38 bigWig signal files for K562."""
    params = {
        "type": "File",
        "file_format": "bigWig",
        "assembly": "GRCh38",
        "status": "released",
        "dataset.biosample_ontology.term_name": "K562",
        "dataset.assay_title": assay_title,
        "dataset.status": "released",
        "format": "json",
        "limit": "all",
        "field": [
            "accession", "href", "output_type", "biological_replicates",
            "dataset", "assembly", "file_format",
        ],
    }
    url = ENCODE_BASE + "/search/?" + urlencode(params, doseq=True)
    req = Request(url, headers={"Accept": "application/json"})
    resp = urlopen(req)
    data = json.loads(resp.read().decode("utf-8"))
    return data.get("@graph", [])


def get_experiment_target(exp_path):
    """Fetch target label from an experiment path."""
    url = ENCODE_BASE + exp_path + "?format=json&field=target.label&field=assay_title"
    req = Request(url, headers={"Accept": "application/json"})
    resp = urlopen(req)
    data = json.loads(resp.read().decode("utf-8"))
    target = data.get("target", {})
    if isinstance(target, dict):
        return target.get("label", data.get("assay_title", "unknown"))
    return data.get("assay_title", "unknown")


def main():
    assays = ["TF ChIP-seq", "Histone ChIP-seq", "ATAC-seq", "DNase-seq"]

    # ── Fetch all bigWig files in batch ────────────────────────────────
    all_files = []
    for assay in assays:
        print(f"Querying {assay}...", end=" ", flush=True)
        files = encode_file_search(assay)
        print(f"{len(files)} bigWig files")
        for f in files:
            f["_assay"] = assay
        all_files.extend(files)

    print(f"\nTotal bigWig files: {len(all_files)}")

    # ── Group by experiment (dataset) ──────────────────────────────────
    by_experiment = {}
    for f in all_files:
        ds = f.get("dataset", "")
        if isinstance(ds, str):
            exp_acc = ds.rstrip("/").split("/")[-1]
        else:
            exp_acc = "unknown"
        if exp_acc not in by_experiment:
            by_experiment[exp_acc] = {"assay": f["_assay"], "files": [], "path": ds}
        by_experiment[exp_acc]["files"].append(f)

    print(f"Unique experiments: {len(by_experiment)}")

    # ── Pick best bigwig per experiment (fold change > signal p-value > signal)
    def score_file(f):
        ot = f.get("output_type", "")
        if "fold change" in ot:
            s = 3
        elif "signal p-value" in ot:
            s = 2
        elif "signal" in ot.lower():
            s = 1
        else:
            s = 0
        n_reps = len(f.get("biological_replicates", []))
        return (s, n_reps)

    best_per_exp = {}
    for exp_acc, info in by_experiment.items():
        scored = [(score_file(f), f) for f in info["files"]]
        scored.sort(key=lambda x: x[0], reverse=True)
        if scored and scored[0][0][0] > 0:
            best_per_exp[exp_acc] = {
                "file": scored[0][1],
                "assay": info["assay"],
                "path": info["path"],
            }

    print(f"Experiments with usable signal bigwig: {len(best_per_exp)}")

    # ── Now fetch target labels (batch: unique experiment paths) ───────
    # Group experiments by path to deduplicate
    exp_paths = {}
    for exp_acc, info in best_per_exp.items():
        path = info["path"]
        if isinstance(path, str) and path.startswith("/"):
            exp_paths[exp_acc] = path

    print(f"\nFetching target labels for {len(exp_paths)} experiments...")

    target_cache = {}
    errors = 0
    for i, (exp_acc, path) in enumerate(sorted(exp_paths.items())):
        try:
            target_cache[exp_acc] = get_experiment_target(path)
        except Exception:
            target_cache[exp_acc] = "unknown"
            errors += 1
        if (i + 1) % 100 == 0:
            print(f"  {i+1}/{len(exp_paths)} targets fetched...")

    print(f"Target labels fetched ({errors} errors)")

    # ── Group by target, pick one experiment per target ────────────────
    by_target = {}
    for exp_acc, info in best_per_exp.items():
        assay = info["assay"]
        target = target_cache.get(exp_acc, "unknown")
        key = (assay, target)
        f = info["file"]
        score = score_file(f)
        if key not in by_target or score > by_target[key]["score"]:
            href = f.get("href", "")
            if href and not href.startswith("http"):
                href = ENCODE_BASE + href
            by_target[key] = {
                "assay_category": assay,
                "target": target,
                "experiment": exp_acc,
                "file_accession": f.get("accession", "?"),
                "output_type": f.get("output_type", "?"),
                "bio_reps": ",".join(str(r) for r in f.get("biological_replicates", [])),
                "url": href,
                "score": score,
            }

    print(f"\nUnique (assay, target) to download: {len(by_target)}")

    # ── Write manifest ─────────────────────────────────────────────────
    cols = ["assay_category", "target", "experiment", "file_accession",
            "output_type", "bio_reps", "url"]
    with open(OUT_TSV, "w") as f:
        f.write("\t".join(cols) + "\n")
        for key in sorted(by_target.keys()):
            r = by_target[key]
            f.write("\t".join(r[c] for c in cols) + "\n")

    print(f"Manifest written: {OUT_TSV}")
    print(f"\nBreakdown by assay:")
    from collections import Counter
    ac = Counter(r["assay_category"] for r in by_target.values())
    for a, n in ac.most_common():
        print(f"  {a}: {n}")


if __name__ == "__main__":
    main()
