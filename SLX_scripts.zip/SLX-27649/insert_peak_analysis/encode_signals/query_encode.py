#!/usr/bin/env python3
"""Query ENCODE for all K562 TF/histone ChIP-seq + ATAC-seq + DNase-seq
fold-change-over-control signal bigwig files (hg38).

Picks one representative bigwig per target (preferring fold change over control,
then signal p-value, from the latest experiment with the most replicates).

Outputs a TSV of download URLs and metadata.
"""

import json
import os
import sys

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode

ENCODE_BASE = "https://www.encodeproject.org"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_TSV = os.path.join(OUT_DIR, "encode_bigwig_manifest.tsv")


def encode_search(params):
    """Query ENCODE search API and return all results."""
    params["format"] = "json"
    params["limit"] = "all"
    url = ENCODE_BASE + "/search/?" + urlencode(params, doseq=True)
    req = Request(url, headers={"Accept": "application/json"})
    resp = urlopen(req)
    data = json.loads(resp.read().decode("utf-8"))
    return data.get("@graph", [])


def get_experiment_files(accession):
    """Get file list for an experiment."""
    url = ENCODE_BASE + "/experiments/" + accession + "/?format=json"
    req = Request(url, headers={"Accept": "application/json"})
    resp = urlopen(req)
    data = json.loads(resp.read().decode("utf-8"))
    return data.get("files", [])


def pick_best_bigwig(files):
    """From a list of file objects, pick the best hg38 signal bigwig.

    Priority: fold change over control > signal p-value > signal (other)
    Prefer released files and those with more biological replicates.
    """
    candidates = []
    for f in files:
        if isinstance(f, str):
            # Sometimes files are just paths; skip
            continue
        if f.get("file_format") != "bigWig":
            continue
        if f.get("assembly") != "GRCh38":
            continue
        if f.get("status") != "released":
            continue
        output_type = f.get("output_type", "")
        # Score by output type preference
        if "fold change" in output_type:
            score = 3
        elif "signal p-value" in output_type:
            score = 2
        elif "signal" in output_type.lower():
            score = 1
        else:
            continue
        n_reps = len(f.get("biological_replicates", []))
        candidates.append((score, n_reps, f))

    if not candidates:
        return None
    # Sort by score desc, then number of replicates desc
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return candidates[0][2]


def main():
    # ── Query experiments ──────────────────────────────────────────────
    assays = [
        ("TF ChIP-seq", {"type": "Experiment", "biosample_ontology.term_name": "K562",
                          "assay_title": "TF ChIP-seq", "status": "released"}),
        ("Histone ChIP-seq", {"type": "Experiment", "biosample_ontology.term_name": "K562",
                               "assay_title": "Histone ChIP-seq", "status": "released"}),
        ("ATAC-seq", {"type": "Experiment", "biosample_ontology.term_name": "K562",
                      "assay_title": "ATAC-seq", "status": "released"}),
        ("DNase-seq", {"type": "Experiment", "biosample_ontology.term_name": "K562",
                       "assay_title": "DNase-seq", "status": "released"}),
    ]

    all_experiments = []
    for assay_name, params in assays:
        params_query = dict(params)
        params_query["field"] = ["accession", "target.label", "assay_title",
                                 "date_released"]
        exps = encode_search(params_query)
        print(f"{assay_name}: {len(exps)} experiments")
        for e in exps:
            e["_assay_category"] = assay_name
        all_experiments.extend(exps)

    print(f"\nTotal experiments to scan: {len(all_experiments)}")

    # ── Group by target ────────────────────────────────────────────────
    # For ATAC/DNase there's no target, use assay name
    by_target = {}
    for exp in all_experiments:
        target = exp.get("target", {}).get("label", exp.get("assay_title", "unknown"))
        category = exp["_assay_category"]
        key = (category, target)
        if key not in by_target:
            by_target[key] = []
        by_target[key].append(exp)

    print(f"Unique (assay, target) combinations: {len(by_target)}")

    # ── For each target, pick the best experiment + bigwig ─────────────
    results = []
    errors = 0
    for i, ((category, target), exps) in enumerate(sorted(by_target.items())):
        # Pick latest experiment
        exps.sort(key=lambda e: e.get("date_released", ""), reverse=True)
        best_bw = None
        best_exp = None
        for exp in exps[:3]:  # Try up to 3 most recent
            acc = exp["accession"]
            try:
                files = get_experiment_files(acc)
                bw = pick_best_bigwig(files)
                if bw:
                    best_bw = bw
                    best_exp = exp
                    break
            except Exception as ex:
                errors += 1
                continue

        if best_bw and best_exp:
            href = best_bw.get("href", "")
            if href and not href.startswith("http"):
                href = ENCODE_BASE + href
            results.append({
                "assay_category": category,
                "target": target,
                "experiment": best_exp["accession"],
                "file_accession": best_bw.get("accession", "?"),
                "output_type": best_bw.get("output_type", "?"),
                "url": href,
                "bio_reps": ",".join(str(r) for r in best_bw.get("biological_replicates", [])),
            })

        if (i + 1) % 50 == 0:
            print(f"  Processed {i+1}/{len(by_target)} targets ({len(results)} found)")

    print(f"\nFound bigwigs for {len(results)}/{len(by_target)} targets ({errors} API errors)")

    # ── Write manifest ─────────────────────────────────────────────────
    cols = ["assay_category", "target", "experiment", "file_accession",
            "output_type", "bio_reps", "url"]
    with open(OUT_TSV, "w") as f:
        f.write("\t".join(cols) + "\n")
        for r in sorted(results, key=lambda x: (x["assay_category"], x["target"])):
            f.write("\t".join(r[c] for c in cols) + "\n")

    print(f"Manifest written: {OUT_TSV}")


if __name__ == "__main__":
    main()
