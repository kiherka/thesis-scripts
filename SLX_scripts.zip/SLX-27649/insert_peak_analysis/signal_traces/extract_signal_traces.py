#!/usr/bin/env python3
"""Extract CPM signal from bigwig files over gold-standard insert regions.

For each gold-standard junction (BG4 only), extracts the CPM signal from the
corresponding bigwig file over the 20525bp region (10kb flank + 525bp insert +
10kb flank) in integrated-genome coordinates.

Averages the signal across all gold-standard inserts and plots as a line graph.
"""

import csv
import os
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/scratche/slow/sblab/herka01/SLX-27649/insert_peak_analysis"
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
BED_DIR = os.path.join(ANALYSIS_DIR, "bed_regions")
# Write to local /tmp to avoid NFS write-cache stalls on /scratche/slow/
OUT_DIR = "/tmp/herka01_signal_traces_10kb"
NFS_OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces_10kb")

BIGWIG_DIRS = {
    "SLX-26997": "/scratche/slow/sblab/herka01/SLX-26997/bigwigs",
    "SLX-27843": "/scratche/slow/sblab/herka01/SLX-27843/bigwigs",
}

FLANK_SIZE = 10000   # bp of context either side of insert
OLD_FLANK  = 1000    # flank used when region_start/region_end were precomputed
INSERT_SIZE = 525
REGION_SIZE = FLANK_SIZE * 2 + INSERT_SIZE  # 20525
NUM_BINS = 500       # resolution for signal extraction


def get_bigwig_path(dataset, sample):
    bw_dir = BIGWIG_DIRS.get(dataset)
    if not bw_dir:
        return None
    path = os.path.join(bw_dir, f"{sample}.cpm.bw")
    return path if os.path.exists(path) else None


def extract_signal(bw_path, chrom, start, end, num_bins):
    """Extract CPM signal from bigwig, return array of length num_bins."""
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        # Clip to chromosome bounds
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        # Replace None with 0
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    # Read gold standard junctions
    with open(GOLD_TSV) as f:
        rows = list(csv.DictReader(f, delimiter="\t"))

    print(f"Gold standard junctions: {len(rows)}")

    all_signals = []
    skipped = 0

    for row in rows:
        dataset = row["dataset"]
        sample = row["sample"]
        chrom = row["chrom"]
        start = int(row["region_start"])
        end = int(row["region_end"])
        orientation = row["orientation"]

        # Recover insert coordinates from the pre-computed 1kb-flanked region,
        # then re-apply the new FLANK_SIZE.
        insert_start = start + OLD_FLANK
        insert_end   = end   - OLD_FLANK
        start = insert_start - FLANK_SIZE
        end   = insert_end   + FLANK_SIZE

        bw_path = get_bigwig_path(dataset, sample)
        if bw_path is None:
            print(f"  SKIP {sample}: no bigwig")
            skipped += 1
            continue

        signal = extract_signal(bw_path, chrom, start, end, NUM_BINS)
        if signal is None:
            print(f"  SKIP {sample} {chrom}:{start}-{end}: no signal")
            skipped += 1
            continue

        # Flip reverse-oriented inserts so all are shown in forward direction
        if orientation == "reverse":
            signal = signal[::-1]

        all_signals.append(signal)

    print(f"Extracted: {len(all_signals)}, skipped: {skipped}")

    if not all_signals:
        print("No signals extracted, exiting.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)
    q25 = np.percentile(signals, 25, axis=0)
    q75 = np.percentile(signals, 75, axis=0)

    # Write to local /tmp — NFS filesystem (/scratche/slow/) hangs on writes.
    # After completion, copy from /tmp/herka01_signal_traces_10kb/ to NFS.
    import io as _io

    def _write_bytes(data_bytes, dest_path):
        """Write bytes to a local file."""
        with open(dest_path, "wb") as fh:
            fh.write(data_bytes)

    os.makedirs(OUT_DIR, exist_ok=True)

    for arr, name in [(median_signal, "median_signal.tsv"),
                      (q25,           "q25_signal.tsv"),
                      (q75,           "q75_signal.tsv")]:
        buf = _io.BytesIO()
        np.savetxt(buf, arr, delimiter="\t")
        _write_bytes(buf.getvalue(), os.path.join(OUT_DIR, name))
        print(f"Saved {name}")

    buf = _io.BytesIO()
    np.save(buf, signals)
    _write_bytes(buf.getvalue(), os.path.join(OUT_DIR, "all_signals.npy"))
    print("Saved all_signals.npy")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import io as _mpl_io

    # Use Helvetica Neue Light for all text
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Helvetica Neue", "HelveticaNeue-Light",
                                        "Helvetica", "Arial"]
    plt.rcParams["font.weight"] = "light"
    plt.rcParams["axes.titleweight"] = "light"
    plt.rcParams["axes.labelweight"] = "light"

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    # Mark insert boundaries
    ax.axvline(FLANK_SIZE, color="red", linestyle="--", linewidth=0.8,
               label="Insert boundary")
    ax.axvline(FLANK_SIZE + INSERT_SIZE, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(FLANK_SIZE, FLANK_SIZE + INSERT_SIZE, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(f"BG4 signal at gold-standard insert sites (n={len(all_signals)})")

    # Custom x-tick labels
    mid = FLANK_SIZE + INSERT_SIZE // 2
    ticks  = [0, FLANK_SIZE // 2, FLANK_SIZE, mid,
              FLANK_SIZE + INSERT_SIZE,
              FLANK_SIZE + INSERT_SIZE + FLANK_SIZE // 2,
              REGION_SIZE]
    labels = ["-10 kb", "-5 kb", "Insert\nstart", "Insert\nmid",
              "Insert\nend", "+5 kb", "+10 kb"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    # Render each format to a memory buffer, then write to NFS in 8 KB chunks.
    out_pdf = os.path.join(OUT_DIR, "gold_standard_signal_trace_10kb.pdf")
    out_png = os.path.join(OUT_DIR, "gold_standard_signal_trace_10kb.png")
    out_svg = os.path.join(OUT_DIR, "gold_standard_signal_trace_10kb.svg")

    for fmt, path in [("pdf", out_pdf), ("png", out_png), ("svg", out_svg)]:
        buf = _mpl_io.BytesIO()
        fig.savefig(buf, format=fmt, dpi=(200 if fmt == "png" else None))
        _write_bytes(buf.getvalue(), path)
        print(f"Plot saved: {path}")

    plt.close()
    print("DONE.")
    print(f"\nAll output written to: {OUT_DIR}")
    print(f"To copy to NFS when stable, run:")
    print(f"  cp -r {OUT_DIR}/ {NFS_OUT_DIR}/")


if __name__ == "__main__":
    main()
