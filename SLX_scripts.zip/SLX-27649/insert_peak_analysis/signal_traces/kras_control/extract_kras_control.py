#!/usr/bin/env python3
"""Extract BG4 CPM signal at the KRAS G4 peak in no-insert (empty) cell lines.

Region: chr12:25,249,602-25,252,390 (2788 bp)

Uses all BG4 bigwigs from empty cell lines (no BED region file = no inserts).
These cells have standard hg38 coordinates, so the region is extracted directly.

Generates:
  - Median signal trace plot with IQR shading
  - Raw signal matrix (TSV + NPZ)
"""

import glob
import os
import re
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
BED_DIR = os.path.join(ANALYSIS_DIR, "bed_regions")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "kras_control")

BIGWIG_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/bigwigs",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs",
}
NODUP_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/noDups",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/noDups",
}

MIN_NODUP_READS = 1_000_000

# KRAS G4 peak region
CHROM = "chr12"
START = 25249602
END = 25252390
REGION_SIZE = END - START   # 2788 bp
NUM_BINS = 500


# ── Helpers ────────────────────────────────────────────────────────────────────

def normalise_well(well):
    m = re.match(r'^(\d+[A-H])0*(\d+)$', well)
    return f"{m.group(1)}{m.group(2)}" if m else well


def parse_picard_nodup_reads(metrics_path):
    """Parse noDup read count from picard MarkDuplicates metrics."""
    if not os.path.exists(metrics_path):
        return None
    header = None
    with open(metrics_path) as f:
        for line in f:
            if line.startswith("LIBRARY"):
                header = line.strip().split("\t")
                data_line = next(f).strip().split("\t")
                break
    if header is None:
        return None
    d = dict(zip(header, data_line))
    unpaired = int(d.get("UNPAIRED_READS_EXAMINED", 0))
    unpaired_dup = int(d.get("UNPAIRED_READ_DUPLICATES", 0))
    pairs = int(d.get("READ_PAIRS_EXAMINED", 0))
    pair_dup = int(d.get("READ_PAIR_DUPLICATES", 0))
    return (unpaired - unpaired_dup) + 2 * (pairs - pair_dup)


def find_empty_bg4_bigwigs():
    """Find BG4 bigwigs for empty cell lines with >1M noDup reads."""
    bed_wells = set()
    for f in glob.glob(os.path.join(BED_DIR, "SPLINK_*.insert_regions.bed")):
        w = os.path.basename(f).replace("SPLINK_", "").replace(".insert_regions.bed", "")
        bed_wells.add(w)

    empty_bws = []
    skipped_low = 0
    for ds_name, bw_dir in BIGWIG_DIRS.items():
        nodup_dir = NODUP_DIRS.get(ds_name)
        for fname in sorted(os.listdir(bw_dir)):
            if not fname.endswith(".cpm.bw") or not fname.startswith("BG4_"):
                continue
            sample = fname.replace(".cpm.bw", "")
            m = re.match(r'^BG4_(\w+)_B\d+$', sample)
            if not m:
                continue
            well = normalise_well(m.group(1))
            if well not in bed_wells:
                # Check noDup read count
                if nodup_dir:
                    metrics = os.path.join(nodup_dir, f"{sample}.r1.hg38.rmDups.txt")
                    n = parse_picard_nodup_reads(metrics)
                    if n is not None and n < MIN_NODUP_READS:
                        skipped_low += 1
                        continue
                empty_bws.append(os.path.join(bw_dir, fname))
    print(f"  Skipped {skipped_low} empty bigwigs with <{MIN_NODUP_READS:,} noDup reads")
    return empty_bws


def extract_signal(bw_path, chrom, start, end, num_bins):
    """Extract CPM signal from bigwig, return array of length num_bins."""
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        s = max(0, start)
        e = min(end, chrom_len)
        if e <= s:
            return None
        vals = bw.stats(chrom, s, e, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    empty_bws = find_empty_bg4_bigwigs()
    print(f"Empty BG4 bigwigs: {len(empty_bws)}")

    all_signals = []
    skipped = 0

    for bw_path in empty_bws:
        sample = os.path.basename(bw_path).replace(".cpm.bw", "")
        signal = extract_signal(bw_path, CHROM, START, END, NUM_BINS)
        if signal is None:
            print(f"  SKIP {sample}: no signal")
            skipped += 1
            continue
        all_signals.append(signal)

    print(f"Extracted: {len(all_signals)}, skipped: {skipped}")

    if not all_signals:
        print("No signals extracted, exiting.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)
    q25 = np.percentile(signals, 25, axis=0)
    q75 = np.percentile(signals, 75, axis=0)
    mean_signal = np.mean(signals, axis=0)

    # Save raw data
    np.savetxt(os.path.join(OUT_DIR, "all_signals.tsv"), signals, delimiter="\t")
    np.savez_compressed(os.path.join(OUT_DIR, "kras_signals.npz"),
                        signals=signals, median=median_signal,
                        q25=q25, q75=q75, mean=mean_signal)

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(START, END, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.set_xlabel("Genomic position (chr12)")
    ax.set_ylabel("CPM")
    ax.set_title(f"BG4 signal at KRAS G4 locus – empty cell lines (n={len(all_signals)})")

    # Format x-axis with commas
    ax.get_xaxis().set_major_formatter(
        plt.FuncFormatter(lambda v, _: f"{int(v):,}"))
    plt.xticks(rotation=30, fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "kras_g4_empty_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "kras_g4_empty_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nMedian peak CPM: {median_signal.max():.4f}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
