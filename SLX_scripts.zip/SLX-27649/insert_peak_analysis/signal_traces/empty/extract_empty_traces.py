#!/usr/bin/env python3
"""Extract BG4 CPM signal at gold-standard insert positions in EMPTY cell lines.

For each gold-standard junction, uses the hg38 clip position to define a
2525bp window [clip_pos - 1000, clip_pos + 1525) in each empty cell line's
bigwig. The empty cells have no insert at these positions, so this shows the
background BG4 signal at the same genomic loci.

Reverse-oriented junctions are flipped to match the gold-standard plot.
"""

import csv
import os
import re
import glob
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
BED_DIR = os.path.join(ANALYSIS_DIR, "bed_regions")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "empty")

BIGWIG_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/bigwigs",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs",
}

REGION_SIZE = 2525  # match the gold-standard plot window
NUM_BINS = 500
FLANK = 1000
INSERT_LEN = 525


def normalise_well(well):
    m = re.match(r'^(\d+[A-H])0*(\d+)$', well)
    return f"{m.group(1)}{m.group(2)}" if m else well


def find_empty_bg4_bigwigs():
    """Find BG4 bigwigs for empty cell lines (no BED region file)."""
    bed_wells = set()
    for f in glob.glob(os.path.join(BED_DIR, "SPLINK_*.insert_regions.bed")):
        w = os.path.basename(f).replace("SPLINK_", "").replace(".insert_regions.bed", "")
        bed_wells.add(w)

    empty_bws = []
    for ds_name, bw_dir in BIGWIG_DIRS.items():
        for fname in sorted(os.listdir(bw_dir)):
            if not fname.endswith(".cpm.bw") or not fname.startswith("BG4_"):
                continue
            sample = fname.replace(".cpm.bw", "")
            m = re.match(r'^BG4_(\w+)_B\d+$', sample)
            if not m:
                continue
            well = normalise_well(m.group(1))
            if well not in bed_wells:
                empty_bws.append(os.path.join(bw_dir, fname))
    return empty_bws


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Read gold standard junctions
    with open(GOLD_TSV) as f:
        gold_rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Gold standard junctions: {len(gold_rows)}")

    # Parse hg38 clip positions and orientations
    junctions = []
    for r in gold_rows:
        loc = r["junction_location"]  # e.g. "chr7:143306073"
        chrom, pos_str = loc.split(":")
        clip_pos = int(pos_str)
        # In hg38 (no insert): window is [clip_pos - FLANK, clip_pos + INSERT_LEN + FLANK)
        # This spans the same 2525bp width for visual comparison
        start = clip_pos - FLANK
        end = clip_pos + INSERT_LEN + FLANK
        junctions.append({
            "chrom": chrom,
            "start": start,
            "end": end,
            "orientation": r["orientation"],
        })

    # Find empty cell line bigwigs
    empty_bws = find_empty_bg4_bigwigs()
    print(f"Empty BG4 bigwigs: {len(empty_bws)}")

    # For each junction × each empty cell, extract signal
    all_signals = []
    skipped = 0
    total = 0

    for bw_path in empty_bws:
        bw_name = os.path.basename(bw_path)
        n_ok = 0
        for junc in junctions:
            total += 1
            signal = extract_signal(
                bw_path, junc["chrom"], junc["start"], junc["end"], NUM_BINS
            )
            if signal is None:
                skipped += 1
                continue

            if junc["orientation"] == "reverse":
                signal = signal[::-1]

            all_signals.append(signal)
            n_ok += 1

        print(f"  {bw_name}: {n_ok}/{len(junctions)} extracted")

    print(f"\nTotal extracted: {len(all_signals)}, skipped: {skipped}")

    if not all_signals:
        print("No signals extracted, exiting.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)

    # Save raw data
    np.savetxt(os.path.join(OUT_DIR, "median_signal.tsv"), median_signal, delimiter="\t")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.axvline(1000, color="red", linestyle="--", linewidth=0.8, label="Insert boundary")
    ax.axvline(1000 + 525, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(1000, 1000 + 525, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(
        f"BG4 signal at gold-standard positions in EMPTY cell lines "
        f"(n={len(all_signals)}: {len(junctions)} junctions × {len(empty_bws)} cells)"
    )

    ticks = [0, 500, 1000, 1262, 1525, 2025, 2525]
    labels = ["-1000", "-500", "Insert\nstart", "Insert\nmid", "Insert\nend", "+500", "+1000"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "empty_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "empty_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nPlot saved: {out_pdf}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
