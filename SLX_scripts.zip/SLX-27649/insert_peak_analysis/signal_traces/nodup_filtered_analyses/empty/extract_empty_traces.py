#!/usr/bin/env python3
"""Extract BG4 CPM signal at gold-standard insert positions in EMPTY cell lines.

Only includes empty cell lines with >1M noDup aligned reads (from picard metrics).
For each gold-standard junction, uses the hg38 clip position to define a
2525bp window in each empty cell line's bigwig.
"""

import csv
import os
import re
import glob
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
BED_DIR = os.path.join(ANALYSIS_DIR, "bed_regions")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "nodup_filtered_analyses", "empty")

BIGWIG_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/bigwigs",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs",
}
NODUP_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/noDups",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/noDups",
}

MIN_NODUP_READS = 1_000_000
REGION_SIZE = 2525
NUM_BINS = 500
FLANK = 1000
INSERT_LEN = 525


def parse_picard_nodup_reads(metrics_path):
    """Return noDup read count from picard MarkDuplicates metrics."""
    with open(metrics_path) as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith("LIBRARY"):
            header_idx = i
            break
    if header_idx is None:
        return None
    headers = lines[header_idx].strip().split("\t")
    values = lines[header_idx + 1].strip().split("\t")
    d = dict(zip(headers, values))
    unpaired = int(d.get("UNPAIRED_READS_EXAMINED", 0)) - int(
        d.get("UNPAIRED_READ_DUPLICATES", 0)
    )
    pairs = int(d.get("READ_PAIRS_EXAMINED", 0)) - int(
        d.get("READ_PAIR_DUPLICATES", 0)
    )
    return unpaired + pairs * 2


def normalise_well(well):
    m = re.match(r'^(\d+[A-H])0*(\d+)$', well)
    return f"{m.group(1)}{m.group(2)}" if m else well


def find_empty_bg4_bigwigs():
    """Find BG4 bigwigs for empty cell lines (no BED region file) with >1M noDup reads."""
    bed_wells = set()
    for f in glob.glob(os.path.join(BED_DIR, "SPLINK_*.insert_regions.bed")):
        w = os.path.basename(f).replace("SPLINK_", "").replace(".insert_regions.bed", "")
        bed_wells.add(w)

    empty_bws = []
    skipped_nodup = 0
    for ds_name, bw_dir in BIGWIG_DIRS.items():
        nodup_dir = NODUP_DIRS[ds_name]
        for fname in sorted(os.listdir(bw_dir)):
            if not fname.endswith(".cpm.bw") or not fname.startswith("BG4_"):
                continue
            sample = fname.replace(".cpm.bw", "")
            m = re.match(r'^BG4_(\w+)_B\d+$', sample)
            if not m:
                continue
            well = normalise_well(m.group(1))
            if well not in bed_wells:
                # Check noDup reads
                metrics_path = os.path.join(nodup_dir, f"{sample}.r1.hg38.rmDups.txt")
                if not os.path.exists(metrics_path):
                    print(f"  SKIP {sample}: no picard metrics")
                    skipped_nodup += 1
                    continue
                nodup = parse_picard_nodup_reads(metrics_path)
                if nodup is None or nodup < MIN_NODUP_READS:
                    print(f"  SKIP {sample}: {nodup:,} noDup reads < {MIN_NODUP_READS:,}")
                    skipped_nodup += 1
                    continue
                empty_bws.append(os.path.join(bw_dir, fname))
    print(f"Empty BG4 bigwigs skipped (noDup filter): {skipped_nodup}")
    return empty_bws


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    with open(GOLD_TSV) as f:
        gold_rows = list(csv.DictReader(f, delimiter="\t"))
    print(f"Gold standard junctions: {len(gold_rows)}")

    junctions = []
    for r in gold_rows:
        loc = r["junction_location"]
        chrom, pos_str = loc.split(":")
        clip_pos = int(pos_str)
        start = clip_pos - FLANK
        end = clip_pos + INSERT_LEN + FLANK
        junctions.append({
            "chrom": chrom,
            "start": start,
            "end": end,
            "orientation": r["orientation"],
        })

    empty_bws = find_empty_bg4_bigwigs()
    print(f"Empty BG4 bigwigs passing filter: {len(empty_bws)}")

    all_signals = []
    skipped = 0

    for bw_path in empty_bws:
        bw_name = os.path.basename(bw_path)
        n_ok = 0
        for junc in junctions:
            signal = extract_signal(
                bw_path, junc["chrom"], junc["start"], junc["end"], NUM_BINS
            )
            if signal is None:
                skipped += 1
                continue

            if junc["orientation"] == "reverse":
                signal = signal[::-1]

            all_signals.append(signal)
            n_ok += 1

        print(f"  {bw_name}: {n_ok}/{len(junctions)} extracted")

    print(f"\nTotal extracted: {len(all_signals)}, skipped: {skipped}")

    if not all_signals:
        print("No signals extracted, exiting.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)

    np.savetxt(os.path.join(OUT_DIR, "median_signal.tsv"), median_signal, delimiter="\t")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.axvline(1000, color="red", linestyle="--", linewidth=0.8, label="Insert boundary")
    ax.axvline(1000 + 525, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(1000, 1000 + 525, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(
        f"BG4 signal at gold-standard positions in EMPTY cell lines "
        f"(n={len(all_signals)}: {len(junctions)} junctions x {len(empty_bws)} cells, "
        f">{MIN_NODUP_READS // 1_000_000}M noDup reads)"
    )

    ticks = [0, 500, 1000, 1262, 1525, 2025, 2525]
    labels = ["-1000", "-500", "Insert\nstart", "Insert\nmid", "Insert\nend", "+500", "+1000"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "empty_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "empty_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nPlot saved: {out_pdf}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
