#!/usr/bin/env python3
"""Extract CPM signal for non-gold-standard insert junctions (BG4 only).

Only includes samples with >1M noDup aligned reads (from picard metrics).
Takes all junctions from insert_peak_summary_bg4.tsv and excludes those
in gold_standard_junctions_bg4.tsv.
"""

import csv
import os
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
SUMMARY_TSV = os.path.join(ANALYSIS_DIR, "insert_peak_summary_bg4.tsv")
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "nodup_filtered_analyses", "non_gold")

BIGWIG_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/bigwigs",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs",
}
NODUP_DIRS = {
    "SLX-26997": "/mnt/scratchc/sblab/herka01/SLX-26997/noDups",
    "SLX-27843": "/mnt/scratchc/sblab/herka01/SLX-27843/noDups",
}

MIN_NODUP_READS = 1_000_000
REGION_SIZE = 2525
NUM_BINS = 500


def parse_picard_nodup_reads(metrics_path):
    """Return noDup read count from picard MarkDuplicates metrics."""
    with open(metrics_path) as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith("LIBRARY"):
            header_idx = i
            break
    if header_idx is None:
        return None
    headers = lines[header_idx].strip().split("\t")
    values = lines[header_idx + 1].strip().split("\t")
    d = dict(zip(headers, values))
    unpaired = int(d.get("UNPAIRED_READS_EXAMINED", 0)) - int(
        d.get("UNPAIRED_READ_DUPLICATES", 0)
    )
    pairs = int(d.get("READ_PAIRS_EXAMINED", 0)) - int(
        d.get("READ_PAIR_DUPLICATES", 0)
    )
    return unpaired + pairs * 2


def get_nodup_reads(dataset, sample):
    nodup_dir = NODUP_DIRS.get(dataset)
    if not nodup_dir:
        return None
    metrics_path = os.path.join(nodup_dir, f"{sample}.r1.hg38.rmDups.txt")
    if not os.path.exists(metrics_path):
        return None
    return parse_picard_nodup_reads(metrics_path)


def get_bigwig_path(dataset, sample):
    bw_dir = BIGWIG_DIRS.get(dataset)
    if not bw_dir:
        return None
    path = os.path.join(bw_dir, f"{sample}.cpm.bw")
    return path if os.path.exists(path) else None


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    with open(GOLD_TSV) as f:
        gold_rows = list(csv.DictReader(f, delimiter="\t"))
    gold_keys = set()
    for r in gold_rows:
        gold_keys.add((r["sample"], r["chrom"], r["region_start"], r["region_end"]))
    print(f"Gold standard junctions to exclude: {len(gold_keys)}")

    with open(SUMMARY_TSV) as f:
        all_rows = list(csv.DictReader(f, delimiter="\t"))

    non_gold = [r for r in all_rows
                if (r["sample"], r["chrom"], r["region_start"], r["region_end"])
                not in gold_keys]
    print(f"Total BG4 junctions: {len(all_rows)}")
    print(f"Non-gold-standard junctions: {len(non_gold)}")

    all_signals = []
    skipped = 0
    skipped_nodup = 0

    for row in non_gold:
        dataset = row["dataset"]
        sample = row["sample"]
        chrom = row["chrom"]
        start = int(row["region_start"])
        end = int(row["region_end"])
        orientation = row["orientation"]

        # noDup filter
        nodup = get_nodup_reads(dataset, sample)
        if nodup is None or nodup < MIN_NODUP_READS:
            skipped_nodup += 1
            continue

        bw_path = get_bigwig_path(dataset, sample)
        if bw_path is None:
            skipped += 1
            continue

        signal = extract_signal(bw_path, chrom, start, end, NUM_BINS)
        if signal is None:
            skipped += 1
            continue

        if orientation == "reverse":
            signal = signal[::-1]

        all_signals.append(signal)

    print(f"Extracted: {len(all_signals)}, skipped (noDup): {skipped_nodup}, skipped (other): {skipped}")

    if not all_signals:
        print("No signals extracted, exiting.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)

    np.savetxt(os.path.join(OUT_DIR, "median_signal.tsv"), median_signal, delimiter="\t")
    np.savetxt(os.path.join(OUT_DIR, "all_signals.tsv"), signals, delimiter="\t")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.axvline(1000, color="red", linestyle="--", linewidth=0.8, label="Insert boundary")
    ax.axvline(1000 + 525, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(1000, 1000 + 525, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(
        f"BG4 signal at non-gold-standard insert sites (n={len(all_signals)}, "
        f">{MIN_NODUP_READS // 1_000_000}M noDup reads)"
    )

    ticks = [0, 500, 1000, 1262, 1525, 2025, 2525]
    labels = ["-1000", "-500", "Insert\nstart", "Insert\nmid", "Insert\nend", "+500", "+1000"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "non_gold_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "non_gold_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nPlot saved: {out_pdf}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
