#!/usr/bin/env python3
"""Extract CUTAC CPM signal at BG4 gold-standard sites FROM THE SAME WELL.

Restricted to the 22 gold-standard junctions in SLX-27843 (wells 1A1–1B12),
where each well has a matching CUTAC bigwig with the insert at the same
integrated-genome coordinates. Only CUTAC bigwigs with >1M noDup reads used.
"""

import csv
import os
import sys

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "cutac_gold_matched")

BIGWIG_DIR = "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs"
NODUP_DIR = "/mnt/scratchc/sblab/herka01/SLX-27843/noDups"

MIN_NODUP_READS = 1_000_000
REGION_SIZE = 2525
NUM_BINS = 500
FLANK = 1000
INSERT_LEN = 525


def parse_picard_metrics(metrics_path):
    """Return noDup read count from picard MarkDuplicates metrics."""
    with open(metrics_path) as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith("LIBRARY"):
            header_idx = i
            break
    if header_idx is None:
        return None
    headers = lines[header_idx].strip().split("\t")
    values = lines[header_idx + 1].strip().split("\t")
    d = dict(zip(headers, values))
    unpaired = int(d.get("UNPAIRED_READS_EXAMINED", 0)) - int(
        d.get("UNPAIRED_READ_DUPLICATES", 0)
    )
    pairs = int(d.get("READ_PAIRS_EXAMINED", 0)) - int(
        d.get("READ_PAIR_DUPLICATES", 0)
    )
    return unpaired + pairs * 2


def get_nodup_reads(well):
    """Get noDup reads for CUTAC_{well}_B1."""
    sample = f"CUTAC_{well}_B1"
    metrics_path = os.path.join(NODUP_DIR, f"{sample}.r1.hg38.rmDups.txt")
    if not os.path.exists(metrics_path):
        return None
    return parse_picard_metrics(metrics_path)


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Gold-standard junctions from SLX-27843 only
    with open(GOLD_TSV) as f:
        all_rows = list(csv.DictReader(f, delimiter="\t"))
    gold_27843 = [r for r in all_rows if r["dataset"] == "SLX-27843"]
    print(f"Gold-standard junctions from SLX-27843: {len(gold_27843)}")

    all_signals = []
    skipped = 0
    wells_used = set()

    for r in gold_27843:
        well = r["cell_line"]
        chrom = r["chrom"]
        start = int(r["region_start"])
        end = int(r["region_end"])
        orientation = r["orientation"]

        # CUTAC bigwig for the same well
        cutac_sample = f"CUTAC_{well}_B1"
        bw_path = os.path.join(BIGWIG_DIR, f"{cutac_sample}.cpm.bw")
        if not os.path.exists(bw_path):
            print(f"  SKIP {well}: no CUTAC bigwig")
            skipped += 1
            continue

        # Check noDup reads
        nodup = get_nodup_reads(well)
        if nodup is None or nodup < MIN_NODUP_READS:
            print(f"  SKIP {well} ({cutac_sample}): {nodup:,} noDup < {MIN_NODUP_READS:,}")
            skipped += 1
            continue

        # Same well → same integrated genome → use BED region coords directly
        signal = extract_signal(bw_path, chrom, start, end, NUM_BINS)
        if signal is None:
            print(f"  SKIP {well} {chrom}:{start}-{end}: no signal")
            skipped += 1
            continue

        if orientation == "reverse":
            signal = signal[::-1]

        all_signals.append(signal)
        wells_used.add(well)
        print(
            f"  OK {cutac_sample} {chrom}:{start}-{end} "
            f"({nodup:,} noDup, {orientation})"
        )

    print(f"\nExtracted: {len(all_signals)}, skipped: {skipped}")
    print(f"Wells represented: {sorted(wells_used)}")

    if not all_signals:
        print("No signals extracted.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)

    np.savetxt(os.path.join(OUT_DIR, "median_signal.tsv"), median_signal, delimiter="\t")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.axvline(1000, color="red", linestyle="--", linewidth=0.8, label="Insert boundary")
    ax.axvline(1000 + 525, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(1000, 1000 + 525, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(
        f"CUTAC signal at matched BG4 gold-standard sites "
        f"(n={len(all_signals)} junctions, {len(wells_used)} wells)"
    )

    ticks = [0, 500, 1000, 1262, 1525, 2025, 2525]
    labels = ["-1000", "-500", "Insert\nstart", "Insert\nmid", "Insert\nend", "+500", "+1000"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "cutac_gold_matched_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "cutac_gold_matched_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nPlot saved: {out_pdf}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
