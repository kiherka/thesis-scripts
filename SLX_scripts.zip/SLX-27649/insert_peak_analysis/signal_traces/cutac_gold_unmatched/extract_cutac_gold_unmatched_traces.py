#!/usr/bin/env python3
"""Extract CUTAC CPM signal at BG4 gold-standard sites in NON-MATCHING wells.

For the 21 SLX-27843 gold-standard junctions (same as cutac_gold_matched),
extracts CUTAC signal from all OTHER SLX-27843 wells (where the insert does
NOT exist). Maps hg38 positions to each well's integrated genome coords.
Only CUTAC bigwigs with >1M noDup reads used.
"""

import csv
import os
import re
import sys
from collections import defaultdict

import numpy as np
import pyBigWig

# ── Paths ──────────────────────────────────────────────────────────────────────
ANALYSIS_DIR = "/mnt/scratchc/sblab/herka01/SLX-27649/insert_peak_analysis"
GOLD_TSV = os.path.join(ANALYSIS_DIR, "gold_standard_junctions_bg4.tsv")
OUT_DIR = os.path.join(ANALYSIS_DIR, "signal_traces", "cutac_gold_unmatched")

BIGWIG_DIR = "/mnt/scratchc/sblab/herka01/SLX-27843/bigwigs"
NODUP_DIR = "/mnt/scratchc/sblab/herka01/SLX-27843/noDups"
CONSENSUS_DIR = (
    "/mnt/scratchc/sblab/herka01/SLX-27649/"
    "260216_VH01410_433_AAHHHJ2M5/consensus_combined"
)

MIN_NODUP_READS = 1_000_000
REGION_SIZE = 2525
NUM_BINS = 500
FLANK = 1000
INSERT_LEN = 525


def parse_picard_metrics(metrics_path):
    with open(metrics_path) as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith("LIBRARY"):
            header_idx = i
            break
    if header_idx is None:
        return None
    headers = lines[header_idx].strip().split("\t")
    values = lines[header_idx + 1].strip().split("\t")
    d = dict(zip(headers, values))
    unpaired = int(d.get("UNPAIRED_READS_EXAMINED", 0)) - int(
        d.get("UNPAIRED_READ_DUPLICATES", 0)
    )
    pairs = int(d.get("READ_PAIRS_EXAMINED", 0)) - int(
        d.get("READ_PAIR_DUPLICATES", 0)
    )
    return unpaired + pairs * 2


def get_cutac_bigwigs():
    bws = []
    for fname in sorted(os.listdir(BIGWIG_DIR)):
        if not fname.startswith("CUTAC_") or not fname.endswith(".cpm.bw"):
            continue
        sample = fname.replace(".cpm.bw", "")
        metrics_path = os.path.join(NODUP_DIR, f"{sample}.r1.hg38.rmDups.txt")
        if not os.path.exists(metrics_path):
            continue
        nodup = parse_picard_metrics(metrics_path)
        if nodup is None or nodup < MIN_NODUP_READS:
            continue
        m = re.match(r"^CUTAC_(\w+)_B\d+$", sample)
        well = m.group(1) if m else sample
        bws.append({
            "sample": sample,
            "well": well,
            "path": os.path.join(BIGWIG_DIR, fname),
            "nodup_reads": nodup,
        })
    return bws


def load_well_inserts(well):
    junctions_file = os.path.join(CONSENSUS_DIR, f"SPLINK_{well}.junctions.bed")
    by_chrom = defaultdict(list)
    if not os.path.exists(junctions_file):
        return by_chrom
    with open(junctions_file) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split("\t")
            chrom = parts[0]
            clip_pos = int(parts[8]) if len(parts) > 8 else int(parts[1])
            by_chrom[chrom].append(clip_pos)
    for chrom in by_chrom:
        by_chrom[chrom].sort()
    return by_chrom


def hg38_to_integrated(hg38_pos, chrom, well_inserts):
    if chrom not in well_inserts:
        return hg38_pos
    n_before = sum(1 for p in well_inserts[chrom] if p < hg38_pos)
    return hg38_pos + n_before * INSERT_LEN


def extract_signal(bw_path, chrom, start, end, num_bins):
    bw = pyBigWig.open(bw_path)
    try:
        chroms = bw.chroms()
        if chrom not in chroms:
            return None
        chrom_len = chroms[chrom]
        start = max(0, start)
        end = min(end, chrom_len)
        if end <= start:
            return None
        vals = bw.stats(chrom, start, end, nBins=num_bins, type="mean")
        return np.array([v if v is not None else 0.0 for v in vals])
    finally:
        bw.close()


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Gold-standard junctions from SLX-27843
    with open(GOLD_TSV) as f:
        all_rows = list(csv.DictReader(f, delimiter="\t"))
    gold_27843 = [r for r in all_rows if r["dataset"] == "SLX-27843"]
    print(f"Gold-standard junctions from SLX-27843: {len(gold_27843)}")

    # Parse hg38 positions and the wells they belong to
    junctions = []
    gold_wells = set()
    for r in gold_27843:
        chrom, pos_str = r["junction_location"].split(":")
        junctions.append({
            "chrom": chrom,
            "hg38_clip_pos": int(pos_str),
            "orientation": r["orientation"],
            "well": r["cell_line"],
        })
        gold_wells.add(r["cell_line"])

    # Also filter out 1A7 which was skipped due to low reads
    print(f"Gold-standard wells: {sorted(gold_wells)}")

    # Get all CUTAC bigwigs passing filter, EXCLUDING gold-standard wells
    all_cutac = get_cutac_bigwigs()
    unmatched_cutac = [bw for bw in all_cutac if bw["well"] not in gold_wells]
    print(f"All CUTAC bigwigs (>1M noDup): {len(all_cutac)}")
    print(f"Non-gold CUTAC bigwigs: {len(unmatched_cutac)}")
    for bw in unmatched_cutac:
        print(f"    {bw['sample']}: {bw['nodup_reads']:,} noDup reads")

    # Pre-load insert data per well
    well_insert_cache = {}
    for bw_info in unmatched_cutac:
        well = bw_info["well"]
        if well not in well_insert_cache:
            well_insert_cache[well] = load_well_inserts(well)
            n_ins = sum(len(v) for v in well_insert_cache[well].values())
            print(f"    {well}: {n_ins} inserts loaded")

    total = len(junctions) * len(unmatched_cutac)
    print(f"Total extractions: {len(junctions)} x {len(unmatched_cutac)} = {total}")

    all_signals = []
    skipped = 0

    for idx, bw_info in enumerate(unmatched_cutac):
        well = bw_info["well"]
        well_inserts = well_insert_cache[well]
        n_ok = 0

        for junc in junctions:
            integrated_pos = hg38_to_integrated(
                junc["hg38_clip_pos"], junc["chrom"], well_inserts
            )
            start = integrated_pos - FLANK
            end = integrated_pos + INSERT_LEN + FLANK

            signal = extract_signal(bw_info["path"], junc["chrom"], start, end, NUM_BINS)
            if signal is None:
                skipped += 1
                continue
            if junc["orientation"] == "reverse":
                signal = signal[::-1]
            all_signals.append(signal)
            n_ok += 1

        print(f"  [{idx+1}/{len(unmatched_cutac)}] {bw_info['sample']}: {n_ok}/{len(junctions)}")

    print(f"\nTotal extracted: {len(all_signals)}, skipped: {skipped}")

    if not all_signals:
        print("No signals extracted.")
        sys.exit(1)

    signals = np.vstack(all_signals)
    median_signal = np.median(signals, axis=0)

    np.savetxt(os.path.join(OUT_DIR, "median_signal.tsv"), median_signal, delimiter="\t")

    # ── Plot ───────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = np.linspace(0, REGION_SIZE, NUM_BINS)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, median_signal, color="#2166ac", linewidth=1.2)

    ax.axvline(1000, color="red", linestyle="--", linewidth=0.8, label="Insert boundary")
    ax.axvline(1000 + 525, color="red", linestyle="--", linewidth=0.8)
    ax.axvspan(1000, 1000 + 525, color="red", alpha=0.05)

    ax.set_xlabel("Position relative to insert region (bp)")
    ax.set_ylabel("Median CPM")
    ax.set_title(
        f"CUTAC signal at gold-standard sites in NON-MATCHING wells "
        f"({len(junctions)} junctions x {len(unmatched_cutac)} wells)"
    )

    ticks = [0, 500, 1000, 1262, 1525, 2025, 2525]
    labels = ["-1000", "-500", "Insert\nstart", "Insert\nmid", "Insert\nend", "+500", "+1000"]
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, fontsize=8)

    ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()

    out_pdf = os.path.join(OUT_DIR, "cutac_gold_unmatched_signal_trace.pdf")
    out_png = os.path.join(OUT_DIR, "cutac_gold_unmatched_signal_trace.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close()

    print(f"\nPlot saved: {out_pdf}")
    print(f"Plot saved: {out_png}")
    print("DONE.")


if __name__ == "__main__":
    main()
