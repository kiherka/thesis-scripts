#!/bin/bash
# Launch the Snakemake pipeline inside a screen session so it
# survives terminal disconnection. Re-attach with:
#   screen -r snakemake_pipeline
cd /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5
eval "$(conda shell.bash hook)"
conda activate snakemake
snakemake --profile profile/ 2>&1 | tee logs/snakemake_master.log
