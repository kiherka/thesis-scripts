#!/usr/bin/env python3
"""
Analyse CPM bigwig files for ATRX CUT&Tag, local reproduction of
analyse_bg4_smoothened_cpm.py adapted for the ATRX antibody samples in this
folder's bigwigs/ directory.

Scope of this script (differs from analyse_bg4_smoothened_cpm.py):
  - Only ATRX samples are analysed (SPLINK/BG4 tracks in this folder are
    ignored).
  - Sample names follow the local ATRX naming scheme:
        ATRX_<CATEGORY>-<CLONE>_<BIOREP>.cpm.bw
    e.g. ATRX_G3T1-1_B1.cpm.bw -> category=G3T1, clone=1, biorep=B1
    Edit categories: WT, G3T1, G3T1F, G3T4.
    "-1"/"-2"/... identify the clonal cell line within a category.
    B1/B2 = biological replicates.
  - There are no technical replicates for these ATRX bigwigs (single CPM
    bigwig per biological replicate, generated with bamCoverage
    --normalizeUsing CPM --binSize 3, no fragment-size separation or extra
    smoothing), so the technical-replicate averaging step used in the BG4
    script is not needed here - each bigwig is already a biological
    replicate.
  - Cell lines G3T1-3 and G3T1F-3 are excluded wholesale (per user
    instruction) and recorded in excluded_cell_lines.tsv.
  - Statistics (Mann-Whitney U, BH-FDR corrected across the 3 comparisons)
    are still computed for each edit category (G3T1, G3T1F, G3T4) vs WT and
    saved to statistics_*_vs_WT.tsv, but the plots show all edit categories
    together on the same axes (bar + jittered replicate dots) rather than
    per-category-vs-WT comparison panels with significance brackets.
  - Additional reference (normalisation) regions ported from analyse_cpm.py:
    NPRL3 (chr16), STAT3 (chr17) and MYC (chr8), alongside the original
    chr12 reference locus. Target CPM is normalised against each of the
    four reference regions independently, each producing its own
    per-edit-category plot and vs-WT statistics file.

Insert/test site: chrX:71,530,537-71,530,555 (G4 promoter insertion site).
The test-locus CPM window is a region flanking the insert site sized to
exactly match the reference locus size (1,000 bp), so that target and
reference CPM values are computed over equally sized windows.

Both the normalised CPM (target/reference) and the raw CPM (target alone,
reference alone) are plotted at the cell-line level and at the edit-category
level (all categories together), for each of the four reference regions.
"""

import re
import glob
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pyBigWig
from scipy import stats
from statsmodels.stats.multitest import multipletests

# ── Regions ───────────────────────────────────────────────────────────────────
TARGET_CHR = "chrX"
PEAK_START = 71_530_537
PEAK_END   = 71_530_555

# Reference (normalisation) locus - unchanged from analyse_bg4_smoothened_cpm.py
REF_CHR   = "chr12"
REF_START = 25_250_600
REF_END   = 25_251_600
REF_SIZE  = REF_END - REF_START

# Additional reference (normalisation) regions, ported from analyse_cpm.py
NPRL_CHR,  NPRL_START,  NPRL_END  = "chr16", 138_029,     139_191
STAT3_CHR, STAT3_START, STAT3_END = "chr17", 42_388_142,  42_389_213
MYC_CHR,   MYC_START,   MYC_END   = "chr8",  127_734_866, 127_736_733

# key -> (chrom, start, end, display label). "ref" is the original chr12
# locus and keeps the plain ref_cpm/norm_cpm column names for backward
# compatibility; the others get ref_cpm_<key>/norm_cpm_<key> columns.
REFERENCES = [
    ("ref",   REF_CHR,   REF_START,   REF_END,   f"chr12 ({REF_CHR}:{REF_START:,}-{REF_END:,})"),
    ("nprl",  NPRL_CHR,  NPRL_START,  NPRL_END,  f"NPRL3 ({NPRL_CHR}:{NPRL_START:,}-{NPRL_END:,})"),
    ("stat3", STAT3_CHR, STAT3_START, STAT3_END, f"STAT3 ({STAT3_CHR}:{STAT3_START:,}-{STAT3_END:,})"),
    ("myc",   MYC_CHR,   MYC_START,   MYC_END,   f"MYC ({MYC_CHR}:{MYC_START:,}-{MYC_END:,})"),
]

# Test-locus window: flank the insert site so the resulting window is
# exactly REF_SIZE bp wide (same size as the reference locus), instead of a
# fixed ±500 bp flank, so target and reference CPM are directly comparable.
PEAK_LEN     = PEAK_END - PEAK_START
FLANK        = (REF_SIZE - PEAK_LEN) // 2
TARGET_START = PEAK_START - FLANK
TARGET_END   = TARGET_START + REF_SIZE

WINDOWS = {
    "target_matched": (TARGET_START, TARGET_END),
    "10kb":           (PEAK_START - 10000, PEAK_END + 10000),
}

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BIGWIG_DIR = os.path.join(SCRIPT_DIR, "bigwigs")
OUT_DIR    = SCRIPT_DIR
BIN_SIZE   = 25

os.makedirs(OUT_DIR, exist_ok=True)

WT_LABEL = "WT"
EDIT_CATEGORIES_VS_WT = ["G3T1", "G3T1F", "G3T4"]

# ── Cell lines excluded wholesale (per user instruction) ──────────────────────
EXCLUDED_CELL_LINES = {"G3T1-3", "G3T1F-3"}

# ── Sample parsing ─────────────────────────────────────────────────────────────
SAMPLE_RE = re.compile(r'^(ATRX)_([A-Za-z0-9]+-\d+)_(B\d+)\.cpm\.bw$')

def parse_sample(filename):
    m = SAMPLE_RE.match(filename)
    if not m:
        return None
    assay, clone, biorep = m.groups()
    edit_category = re.sub(r'-\d+$', '', clone)
    return dict(assay=assay, clone=clone, edit_category=edit_category, biorep=biorep)

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "ATRX_*.cpm.bw")))
records = []
for path in bw_files:
    fname = os.path.basename(path)
    info = parse_sample(fname)
    if info:
        info["path"] = path
        info["file_stem"] = fname
        records.append(info)

meta = pd.DataFrame(records)
print(f"Found {len(meta)} ATRX cpm.bw files")

# ── Apply cell-line exclusions ────────────────────────────────────────────────
excl_mask = meta["clone"].isin(EXCLUDED_CELL_LINES)
excl_df = meta[excl_mask].copy()
excl_df.to_csv(os.path.join(OUT_DIR, "excluded_cell_lines.tsv"), sep="\t", index=False)

meta = meta[~excl_mask].copy()
print(f"Excluded {len(excl_df)} files belonging to cell line(s): {sorted(EXCLUDED_CELL_LINES)}")
print(f"{len(meta)} files retained for analysis")
print(meta.groupby("edit_category").size().to_string())

meta["cell_line"] = "ATRX_" + meta["clone"]
meta["stem"] = meta["assay"] + "_" + meta["clone"] + "_" + meta["biorep"]

# ── Helper ─────────────────────────────────────────────────────────────────────
def fetch_mean(bw, chrom, start, end):
    try:
        val = bw.stats(chrom, start, end, type="mean", exact=True)[0]
        return float(val) if val is not None else 0.0
    except RuntimeError:
        return 0.0

# ── Extract CPM per file (each file already = one biological replicate) ──────
print("\nExtracting CPM values …")
track_bins = {win: np.arange(s, e, BIN_SIZE) for win, (s, e) in WINDOWS.items()}

target_cpms = []
ref_key_cpms = {key: [] for key, *_ in REFERENCES}
track_data = {win: {} for win in WINDOWS}

for _, row in meta.iterrows():
    bw = pyBigWig.open(row["path"])
    for win, bins in track_bins.items():
        sig = [fetch_mean(bw, TARGET_CHR, int(b), int(b + BIN_SIZE)) for b in bins]
        track_data[win][row["stem"]] = np.array(sig)
    target_cpms.append(fetch_mean(bw, TARGET_CHR, TARGET_START, TARGET_END))
    for key, chrom, start, end, _label in REFERENCES:
        ref_key_cpms[key].append(fetch_mean(bw, chrom, start, end))
    bw.close()

meta["target_cpm"] = target_cpms
for key, *_ in REFERENCES:
    col = "ref_cpm" if key == "ref" else f"ref_cpm_{key}"
    norm_col = "norm_cpm" if key == "ref" else f"norm_cpm_{key}"
    meta[col] = ref_key_cpms[key]
    meta[norm_col] = meta.apply(
        lambda r, c=col: r["target_cpm"] / r[c] if r[c] > 0 else np.nan, axis=1
    )
meta.to_csv(os.path.join(OUT_DIR, "per_sample_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm.tsv (biological-replicate level)")

# ── Colour palette ─────────────────────────────────────────────────────────────
def make_palette(keys):
    n = len(keys)
    colors = sns.color_palette("tab20", n) if n <= 20 else sns.color_palette("husl", n)
    return dict(zip(sorted(keys), colors))

edit_cats = sorted(meta["edit_category"].unique())
cat_palette = make_palette(edit_cats)

# ── 1a. Track plots - all samples overview ────────────────────────────────────
print("\nPlotting CPM tracks (all samples) …")

def plot_tracks(sub_meta, win_label, win_start, win_end, out_path, title_extra=""):
    bins = track_bins[win_label]
    x = bins - win_start
    peak_rel_s = PEAK_START - win_start
    peak_rel_e = PEAK_END   - win_start
    n_samples = len(sub_meta)

    all_vals = np.concatenate([track_data[win_label][r["stem"]]
                               for _, r in sub_meta.iterrows()])
    ymax = np.nanpercentile(all_vals, 99) * 1.15
    ymax = max(ymax, 0.01)

    fig, axes = plt.subplots(
        n_samples, 1,
        figsize=(14, max(4, 0.38 * n_samples + 1.5)),
        sharex=True, sharey=False,
        gridspec_kw={"hspace": 0.05}
    )
    if n_samples == 1:
        axes = [axes]

    for ax, (_, row) in zip(axes, sub_meta.iterrows()):
        sig = track_data[win_label][row["stem"]]
        color = cat_palette[row["edit_category"]]
        ax.fill_between(x, sig, alpha=0.85, color=color, linewidth=0)
        ax.axvspan(peak_rel_s, peak_rel_e, color="red", alpha=0.15, linewidth=0)
        ax.set_ylim(0, ymax)
        ax.set_ylabel(f"{row['cell_line']}_{row['biorep']}", fontsize=4.5,
                      rotation=0, ha="right", va="center", labelpad=2)
        ax.set_yticks([round(ymax, 2)])
        ax.set_yticklabels([f"{ymax:.2f}"], fontsize=3.5)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(left=False)

    axes[-1].set_xlabel(f"{TARGET_CHR} offset from window start (bp)")
    wlen = win_end - win_start
    fig.suptitle(
        f"ATRX: CPM signal – {win_label} window  "
        f"({TARGET_CHR}:{win_start:,}–{win_end:,}, {wlen:,} bp)\n"
        f"Red band = insert/test site ({TARGET_CHR}:{PEAK_START:,}–{PEAK_END:,})  |  "
        f"All tracks: same Y scale (max = {ymax:.2f} CPM){title_extra}",
        fontsize=8
    )
    cats_here = sorted(sub_meta["edit_category"].unique())
    handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
    axes[0].legend(handles, cats_here, loc="upper right", fontsize=5,
                   ncol=max(1, len(cats_here) // 4), framealpha=0.7)

    fig.savefig(out_path, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"  Saved {out_path}")

sub_all = meta.sort_values("cell_line")
for win_label, (win_start, win_end) in WINDOWS.items():
    out = os.path.join(OUT_DIR, f"01_tracks_ATRX_all_{win_label}.pdf")
    plot_tracks(sub_all, win_label, win_start, win_end, out)

# ── 2. Cell line plot (overview, all categories) ──────────────────────────────
print("\nPlotting normalised CPM per cell line …")

cell_line_stats = (
    meta.groupby(["cell_line", "edit_category"])["norm_cpm"]
    .agg(mean="mean", sem="sem", n="count")
    .reset_index()
)
cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_norm_cpm.tsv"), sep="\t", index=False)

sub = cell_line_stats.sort_values("cell_line")
fig, ax = plt.subplots(figsize=(max(8, len(sub) * 0.35 + 2), 5))
colors = [cat_palette[c] for c in sub["edit_category"]]
ax.bar(range(len(sub)), sub["mean"], yerr=sub["sem"],
       color=colors, capsize=3, width=0.7, error_kw=dict(linewidth=1))
ax.set_xticks(range(len(sub)))
ax.set_xticklabels(sub["cell_line"], rotation=60, ha="right", fontsize=6)
ax.set_ylabel("Normalised CPM (target / reference)")
ax.set_title("ATRX: Mean normalised CPM per cell line\n"
             "(mean ± SEM across biological replicates)")
cats_here = sorted(sub["edit_category"].unique())
handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
ax.legend(handles, cats_here, loc="upper right", fontsize=7,
          ncol=max(1, len(cats_here) // 4))
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
out = os.path.join(OUT_DIR, "02_cell_line_ATRX.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

# ── 3. Edit category vs WT: statistics, plotted with all edits together ──────
# Repeated for each reference region (chr12, NPRL3, STAT3, MYC).
print("\nComputing normalised CPM statistics (vs WT) and plotting all edits together …")

all_cats_order = sorted(meta["edit_category"].unique(), key=lambda c: (c != WT_LABEL, c))

def plot_norm_cpm_vs_wt(value_col, ref_label, file_suffix):
    groups = {cat: grp[value_col].dropna().values for cat, grp in meta.groupby("edit_category")}

    stats_rows = []
    for cat in EDIT_CATEGORIES_VS_WT:
        v_wt, v_cat = groups.get(WT_LABEL, np.array([])), groups.get(cat, np.array([]))
        u, p = (stats.mannwhitneyu(v_wt, v_cat, alternative="two-sided")
                if len(v_wt) >= 2 and len(v_cat) >= 2 else (np.nan, np.nan))
        stats_rows.append(dict(group1=WT_LABEL, group2=cat, U=u, p_raw=p,
                                n_WT=len(v_wt), n_group2=len(v_cat)))

    stats_df = pd.DataFrame(stats_rows)
    p_vals = stats_df["p_raw"].values
    valid = ~np.isnan(p_vals)
    padj = np.full(len(p_vals), np.nan)
    if valid.sum() > 1:
        _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
    elif valid.sum() == 1:
        padj[valid] = p_vals[valid]
    stats_df["p_adj_BH"] = padj
    stats_df["significant"] = padj < 0.05
    stats_name = f"statistics_norm_cpm_vs_WT{file_suffix}.tsv"
    stats_df.to_csv(os.path.join(OUT_DIR, stats_name), sep="\t", index=False)
    print(f"Saved {stats_name}")
    print(stats_df.to_string(index=False))

    fig, ax = plt.subplots(figsize=(max(6, len(all_cats_order) * 1.2 + 2), 6))
    means = [np.mean(groups.get(c, [np.nan])) for c in all_cats_order]
    sems = [stats.sem(groups[c]) if len(groups.get(c, [])) > 1 else 0 for c in all_cats_order]
    colors = [cat_palette[c] for c in all_cats_order]
    ax.bar(range(len(all_cats_order)), means, yerr=sems, color=colors, alpha=0.75,
           capsize=4, width=0.6, error_kw=dict(linewidth=1.5), zorder=2)
    for i, cat in enumerate(all_cats_order):
        pts = groups.get(cat, np.array([]))
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=20, alpha=0.6, zorder=3)

    ax.set_xticks(range(len(all_cats_order)))
    ax.set_xticklabels(all_cats_order, fontsize=9)
    ax.set_ylabel(f"Normalised CPM (target / {ref_label})")
    ax.set_title(f"ATRX: Mean normalised CPM per edit category — ref: {ref_label}\n"
                 "(bar = mean ± SEM; dots = biological replicates)")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, f"03_edit_category_ATRX{file_suffix}.pdf")
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"  Saved {out}")

for key, *_rest, ref_label in REFERENCES:
    value_col = "norm_cpm" if key == "ref" else f"norm_cpm_{key}"
    file_suffix = "" if key == "ref" else f"_{key}"
    plot_norm_cpm_vs_wt(value_col, ref_label, file_suffix)

# ── 4. Raw CPM plots (cell line level, overview) ──────────────────────────────
print("\nPlotting raw CPM (target & reference) per cell line …")

raw_metrics = ["target_cpm"] + [
    ("ref_cpm" if key == "ref" else f"ref_cpm_{key}") for key, *_ in REFERENCES
]
raw_metric_labels = {"target_cpm": f"Target CPM ({TARGET_CHR}:{TARGET_START:,}-{TARGET_END:,})"}
for key, *_rest, ref_label in REFERENCES:
    col = "ref_cpm" if key == "ref" else f"ref_cpm_{key}"
    raw_metric_labels[col] = ref_label

raw_cell_line_stats = (
    meta.groupby(["cell_line", "edit_category"])[raw_metrics]
    .agg(["mean", "sem", "count"])
)
raw_cell_line_stats.columns = ["_".join(c) for c in raw_cell_line_stats.columns]
raw_cell_line_stats = raw_cell_line_stats.reset_index().sort_values("cell_line")
raw_cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_raw_cpm.tsv"), sep="\t", index=False)

colors = [cat_palette[c] for c in raw_cell_line_stats["edit_category"]]
fig, axes = plt.subplots(len(raw_metrics), 1,
                         figsize=(max(8, len(raw_cell_line_stats) * 0.35 + 2), 3.5 * len(raw_metrics)),
                         sharex=True)
for ax, col in zip(axes, raw_metrics):
    ax.bar(range(len(raw_cell_line_stats)), raw_cell_line_stats[f"{col}_mean"],
           yerr=raw_cell_line_stats[f"{col}_sem"],
           color=colors, capsize=3, width=0.7, error_kw=dict(linewidth=1))
    ax.set_ylabel(f"{raw_metric_labels[col]}\nraw CPM")
    ax.spines[["top", "right"]].set_visible(False)

axes[-1].set_xticks(range(len(raw_cell_line_stats)))
axes[-1].set_xticklabels(raw_cell_line_stats["cell_line"], rotation=60, ha="right", fontsize=6)
fig.suptitle("ATRX: Mean raw CPM per cell line (mean ± SEM across biological replicates)",
             fontsize=9)
cats_here = sorted(raw_cell_line_stats["edit_category"].unique())
handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
axes[0].legend(handles, cats_here, loc="upper right", fontsize=7,
               ncol=max(1, len(cats_here) // 4))
plt.tight_layout()
out = os.path.join(OUT_DIR, "04_cell_line_ATRX_raw_cpm.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

# ── 5. Edit category vs WT: statistics, plotted with all edits together ──────
print("\nComputing raw CPM statistics (vs WT) and plotting all edits together …")

raw_stats_rows = []
raw_groups = {col: {cat: grp[col].dropna().values for cat, grp in meta.groupby("edit_category")}
              for col in raw_metrics}
for col in raw_metrics:
    for cat in EDIT_CATEGORIES_VS_WT:
        v_wt = raw_groups[col].get(WT_LABEL, np.array([]))
        v_cat = raw_groups[col].get(cat, np.array([]))
        u, p = (stats.mannwhitneyu(v_wt, v_cat, alternative="two-sided")
                if len(v_wt) >= 2 and len(v_cat) >= 2 else (np.nan, np.nan))
        raw_stats_rows.append(dict(metric=col, group1=WT_LABEL, group2=cat, U=u, p_raw=p,
                                    n_WT=len(v_wt), n_group2=len(v_cat)))

raw_stats_df = pd.DataFrame(raw_stats_rows)
for col in raw_metrics:
    mask = raw_stats_df["metric"] == col
    p_vals = raw_stats_df.loc[mask, "p_raw"].values
    valid = ~np.isnan(p_vals)
    padj = np.full(len(p_vals), np.nan)
    if valid.sum() > 1:
        _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
    elif valid.sum() == 1:
        padj[valid] = p_vals[valid]
    raw_stats_df.loc[mask, "p_adj_BH"] = padj
    raw_stats_df.loc[mask, "significant"] = padj < 0.05
raw_stats_df.to_csv(os.path.join(OUT_DIR, "statistics_raw_cpm_vs_WT.tsv"), sep="\t", index=False)
print("Saved statistics_raw_cpm_vs_WT.tsv")
print(raw_stats_df.to_string(index=False))

n_cats = len(all_cats_order)
fig, axes = plt.subplots(1, len(raw_metrics), figsize=(4 * len(raw_metrics) + 1, 6))
for ax, col in zip(axes, raw_metrics):
    means = [np.mean(raw_groups[col].get(c, [np.nan])) for c in all_cats_order]
    sems = [stats.sem(raw_groups[col][c]) if len(raw_groups[col].get(c, [])) > 1 else 0
            for c in all_cats_order]
    colors = [cat_palette[c] for c in all_cats_order]
    ax.bar(range(n_cats), means, yerr=sems, color=colors, alpha=0.75,
           capsize=4, width=0.6, error_kw=dict(linewidth=1.5), zorder=2)
    for i, cat in enumerate(all_cats_order):
        pts = raw_groups[col].get(cat, np.array([]))
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=20, alpha=0.6, zorder=3)

    ax.set_xticks(range(n_cats))
    ax.set_xticklabels(all_cats_order, fontsize=9)
    ax.set_ylabel(f"{raw_metric_labels[col]}\nraw CPM")
    ax.set_title(raw_metric_labels[col].split(" (")[0], fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

fig.suptitle("ATRX: Mean raw CPM per edit category\n"
             "(bar = mean ± SEM; dots = biological replicates)", fontsize=9)
plt.tight_layout()
out = os.path.join(OUT_DIR, "05_edit_category_ATRX_raw_cpm.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

print(f"\nAll outputs written to: {OUT_DIR}")
