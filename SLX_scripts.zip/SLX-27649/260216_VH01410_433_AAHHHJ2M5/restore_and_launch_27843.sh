#!/bin/bash
# Restore all 679 integrated genomes to scratch, rebuild missing BWA indexes,
# then launch the full SLX-27843 pipeline.
set -euo pipefail

WORKDIR=/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5
NAS=/mnt/nas-data/sblab/group_folders/herka01/ENS_whole_genome_references_combined
DST=${WORKDIR}/integrated_genomes_combined
BWA=${WORKDIR}/.snakemake/conda/295bb62721956f30418c463873e54524_/bin/bwa

LOG=${WORKDIR}/logs/slurm/restore_and_launch_$(date +%Y%m%d_%H%M%S).log
exec > >(tee -a "$LOG") 2>&1

cd "$WORKDIR"

# ── Step 1: Copy missing genomes from NAS to scratch ─────────────────────────
echo "[$(date)] Step 1: Copying genomes from NAS to scratch..."

COPIED=0
for fa in "${NAS}"/SPLINK_*.integrated.fa; do
    sample=$(basename "$fa" .integrated.fa)
    if [[ ! -f "${DST}/${sample}.integrated.fa" ]]; then
        cp "$fa" "${DST}/${sample}.integrated.fa"
        for ext in .amb .ann .bwt .pac .sa; do
            src="${NAS}/${sample}.integrated.fa${ext}"
            [[ -f "$src" ]] && cp "$src" "${DST}/${sample}.integrated.fa${ext}"
        done
        COPIED=$((COPIED + 1))
        # Progress every 50
        [[ $((COPIED % 50)) -eq 0 ]] && echo "[$(date)]   ... copied $COPIED samples"
    fi
done
echo "[$(date)] Copied $COPIED genomes from NAS to scratch."

# ── Step 2: Verify all 679 FASTA files present ──────────────────────────────
FA_COUNT=$(ls "${DST}"/*.fa 2>/dev/null | wc -l)
echo "[$(date)] Step 2: ${FA_COUNT} FASTA files on scratch."
if [[ "$FA_COUNT" -lt 679 ]]; then
    echo "[$(date)] ERROR: Only ${FA_COUNT}/679 FASTA files. Aborting."
    exit 1
fi

# ── Step 3: Rebuild any missing BWA indexes ──────────────────────────────────
echo "[$(date)] Step 3: Checking BWA indexes..."

MISSING_IDX=()
for fa in "${DST}"/SPLINK_*.integrated.fa; do
    if [[ ! -f "${fa}.bwt" ]]; then
        MISSING_IDX+=("$fa")
    fi
done

if [[ ${#MISSING_IDX[@]} -gt 0 ]]; then
    echo "[$(date)] ${#MISSING_IDX[@]} samples need BWA indexing. Submitting SLURM jobs..."

    JOBIDS=()
    for fa in "${MISSING_IDX[@]}"; do
        sample=$(basename "$fa" .integrated.fa)
        JID=$(sbatch --parsable --partition=epyc --cpus-per-task=8 --mem=16G --time=2:00:00 \
            --job-name="bwa_idx_${sample}" \
            --output="${WORKDIR}/logs/splink/${sample}.bwa_index_restore.out" \
            --error="${WORKDIR}/logs/splink/${sample}.bwa_index_restore.err" \
            --wrap="${BWA} index ${fa}")
        JOBIDS+=("$JID")
        echo "  Submitted ${sample}: job ${JID}"
    done

    echo "[$(date)] Waiting for ${#JOBIDS[@]} BWA index jobs to finish..."
    for jid in "${JOBIDS[@]}"; do
        while squeue -j "$jid" -h 2>/dev/null | grep -q .; do
            sleep 30
        done
    done
    echo "[$(date)] All BWA index jobs finished."

    # Verify
    STILL_MISSING=0
    for fa in "${MISSING_IDX[@]}"; do
        [[ ! -f "${fa}.bwt" ]] && STILL_MISSING=$((STILL_MISSING + 1))
    done
    if [[ "$STILL_MISSING" -gt 0 ]]; then
        echo "[$(date)] ERROR: ${STILL_MISSING} BWA indexes still missing after rebuild. Aborting."
        exit 1
    fi
else
    echo "[$(date)] All BWA indexes present."
fi

BWT_COUNT=$(ls "${DST}"/*.fa.bwt 2>/dev/null | wc -l)
echo "[$(date)] Final check: ${BWT_COUNT} BWA-indexed genomes on scratch."

# ── Step 4: Launch SLX-27843 pipeline ────────────────────────────────────────
echo "[$(date)] Step 4: Launching SLX-27843 full pipeline..."

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27843

LOG27843=logs/slurm/smk_master_local_$(date +%Y%m%d_%H%M%S).log
echo "[$(date)] SLX-27843 logging to $LOG27843"

snakemake --profile profile --jobs 100 2>&1 | tee "$LOG27843"
