#!/usr/bin/env python3
"""
Analyse ATRX CPM bigwig files in this folder.

Two bigwig naming conventions are both present and are combined as
replicates of the same cell line:
  {cell_line}_{rep}_ATRX.r1.trimmed.hg38.sort.sortName.cpm.bs10.bw
  ATRX_{cell_line}_{rep}.r1.hg38.sort..s600.cpm.bs3.bw

Cell lines: WT, 14, 17, 25, 26 (each bigwig file = one replicate).

Tasks:
 1. Plot CPM signal across chr16:113170-114196 (target ±500 bp) per sample
 2. Compute mean CPM in target region, normalised to reference region
    (chr12:25,250,600-25,251,600)
 3. Plot average normalised CPM per cell line, with individual replicate
    points and statistical comparisons (Kruskal-Wallis + pairwise
    Mann-Whitney U, FDR corrected)
 4. Peak CPM analysis (peak_cpm_analysis/): compute and plot the highest
    (max) CPM value in each window per sample, and repeat the normalised
    per-cell-line comparison (step 3) using the peak value instead of the
    window mean.
 5. NPRL normalisation (nprl_normalisation/): repeat the mean- and peak-based
    normalised per-cell-line comparisons using chr16:138,029-139,191 as the
    reference region instead of the chr12 reference.
 6. Raw CPM comparison (raw_cpm_comparison/): plot un-normalised mean CPM
    per cell line at the test locus and four control/reference loci —
    KRAS (chr12), NPRL3 (chr16:138,029-139,191), STAT3
    (chr17:42,388,142-42,389,213) and MYC (chr8:127,734,866-127,736,733).
 7. STAT3 / MYC normalisation (stat3_normalisation/, myc_normalisation/):
    repeat the mean- and peak-based normalised per-cell-line comparisons
    (as in step 5) using STAT3 and MYC as the reference region instead of
    the chr12 reference.
 8. Raw peak CPM comparison (raw_peak_cpm_comparison/): same as step 6 but
    using the highest (max) CPM value per locus per sample instead of the
    mean.
"""

import re
import glob
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pyBigWig
from scipy import stats
from statsmodels.stats.multitest import multipletests
from itertools import combinations

# ── Plot styling: Helvetica Neue Light everywhere; save PDF + SVG ────────────
def _register_helvetica_neue_light():
    """Extract & register the true 'Helvetica Neue Light' face from the
    system Helvetica Neue TrueType Collection (matplotlib otherwise only
    ever sees face index 0 of a .ttc, which is Regular). Falls back
    silently if the system font or fontTools is unavailable."""
    import matplotlib.font_manager as fm
    cache_path = os.path.expanduser("~/.cache/matplotlib_fonts/HelveticaNeueLight.ttf")
    if not os.path.exists(cache_path):
        ttc_path = "/System/Library/Fonts/HelveticaNeue.ttc"
        if not os.path.exists(ttc_path):
            return
        try:
            from fontTools.ttLib import TTCollection
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            for font in TTCollection(ttc_path).fonts:
                if font["name"].getDebugName(2) == "Light":
                    font.save(cache_path)
                    break
        except Exception:
            return
    if os.path.exists(cache_path):
        fm.fontManager.addfont(cache_path)

_register_helvetica_neue_light()

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"]
plt.rcParams["font.weight"] = "light"
plt.rcParams["axes.labelweight"] = "light"
plt.rcParams["axes.titleweight"] = "light"
plt.rcParams["figure.titleweight"] = "light"

def save_fig(fig, out_base, **kwargs):
    """Save a figure as both PDF and SVG (out_base without extension)."""
    save_kwargs = dict(bbox_inches="tight", dpi=150)
    save_kwargs.update(kwargs)
    for ext in (".pdf", ".svg"):
        fig.savefig(f"{out_base}{ext}", **save_kwargs)

# ── Regions ──────────────────────────────────────────────────────────────────
TARGET_CHR   = "chr16"
PEAK_START   = 113670
PEAK_END     = 113696

# Two windows for track plots
WINDOWS = {
    "500bp": (PEAK_START - 500,  PEAK_END + 500),
    "10kb":  (PEAK_START - 10000, PEAK_END + 10000),
}
# CPM quantification always uses the 500 bp window
TARGET_START = WINDOWS["500bp"][0]
TARGET_END   = WINDOWS["500bp"][1]

REF_CHR   = "chr12"
REF_START = 25_250_600
REF_END   = 25_251_600

# Alternative normalisation reference region (NPRL locus)
NPRL_REF_CHR   = "chr16"
NPRL_REF_START = 138_029
NPRL_REF_END   = 139_191

# Additional loci for the raw (un-normalised) CPM comparison
STAT3_CHR, STAT3_START, STAT3_END = "chr17", 42_388_142, 42_389_213
MYC_CHR,   MYC_START,   MYC_END   = "chr8",  127_734_866, 127_736_733

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BIGWIG_DIR = SCRIPT_DIR
OUT_DIR    = os.path.join(SCRIPT_DIR, "cpm_analysis")
PEAK_OUT_DIR = os.path.join(SCRIPT_DIR, "peak_cpm_analysis")
NPRL_OUT_DIR = os.path.join(SCRIPT_DIR, "nprl_normalisation")
RAW_OUT_DIR = os.path.join(SCRIPT_DIR, "raw_cpm_comparison")
RAW_PEAK_OUT_DIR = os.path.join(SCRIPT_DIR, "raw_peak_cpm_comparison")
STAT3_OUT_DIR = os.path.join(SCRIPT_DIR, "stat3_normalisation")
MYC_OUT_DIR = os.path.join(SCRIPT_DIR, "myc_normalisation")
BIN_SIZE   = 25   # bp resolution for track plots

CELL_LINE_ORDER = ["WT", "14", "17", "25", "26"]
# Peak-based plots use 17 before 14 (all other ordering/analysis unchanged)
PEAK_CELL_LINE_ORDER = ["WT", "17", "14", "25", "26"]

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(PEAK_OUT_DIR, exist_ok=True)
os.makedirs(NPRL_OUT_DIR, exist_ok=True)
os.makedirs(RAW_OUT_DIR, exist_ok=True)
os.makedirs(RAW_PEAK_OUT_DIR, exist_ok=True)
os.makedirs(STAT3_OUT_DIR, exist_ok=True)
os.makedirs(MYC_OUT_DIR, exist_ok=True)

# ── Sample parsing ────────────────────────────────────────────────────────────
def parse_sample(path):
    """
    Recognise either of the two bigwig naming conventions in this folder
    and return dict with cell_line, replicate, batch (bs10 / bs3).
    """
    fname = os.path.basename(path)

    # ATRX_{cell_line}_{rep}.r1.hg38.sort..s600.cpm.bs3.bw
    m = re.match(r'^ATRX_(WT|\d+)_([A-Za-z0-9]+)\.r1\.hg38\.sort\.\.s600\.cpm\.bs3\.bw$', fname)
    if m:
        cell_line, rep = m.group(1), m.group(2)
        return dict(stem=fname, cell_line=cell_line, replicate=rep, batch="bs3")

    # {cell_line}_{rep}_ATRX.r1.trimmed.hg38.sort.sortName.cpm.bs10.bw
    m = re.match(r'^(WT|\d+)_([A-Za-z0-9]+)_ATRX\.r1\.trimmed\.hg38\.sort\.sortName\.cpm\.bs10\.bw$', fname)
    if m:
        cell_line, rep = m.group(1), m.group(2)
        return dict(stem=fname, cell_line=cell_line, replicate=rep, batch="bs10")

    return None

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "*.bw")))
records = []
for path in bw_files:
    info = parse_sample(path)
    if info:
        info["path"] = path
        records.append(info)
    else:
        print(f"  Skipping unrecognised file: {os.path.basename(path)}")

meta = pd.DataFrame(records)
meta["cell_line"] = pd.Categorical(meta["cell_line"], categories=CELL_LINE_ORDER, ordered=True)
meta = meta.sort_values(["cell_line", "batch", "replicate"]).reset_index(drop=True)

print(f"\n{len(meta)} samples found")
print(meta.groupby("cell_line", observed=True).size().to_string())

# ── Helper: fetch mean / max CPM from a region ───────────────────────────────
def fetch_mean(bw, chrom, start, end):
    """Return mean CPM over [start, end). Returns 0 if chrom absent."""
    try:
        val = bw.stats(chrom, start, end, type="mean", exact=True)[0]
        return float(val) if val is not None else 0.0
    except RuntimeError:
        return 0.0

def fetch_max(bw, chrom, start, end):
    """Return the highest CPM value over [start, end). Returns 0 if chrom absent."""
    try:
        val = bw.stats(chrom, start, end, type="max", exact=True)[0]
        return float(val) if val is not None else 0.0
    except RuntimeError:
        return 0.0

# ── 1 & 2: Extract per-sample CPM ────────────────────────────────────────────
print("\nExtracting CPM values …")
target_cpms, ref_cpms, ref_peak_cpms = [], [], []
nprl_ref_cpms, nprl_ref_peak_cpms = [], []
stat3_cpms, stat3_peak_cpms = [], []
myc_cpms, myc_peak_cpms = [], []
peak_cpms = {win: [] for win in WINDOWS}   # win → list of per-sample max CPM
# Binned signal for each window
track_bins = {win: np.arange(s, e, BIN_SIZE) for win, (s, e) in WINDOWS.items()}
track_data = {win: {} for win in WINDOWS}   # win → stem → signal array

for _, row in meta.iterrows():
    bw = pyBigWig.open(row["path"])
    for win, bins in track_bins.items():
        sig = [fetch_mean(bw, TARGET_CHR, int(b), int(b + BIN_SIZE)) for b in bins]
        track_data[win][row["stem"]] = np.array(sig)
        win_start, win_end = WINDOWS[win]
        peak_cpms[win].append(fetch_max(bw, TARGET_CHR, win_start, win_end))
    target_cpms.append(fetch_mean(bw, TARGET_CHR, TARGET_START, TARGET_END))
    ref_cpms.append(fetch_mean(bw, REF_CHR, REF_START, REF_END))
    ref_peak_cpms.append(fetch_max(bw, REF_CHR, REF_START, REF_END))
    nprl_ref_cpms.append(fetch_mean(bw, NPRL_REF_CHR, NPRL_REF_START, NPRL_REF_END))
    nprl_ref_peak_cpms.append(fetch_max(bw, NPRL_REF_CHR, NPRL_REF_START, NPRL_REF_END))
    stat3_cpms.append(fetch_mean(bw, STAT3_CHR, STAT3_START, STAT3_END))
    stat3_peak_cpms.append(fetch_max(bw, STAT3_CHR, STAT3_START, STAT3_END))
    myc_cpms.append(fetch_mean(bw, MYC_CHR, MYC_START, MYC_END))
    myc_peak_cpms.append(fetch_max(bw, MYC_CHR, MYC_START, MYC_END))
    bw.close()

meta["target_cpm"]   = target_cpms
meta["ref_cpm"]      = ref_cpms
meta["ref_peak_cpm"] = ref_peak_cpms
meta["nprl_ref_cpm"]      = nprl_ref_cpms
meta["nprl_ref_peak_cpm"] = nprl_ref_peak_cpms
meta["STAT3_cpm"]      = stat3_cpms
meta["STAT3_peak_cpm"] = stat3_peak_cpms
meta["MYC_cpm"]        = myc_cpms
meta["MYC_peak_cpm"]   = myc_peak_cpms
for win in WINDOWS:
    meta[f"peak_cpm_{win}"] = peak_cpms[win]
# Normalised CPM: target / reference (guard against div-by-zero)
meta["norm_cpm"] = meta.apply(
    lambda r: r["target_cpm"] / r["ref_cpm"] if r["ref_cpm"] > 0 else np.nan, axis=1
)
# Normalised peak CPM (500 bp window, matching the CPM quantification window)
# Both target and reference use their peak (max) value within the window.
meta["norm_peak_cpm"] = meta.apply(
    lambda r: r["peak_cpm_500bp"] / r["ref_peak_cpm"] if r["ref_peak_cpm"] > 0 else np.nan, axis=1
)
# Normalised CPM using the NPRL locus (chr16:138,029-139,191) as reference
meta["norm_cpm_nprl"] = meta.apply(
    lambda r: r["target_cpm"] / r["nprl_ref_cpm"] if r["nprl_ref_cpm"] > 0 else np.nan, axis=1
)
meta["norm_peak_cpm_nprl"] = meta.apply(
    lambda r: r["peak_cpm_500bp"] / r["nprl_ref_peak_cpm"] if r["nprl_ref_peak_cpm"] > 0 else np.nan, axis=1
)
# Normalised CPM using STAT3 (chr17:42,388,142-42,389,213) as reference
meta["norm_cpm_stat3"] = meta.apply(
    lambda r: r["target_cpm"] / r["STAT3_cpm"] if r["STAT3_cpm"] > 0 else np.nan, axis=1
)
meta["norm_peak_cpm_stat3"] = meta.apply(
    lambda r: r["peak_cpm_500bp"] / r["STAT3_peak_cpm"] if r["STAT3_peak_cpm"] > 0 else np.nan, axis=1
)
# Normalised CPM using MYC (chr8:127,734,866-127,736,733) as reference
meta["norm_cpm_myc"] = meta.apply(
    lambda r: r["target_cpm"] / r["MYC_cpm"] if r["MYC_cpm"] > 0 else np.nan, axis=1
)
meta["norm_peak_cpm_myc"] = meta.apply(
    lambda r: r["peak_cpm_500bp"] / r["MYC_peak_cpm"] if r["MYC_peak_cpm"] > 0 else np.nan, axis=1
)
meta.to_csv(os.path.join(OUT_DIR, "per_sample_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm.tsv")

# ── Colour palette per cell line ─────────────────────────────────────────────
def make_palette(keys):
    n = len(keys)
    colors = sns.color_palette("tab20", n) if n <= 20 else sns.color_palette("husl", n)
    return dict(zip(keys, colors))

cell_lines_present = [c for c in CELL_LINE_ORDER if c in meta["cell_line"].unique()]
peak_cell_lines_present = [c for c in PEAK_CELL_LINE_ORDER if c in meta["cell_line"].unique()]
cat_palette = make_palette(cell_lines_present)

# ── 1. Track plots (500 bp and 10 kb windows) ────────────────────────────────
print("Plotting CPM tracks …")

sub = meta.sort_values("cell_line")
n_samples = len(sub)

for win_label, (win_start, win_end) in WINDOWS.items():
    bins = track_bins[win_label]
    x = bins - win_start  # relative coordinates
    peak_rel_s = PEAK_START - win_start
    peak_rel_e = PEAK_END   - win_start

    # Compute a single Y max across all samples (99th percentile + 15% headroom)
    all_vals = np.concatenate([track_data[win_label][r["stem"]]
                               for _, r in sub.iterrows()])
    ymax = np.nanpercentile(all_vals, 99) * 1.15
    ymax = max(ymax, 0.01)

    fig, axes = plt.subplots(
        n_samples, 1,
        figsize=(14, max(4, 0.38 * n_samples + 1.5)),
        sharex=True, sharey=False,
        gridspec_kw={"hspace": 0.05}
    )
    if n_samples == 1:
        axes = [axes]

    for ax, (_, row) in zip(axes, sub.iterrows()):
        sig = track_data[win_label][row["stem"]]
        color = cat_palette[row["cell_line"]]
        ax.fill_between(x, sig, alpha=0.85, color=color, linewidth=0)
        ax.axvspan(peak_rel_s, peak_rel_e, color="red", alpha=0.15, linewidth=0)
        ax.set_ylim(0, ymax)   # same scale for every sample
        label = f"{row['cell_line']}_{row['replicate']}"
        ax.set_ylabel(label, fontsize=4.5, rotation=0,
                      ha="right", va="center", labelpad=2)
        ax.set_yticks([round(ymax, 2)])  # single tick showing the shared max
        ax.set_yticklabels([f"{ymax:.2f}"], fontsize=3.5)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(left=False)

    axes[-1].set_xlabel(f"{TARGET_CHR} offset from window start (bp)")
    wlen = win_end - win_start
    fig.suptitle(
        f"ATRX: CPM signal – {win_label} window  "
        f"({TARGET_CHR}:{win_start:,}–{win_end:,}, {wlen:,} bp)\n"
        f"Red band = peak ({TARGET_CHR}:{PEAK_START:,}–{PEAK_END:,})  |  "
        f"All tracks: same Y scale (max = {ymax:.2f} CPM)",
        fontsize=8
    )
    cls_here = [c for c in cell_lines_present if c in sub["cell_line"].unique()]
    handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cls_here]
    axes[0].legend(handles, cls_here, loc="upper right", fontsize=5,
                   ncol=max(1, len(cls_here) // 4), framealpha=0.7)

    out_base = os.path.join(OUT_DIR, f"01_tracks_ATRX_{win_label}")
    save_fig(fig, out_base)
    plt.close(fig)
    print(f"  Saved {out_base}.pdf / .svg")

# ── 3. Average normalised CPM per cell line + statistics ────────────────────
print("Plotting normalised CPM per cell line + statistics …")

cell_line_stats = (
    meta.groupby("cell_line", observed=True)["norm_cpm"]
    .agg(mean="mean", sem="sem", n="count")
    .reset_index()
)
cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_norm_cpm.tsv"), sep="\t", index=False)

# ── Statistical tests ─────────────────────────────────────────────────────────
groups = {cl: grp["norm_cpm"].dropna().values
          for cl, grp in meta.groupby("cell_line", observed=True)}

# Omnibus tests: Kruskal-Wallis (non-parametric) and one-way ANOVA (parametric)
vals = [v for v in groups.values() if len(v) >= 2]
if len(vals) >= 2:
    h_stat, kw_p = stats.kruskal(*vals)
    f_stat, anova_p = stats.f_oneway(*vals)
else:
    h_stat, kw_p = np.nan, np.nan
    f_stat, anova_p = np.nan, np.nan

# Pairwise comparisons: Mann-Whitney U (non-parametric) and Welch's two-sided t-test (parametric)
all_stats = []
pairs = list(combinations([c for c in CELL_LINE_ORDER if c in groups], 2))
for g1, g2 in pairs:
    v1, v2 = groups[g1], groups[g2]
    if len(v1) >= 2 and len(v2) >= 2:
        u, p_mwu = stats.mannwhitneyu(v1, v2, alternative="two-sided")
        t_stat, p_ttest = stats.ttest_ind(v1, v2, equal_var=False, alternative="two-sided")
    else:
        u, p_mwu = np.nan, np.nan
        t_stat, p_ttest = np.nan, np.nan
    all_stats.append(dict(group1=g1, group2=g2,
                          U=u, p_raw_mwu=p_mwu, kw_H=h_stat, kw_p=kw_p,
                          t_stat=t_stat, p_raw_ttest=p_ttest, anova_F=f_stat, anova_p=anova_p))

stats_df = pd.DataFrame(all_stats)
if not stats_df.empty:
    for col_p, col_adj, col_sig in [("p_raw_mwu", "p_adj_BH_mwu", "significant_mwu"),
                                     ("p_raw_ttest", "p_adj_BH_ttest", "significant_ttest")]:
        p_vals = stats_df[col_p].values
        valid = ~np.isnan(p_vals)
        padj = np.full(len(p_vals), np.nan)
        if valid.sum() > 1:
            _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
        elif valid.sum() == 1:
            padj[valid] = p_vals[valid]
        stats_df[col_adj] = padj
        stats_df[col_sig] = padj < 0.05
    stats_df.to_csv(os.path.join(OUT_DIR, "statistics_pairwise.tsv"), sep="\t", index=False)
    print("Saved statistics_pairwise.tsv")

# ── Bar plot per cell line ────────────────────────────────────────────────────
def sig_stars(p):
    if np.isnan(p): return ""
    if p < 0.001: return "***"
    if p < 0.01:  return "**"
    if p < 0.05:  return "*"
    return "ns"

sub_cl = cell_line_stats.copy()
sub_cl["cell_line"] = pd.Categorical(sub_cl["cell_line"], categories=CELL_LINE_ORDER, ordered=True)
sub_cl = sub_cl.sort_values("cell_line")

n_cls = len(sub_cl)
fig, ax = plt.subplots(figsize=(max(6, n_cls * 0.8 + 2), 6))
colors = [cat_palette[c] for c in sub_cl["cell_line"]]

positions = np.arange(n_cls)
ax.bar(positions, sub_cl["mean"], yerr=sub_cl["sem"],
       color=colors, alpha=0.75, capsize=4, width=0.6,
       error_kw=dict(linewidth=1.5), zorder=2)

# Individual data points
for i, cl in enumerate(sub_cl["cell_line"]):
    pts = meta[meta["cell_line"] == cl]["norm_cpm"].dropna()
    jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
    ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

# Significance brackets
if not stats_df.empty:
    y_max = sub_cl["mean"].max() + sub_cl["sem"].max()
    cls_ordered = list(sub_cl["cell_line"])
    step = y_max * 0.12
    level = 0
    for _, row_s in stats_df[stats_df["p_adj_BH_mwu"] < 0.05].iterrows():
        if row_s["group1"] not in cls_ordered or row_s["group2"] not in cls_ordered:
            continue
        x1 = cls_ordered.index(row_s["group1"])
        x2 = cls_ordered.index(row_s["group2"])
        y = y_max + step * (level + 1)
        ax.plot([x1, x1, x2, x2], [y - step * 0.1, y, y, y - step * 0.1],
                color="black", linewidth=0.8)
        ax.text((x1 + x2) / 2, y + step * 0.05,
                sig_stars(row_s["p_adj_BH_mwu"]), ha="center", va="bottom", fontsize=8)
        level += 1

ax.set_xticks(positions)
ax.set_xticklabels(sub_cl["cell_line"], rotation=0, ha="center", fontsize=9)
ax.set_ylabel("Normalised CPM (target / reference)")
kw_text = ""
if not np.isnan(kw_p):
    kw_text = f"  (Kruskal-Wallis p={kw_p:.3g}; ANOVA p={anova_p:.3g})"
ax.set_title(f"ATRX: Mean normalised CPM per cell line{kw_text}\n"
             f"(bar = mean ± SEM; dots = all replicates; * FDR<0.05 Mann-Whitney U)")
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
out_base = os.path.join(OUT_DIR, "03_cell_line_ATRX")
save_fig(fig, out_base)
plt.close(fig)
print(f"  Saved {out_base}.pdf / .svg")

# ── Summary print ─────────────────────────────────────────────────────────────
print(f"\nAll outputs written to: {OUT_DIR}")
print("\nNormalised CPM by cell line:")
print(
    meta.groupby("cell_line", observed=True)["norm_cpm"]
    .agg(["mean", "sem", "count"])
    .round(4)
    .to_string()
)
if not stats_df.empty:
    sig = stats_df[stats_df.get("significant_mwu", False)]
    if len(sig):
        print("\nSignificant pairwise comparisons, Mann-Whitney U (FDR < 0.05):")
        print(sig[["group1", "group2", "p_raw_mwu", "p_adj_BH_mwu"]].to_string(index=False))
    else:
        print("\nNo pairwise comparisons significant at FDR < 0.05 (Mann-Whitney U)")
    sig_t = stats_df[stats_df.get("significant_ttest", False)]
    if len(sig_t):
        print("\nSignificant pairwise comparisons, Welch's t-test (FDR < 0.05):")
        print(sig_t[["group1", "group2", "p_raw_ttest", "p_adj_BH_ttest"]].to_string(index=False))
    else:
        print("\nNo pairwise comparisons significant at FDR < 0.05 (Welch's t-test)")

# ══════════════════════════════════════════════════════════════════════════
# PEAK CPM ANALYSIS — highest CPM value per window per sample
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("PEAK CPM ANALYSIS (highest CPM value per window per sample)")
print("=" * 70)

# ── Per-sample peak CPM table ─────────────────────────────────────────────────
peak_cols = (["stem", "cell_line", "replicate", "batch"]
             + [f"peak_cpm_{w}" for w in WINDOWS]
             + ["ref_peak_cpm", "norm_peak_cpm"])
meta[peak_cols].to_csv(os.path.join(PEAK_OUT_DIR, "per_sample_peak_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_peak_cpm.tsv")

# ── Plot: highest CPM value per sample, one panel per window ────────────────
sub_peak = meta.copy()
sub_peak["cell_line"] = pd.Categorical(sub_peak["cell_line"], categories=PEAK_CELL_LINE_ORDER, ordered=True)
sub_peak = sub_peak.sort_values("cell_line")
n_samples_peak = len(sub_peak)
fig, axes = plt.subplots(1, len(WINDOWS),
                         figsize=(7 * len(WINDOWS), max(4, 0.3 * n_samples_peak + 2)))
if len(WINDOWS) == 1:
    axes = [axes]
for ax, win in zip(axes, WINDOWS):
    labels = [f"{r['cell_line']}_{r['replicate']}" for _, r in sub_peak.iterrows()]
    colors = [cat_palette[r["cell_line"]] for _, r in sub_peak.iterrows()]
    ax.barh(range(n_samples_peak), sub_peak[f"peak_cpm_{win}"], color=colors)
    ax.set_yticks(range(n_samples_peak))
    ax.set_yticklabels(labels, fontsize=5)
    ax.invert_yaxis()
    ax.set_xlabel("Highest CPM in window")
    ax.set_title(f"{win} window")
    ax.spines[["top", "right"]].set_visible(False)
handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in peak_cell_lines_present]
axes[-1].legend(handles, peak_cell_lines_present, loc="lower right", fontsize=6)
fig.suptitle("ATRX: Highest CPM value per sample, per window", fontsize=9)
plt.tight_layout()
out_base = os.path.join(PEAK_OUT_DIR, "00_peak_cpm_per_sample")
save_fig(fig, out_base)
plt.close(fig)
print(f"  Saved {out_base}.pdf / .svg")

# ── Downstream analysis using peak CPM (500 bp window, normalised) ──────────
print("Plotting normalised peak CPM per cell line + statistics …")

cell_line_stats_peak = (
    meta.groupby("cell_line", observed=True)["norm_peak_cpm"]
    .agg(mean="mean", sem="sem", n="count")
    .reset_index()
)
cell_line_stats_peak.to_csv(os.path.join(PEAK_OUT_DIR, "cell_line_peak_cpm.tsv"), sep="\t", index=False)

groups_peak = {cl: grp["norm_peak_cpm"].dropna().values
               for cl, grp in meta.groupby("cell_line", observed=True)}

# Omnibus tests: Kruskal-Wallis (non-parametric) and one-way ANOVA (parametric)
vals_peak = [v for v in groups_peak.values() if len(v) >= 2]
if len(vals_peak) >= 2:
    h_stat_peak, kw_p_peak = stats.kruskal(*vals_peak)
    f_stat_peak, anova_p_peak = stats.f_oneway(*vals_peak)
else:
    h_stat_peak, kw_p_peak = np.nan, np.nan
    f_stat_peak, anova_p_peak = np.nan, np.nan

# Pairwise comparisons: Mann-Whitney U (non-parametric) and Welch's two-sided t-test (parametric)
all_stats_peak = []
pairs_peak = list(combinations([c for c in PEAK_CELL_LINE_ORDER if c in groups_peak], 2))
for g1, g2 in pairs_peak:
    v1, v2 = groups_peak[g1], groups_peak[g2]
    if len(v1) >= 2 and len(v2) >= 2:
        u, p_mwu = stats.mannwhitneyu(v1, v2, alternative="two-sided")
        t_stat, p_ttest = stats.ttest_ind(v1, v2, equal_var=False, alternative="two-sided")
    else:
        u, p_mwu = np.nan, np.nan
        t_stat, p_ttest = np.nan, np.nan
    all_stats_peak.append(dict(group1=g1, group2=g2,
                               U=u, p_raw_mwu=p_mwu, kw_H=h_stat_peak, kw_p=kw_p_peak,
                               t_stat=t_stat, p_raw_ttest=p_ttest,
                               anova_F=f_stat_peak, anova_p=anova_p_peak))

stats_df_peak = pd.DataFrame(all_stats_peak)
if not stats_df_peak.empty:
    for col_p, col_adj, col_sig in [("p_raw_mwu", "p_adj_BH_mwu", "significant_mwu"),
                                     ("p_raw_ttest", "p_adj_BH_ttest", "significant_ttest")]:
        p_vals = stats_df_peak[col_p].values
        valid = ~np.isnan(p_vals)
        padj = np.full(len(p_vals), np.nan)
        if valid.sum() > 1:
            _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
        elif valid.sum() == 1:
            padj[valid] = p_vals[valid]
        stats_df_peak[col_adj] = padj
        stats_df_peak[col_sig] = padj < 0.05
    stats_df_peak.to_csv(os.path.join(PEAK_OUT_DIR, "statistics_pairwise_peak.tsv"), sep="\t", index=False)
    print("Saved statistics_pairwise_peak.tsv")

# ── Bar plot per cell line (peak-based) ──────────────────────────────────────
sub_cl_peak = cell_line_stats_peak.copy()
sub_cl_peak["cell_line"] = pd.Categorical(sub_cl_peak["cell_line"], categories=PEAK_CELL_LINE_ORDER, ordered=True)
sub_cl_peak = sub_cl_peak.sort_values("cell_line")

n_cls_peak = len(sub_cl_peak)
fig, ax = plt.subplots(figsize=(max(6, n_cls_peak * 0.8 + 2), 6))
colors = [cat_palette[c] for c in sub_cl_peak["cell_line"]]

positions = np.arange(n_cls_peak)
ax.bar(positions, sub_cl_peak["mean"], yerr=sub_cl_peak["sem"],
       color=colors, alpha=0.75, capsize=4, width=0.6,
       error_kw=dict(linewidth=1.5), zorder=2)

for i, cl in enumerate(sub_cl_peak["cell_line"]):
    pts = meta[meta["cell_line"] == cl]["norm_peak_cpm"].dropna()
    jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
    ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

if not stats_df_peak.empty:
    y_max = sub_cl_peak["mean"].max() + sub_cl_peak["sem"].max()
    cls_ordered = list(sub_cl_peak["cell_line"])
    step = y_max * 0.12
    level = 0
    for _, row_s in stats_df_peak[stats_df_peak["p_adj_BH_mwu"] < 0.05].iterrows():
        if row_s["group1"] not in cls_ordered or row_s["group2"] not in cls_ordered:
            continue
        x1 = cls_ordered.index(row_s["group1"])
        x2 = cls_ordered.index(row_s["group2"])
        y = y_max + step * (level + 1)
        ax.plot([x1, x1, x2, x2], [y - step * 0.1, y, y, y - step * 0.1],
                color="black", linewidth=0.8)
        ax.text((x1 + x2) / 2, y + step * 0.05,
                sig_stars(row_s["p_adj_BH_mwu"]), ha="center", va="bottom", fontsize=8)
        level += 1

ax.set_xticks(positions)
ax.set_xticklabels(sub_cl_peak["cell_line"], rotation=0, ha="center", fontsize=9)
ax.set_ylabel("Normalised peak CPM (max target / max reference)")
kw_text_peak = ""
if not np.isnan(kw_p_peak):
    kw_text_peak = f"  (Kruskal-Wallis p={kw_p_peak:.3g}; ANOVA p={anova_p_peak:.3g})"
ax.set_title(f"ATRX: Peak (max) normalised CPM per cell line{kw_text_peak}\n"
             f"(bar = mean ± SEM; dots = all replicates; * FDR<0.05 Mann-Whitney U; 500bp window)")
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
out_base = os.path.join(PEAK_OUT_DIR, "03_cell_line_peak_ATRX")
save_fig(fig, out_base)
plt.close(fig)
print(f"  Saved {out_base}.pdf / .svg")

# ── Summary print ─────────────────────────────────────────────────────────────
print(f"\nAll peak CPM outputs written to: {PEAK_OUT_DIR}")
print("\nNormalised peak CPM by cell line:")
print(
    meta.groupby("cell_line", observed=True)["norm_peak_cpm"]
    .agg(["mean", "sem", "count"])
    .round(4)
    .to_string()
)
if not stats_df_peak.empty:
    sig_peak = stats_df_peak[stats_df_peak.get("significant_mwu", False)]
    if len(sig_peak):
        print("\nSignificant pairwise comparisons, Mann-Whitney U (peak CPM, FDR < 0.05):")
        print(sig_peak[["group1", "group2", "p_raw_mwu", "p_adj_BH_mwu"]].to_string(index=False))
    else:
        print("\nNo pairwise comparisons significant at FDR < 0.05 (peak CPM, Mann-Whitney U)")
    sig_peak_t = stats_df_peak[stats_df_peak.get("significant_ttest", False)]
    if len(sig_peak_t):
        print("\nSignificant pairwise comparisons, Welch's t-test (peak CPM, FDR < 0.05):")
        print(sig_peak_t[["group1", "group2", "p_raw_ttest", "p_adj_BH_ttest"]].to_string(index=False))
    else:
        print("\nNo pairwise comparisons significant at FDR < 0.05 (peak CPM, Welch's t-test)")

# ══════════════════════════════════════════════════════════════════════════
# NPRL NORMALISATION — reference region chr16:138,029-139,191
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print(f"NPRL NORMALISATION (reference: {NPRL_REF_CHR}:{NPRL_REF_START:,}-{NPRL_REF_END:,})")
print("=" * 70)

nprl_cols = (["stem", "cell_line", "replicate", "batch", "target_cpm",
              "nprl_ref_cpm", "norm_cpm_nprl", "peak_cpm_500bp",
              "nprl_ref_peak_cpm", "norm_peak_cpm_nprl"])
meta[nprl_cols].to_csv(os.path.join(NPRL_OUT_DIR, "per_sample_cpm_nprl.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm_nprl.tsv")

def run_nprl_cell_line_analysis(value_col, out_name, ylabel, title_label, extra_subtitle="", out_dir=None, cell_line_order=None):
    """Compute per-cell-line stats + omnibus/pairwise tests, plot bar chart,
    and save all outputs for a given normalised/raw value column.
    `out_dir` defaults to NPRL_OUT_DIR (kept for backward compatibility).
    `cell_line_order` defaults to CELL_LINE_ORDER (pass PEAK_CELL_LINE_ORDER
    for peak-based plots, which show 17 before 14)."""
    if out_dir is None:
        out_dir = NPRL_OUT_DIR
    order = cell_line_order if cell_line_order is not None else CELL_LINE_ORDER
    cl_stats = (
        meta.groupby("cell_line", observed=True)[value_col]
        .agg(mean="mean", sem="sem", n="count")
        .reset_index()
    )
    cl_stats.to_csv(os.path.join(out_dir, f"cell_line_{out_name}.tsv"), sep="\t", index=False)

    groups_n = {cl: grp[value_col].dropna().values
                for cl, grp in meta.groupby("cell_line", observed=True)}

    vals_n = [v for v in groups_n.values() if len(v) >= 2]
    if len(vals_n) >= 2:
        h_stat_n, kw_p_n = stats.kruskal(*vals_n)
        f_stat_n, anova_p_n = stats.f_oneway(*vals_n)
    else:
        h_stat_n, kw_p_n = np.nan, np.nan
        f_stat_n, anova_p_n = np.nan, np.nan

    all_stats_n = []
    pairs_n = list(combinations([c for c in order if c in groups_n], 2))
    for g1, g2 in pairs_n:
        v1, v2 = groups_n[g1], groups_n[g2]
        if len(v1) >= 2 and len(v2) >= 2:
            u, p_mwu = stats.mannwhitneyu(v1, v2, alternative="two-sided")
            t_stat, p_ttest = stats.ttest_ind(v1, v2, equal_var=False, alternative="two-sided")
        else:
            u, p_mwu = np.nan, np.nan
            t_stat, p_ttest = np.nan, np.nan
        all_stats_n.append(dict(group1=g1, group2=g2,
                                U=u, p_raw_mwu=p_mwu, kw_H=h_stat_n, kw_p=kw_p_n,
                                t_stat=t_stat, p_raw_ttest=p_ttest,
                                anova_F=f_stat_n, anova_p=anova_p_n))

    stats_df_n = pd.DataFrame(all_stats_n)
    if not stats_df_n.empty:
        for col_p, col_adj, col_sig in [("p_raw_mwu", "p_adj_BH_mwu", "significant_mwu"),
                                         ("p_raw_ttest", "p_adj_BH_ttest", "significant_ttest")]:
            p_vals = stats_df_n[col_p].values
            valid = ~np.isnan(p_vals)
            padj = np.full(len(p_vals), np.nan)
            if valid.sum() > 1:
                _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
            elif valid.sum() == 1:
                padj[valid] = p_vals[valid]
            stats_df_n[col_adj] = padj
            stats_df_n[col_sig] = padj < 0.05
        stats_df_n.to_csv(os.path.join(out_dir, f"statistics_pairwise_{out_name}.tsv"), sep="\t", index=False)
        print(f"Saved statistics_pairwise_{out_name}.tsv")

    sub_cl_n = cl_stats.copy()
    sub_cl_n["cell_line"] = pd.Categorical(sub_cl_n["cell_line"], categories=order, ordered=True)
    sub_cl_n = sub_cl_n.sort_values("cell_line")

    n_cls_n = len(sub_cl_n)
    fig, ax = plt.subplots(figsize=(max(6, n_cls_n * 0.8 + 2), 6))
    colors = [cat_palette[c] for c in sub_cl_n["cell_line"]]

    positions_n = np.arange(n_cls_n)
    ax.bar(positions_n, sub_cl_n["mean"], yerr=sub_cl_n["sem"],
           color=colors, alpha=0.75, capsize=4, width=0.6,
           error_kw=dict(linewidth=1.5), zorder=2)

    for i, cl in enumerate(sub_cl_n["cell_line"]):
        pts = meta[meta["cell_line"] == cl][value_col].dropna()
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

    if not stats_df_n.empty:
        y_max = sub_cl_n["mean"].max() + sub_cl_n["sem"].max()
        cls_ordered = list(sub_cl_n["cell_line"])
        step = y_max * 0.12
        level = 0
        for _, row_s in stats_df_n[stats_df_n["p_adj_BH_mwu"] < 0.05].iterrows():
            if row_s["group1"] not in cls_ordered or row_s["group2"] not in cls_ordered:
                continue
            x1 = cls_ordered.index(row_s["group1"])
            x2 = cls_ordered.index(row_s["group2"])
            y = y_max + step * (level + 1)
            ax.plot([x1, x1, x2, x2], [y - step * 0.1, y, y, y - step * 0.1],
                    color="black", linewidth=0.8)
            ax.text((x1 + x2) / 2, y + step * 0.05,
                    sig_stars(row_s["p_adj_BH_mwu"]), ha="center", va="bottom", fontsize=8)
            level += 1

    ax.set_xticks(positions_n)
    ax.set_xticklabels(sub_cl_n["cell_line"], rotation=0, ha="center", fontsize=9)
    ax.set_ylabel(ylabel)
    kw_text_n = ""
    if not np.isnan(kw_p_n):
        kw_text_n = f"  (Kruskal-Wallis p={kw_p_n:.3g}; ANOVA p={anova_p_n:.3g})"
    ax.set_title(f"{title_label}{kw_text_n}\n"
                 f"(bar = mean ± SEM; dots = all replicates; * FDR<0.05 Mann-Whitney U{extra_subtitle})")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    out_base = os.path.join(out_dir, f"03_cell_line_{out_name}")
    save_fig(fig, out_base)
    plt.close(fig)
    print(f"  Saved {out_base}.pdf / .svg")

    print(f"\nNormalised {title_label} by cell line:")
    print(
        meta.groupby("cell_line", observed=True)[value_col]
        .agg(["mean", "sem", "count"])
        .round(4)
        .to_string()
    )
    if not stats_df_n.empty:
        sig_n = stats_df_n[stats_df_n.get("significant_mwu", False)]
        if len(sig_n):
            print(f"\nSignificant pairwise comparisons, Mann-Whitney U ({out_name}, FDR < 0.05):")
            print(sig_n[["group1", "group2", "p_raw_mwu", "p_adj_BH_mwu"]].to_string(index=False))
        else:
            print(f"\nNo pairwise comparisons significant at FDR < 0.05 ({out_name}, Mann-Whitney U)")
        sig_n_t = stats_df_n[stats_df_n.get("significant_ttest", False)]
        if len(sig_n_t):
            print(f"\nSignificant pairwise comparisons, Welch's t-test ({out_name}, FDR < 0.05):")
            print(sig_n_t[["group1", "group2", "p_raw_ttest", "p_adj_BH_ttest"]].to_string(index=False))
        else:
            print(f"\nNo pairwise comparisons significant at FDR < 0.05 ({out_name}, Welch's t-test)")

# ── Mean-based CPM, normalised to the NPRL reference region ─────────────────
print("\nPlotting mean normalised CPM per cell line (NPRL reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_cpm_nprl", "nprl_mean_ATRX",
    "Normalised CPM (target / NPRL reference)",
    "ATRX: Mean normalised CPM per cell line (NPRL reference)",
)

# ── Peak-based CPM, normalised to the NPRL reference region ─────────────────
print("\nPlotting peak normalised CPM per cell line (NPRL reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_peak_cpm_nprl", "nprl_peak_ATRX",
    "Normalised peak CPM (max target / max NPRL reference)",
    "ATRX: Peak (max) normalised CPM per cell line (NPRL reference)",
    extra_subtitle="; 500bp window",
    cell_line_order=PEAK_CELL_LINE_ORDER,
)

print(f"\nAll NPRL normalisation outputs written to: {NPRL_OUT_DIR}")

# ══════════════════════════════════════════════════════════════════════════
# STAT3 NORMALISATION — reference region chr17:42,388,142-42,389,213
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print(f"STAT3 NORMALISATION (reference: {STAT3_CHR}:{STAT3_START:,}-{STAT3_END:,})")
print("=" * 70)

stat3_cols = (["stem", "cell_line", "replicate", "batch", "target_cpm",
               "STAT3_cpm", "norm_cpm_stat3", "peak_cpm_500bp",
               "STAT3_peak_cpm", "norm_peak_cpm_stat3"])
meta[stat3_cols].to_csv(os.path.join(STAT3_OUT_DIR, "per_sample_cpm_stat3.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm_stat3.tsv")

print("\nPlotting mean normalised CPM per cell line (STAT3 reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_cpm_stat3", "stat3_mean_ATRX",
    "Normalised CPM (target / STAT3 reference)",
    "ATRX: Mean normalised CPM per cell line (STAT3 reference)",
    out_dir=STAT3_OUT_DIR,
)

print("\nPlotting peak normalised CPM per cell line (STAT3 reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_peak_cpm_stat3", "stat3_peak_ATRX",
    "Normalised peak CPM (max target / max STAT3 reference)",
    "ATRX: Peak (max) normalised CPM per cell line (STAT3 reference)",
    extra_subtitle="; 500bp window",
    out_dir=STAT3_OUT_DIR,
    cell_line_order=PEAK_CELL_LINE_ORDER,
)

print(f"\nAll STAT3 normalisation outputs written to: {STAT3_OUT_DIR}")

# ══════════════════════════════════════════════════════════════════════════
# MYC NORMALISATION — reference region chr8:127,734,866-127,736,733
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print(f"MYC NORMALISATION (reference: {MYC_CHR}:{MYC_START:,}-{MYC_END:,})")
print("=" * 70)

myc_cols = (["stem", "cell_line", "replicate", "batch", "target_cpm",
             "MYC_cpm", "norm_cpm_myc", "peak_cpm_500bp",
             "MYC_peak_cpm", "norm_peak_cpm_myc"])
meta[myc_cols].to_csv(os.path.join(MYC_OUT_DIR, "per_sample_cpm_myc.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm_myc.tsv")

print("\nPlotting mean normalised CPM per cell line (MYC reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_cpm_myc", "myc_mean_ATRX",
    "Normalised CPM (target / MYC reference)",
    "ATRX: Mean normalised CPM per cell line (MYC reference)",
    out_dir=MYC_OUT_DIR,
)

print("\nPlotting peak normalised CPM per cell line (MYC reference) + statistics …")
run_nprl_cell_line_analysis(
    "norm_peak_cpm_myc", "myc_peak_ATRX",
    "Normalised peak CPM (max target / max MYC reference)",
    "ATRX: Peak (max) normalised CPM per cell line (MYC reference)",
    extra_subtitle="; 500bp window",
    out_dir=MYC_OUT_DIR,
    cell_line_order=PEAK_CELL_LINE_ORDER,
)

print(f"\nAll MYC normalisation outputs written to: {MYC_OUT_DIR}")

# ══════════════════════════════════════════════════════════════════════════
# RAW CPM COMPARISON — test locus vs KRAS, NPRL3, STAT3, MYC (no normalisation)
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("RAW CPM COMPARISON (un-normalised mean CPM per locus)")
print("=" * 70)

# stem, cell_line, replicate, batch already carry every raw CPM value we need:
#   target_cpm    → test locus (chr16 target, 500 bp window)
#   ref_cpm       → KRAS (chr12 control locus)
#   nprl_ref_cpm  → NPRL3 (chr16:138,029-139,191)
#   STAT3_cpm     → STAT3 (chr17:42,388,142-42,389,213)
#   MYC_cpm       → MYC (chr8:127,734,866-127,736,733)
RAW_LOCI = {
    "test_locus": ("target_cpm",  f"Test locus ({TARGET_CHR}:{TARGET_START:,}-{TARGET_END:,})"),
    "KRAS":       ("ref_cpm",      f"KRAS ({REF_CHR}:{REF_START:,}-{REF_END:,})"),
    "NPRL3":      ("nprl_ref_cpm", f"NPRL3 ({NPRL_REF_CHR}:{NPRL_REF_START:,}-{NPRL_REF_END:,})"),
    "STAT3":      ("STAT3_cpm",    f"STAT3 ({STAT3_CHR}:{STAT3_START:,}-{STAT3_END:,})"),
    "MYC":        ("MYC_cpm",      f"MYC ({MYC_CHR}:{MYC_START:,}-{MYC_END:,})"),
}

raw_cols = ["stem", "cell_line", "replicate", "batch"] + [col for col, _ in RAW_LOCI.values()]
meta[raw_cols].to_csv(os.path.join(RAW_OUT_DIR, "per_sample_raw_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_raw_cpm.tsv")

# ── Per-locus bar plots (raw CPM per cell line, mean ± SEM, with stats) ──────
for locus_name, (value_col, label) in RAW_LOCI.items():
    print(f"\nPlotting raw CPM per cell line — {label} …")
    run_nprl_cell_line_analysis(
        value_col, f"raw_{locus_name}",
        "CPM (un-normalised)",
        f"ATRX: Raw CPM per cell line — {label}",
        out_dir=RAW_OUT_DIR,
    )

# ── Combined overview: all five loci side by side ────────────────────────────
print("\nPlotting combined raw CPM overview across all loci …")
fig, axes = plt.subplots(1, len(RAW_LOCI), figsize=(4.2 * len(RAW_LOCI), 5), sharey=False)
for ax, (locus_name, (value_col, label)) in zip(axes, RAW_LOCI.items()):
    cl_stats_locus = (
        meta.groupby("cell_line", observed=True)[value_col]
        .agg(mean="mean", sem="sem", n="count")
        .reset_index()
    )
    cl_stats_locus["cell_line"] = pd.Categorical(cl_stats_locus["cell_line"], categories=CELL_LINE_ORDER, ordered=True)
    cl_stats_locus = cl_stats_locus.sort_values("cell_line")
    colors = [cat_palette[c] for c in cl_stats_locus["cell_line"]]
    positions = np.arange(len(cl_stats_locus))
    ax.bar(positions, cl_stats_locus["mean"], yerr=cl_stats_locus["sem"],
           color=colors, alpha=0.75, capsize=3, width=0.6, error_kw=dict(linewidth=1.2))
    for i, cl in enumerate(cl_stats_locus["cell_line"]):
        pts = meta[meta["cell_line"] == cl][value_col].dropna()
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=10, alpha=0.6, zorder=3)
    ax.set_xticks(positions)
    ax.set_xticklabels(cl_stats_locus["cell_line"], fontsize=8)
    ax.set_title(locus_name, fontsize=9)
    ax.set_ylabel("CPM (un-normalised)" if locus_name == "test_locus" else "", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
fig.suptitle("ATRX: Raw CPM per cell line across all loci (mean ± SEM; dots = replicates)", fontsize=9)
plt.tight_layout()
out_base = os.path.join(RAW_OUT_DIR, "00_raw_cpm_all_loci_overview")
save_fig(fig, out_base)
plt.close(fig)
print(f"  Saved {out_base}.pdf / .svg")

print(f"\nAll raw CPM comparison outputs written to: {RAW_OUT_DIR}")

# ══════════════════════════════════════════════════════════════════════════
# RAW PEAK CPM COMPARISON — same loci as above, using the highest (max)
# CPM value per locus per sample instead of the mean (no normalisation)
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("RAW PEAK CPM COMPARISON (un-normalised peak CPM per locus)")
print("=" * 70)

# peak_cpm_500bp → test locus (chr16 target, 500 bp window)
# ref_peak_cpm       → KRAS (chr12 control locus)
# nprl_ref_peak_cpm  → NPRL3 (chr16:138,029-139,191)
# STAT3_peak_cpm     → STAT3 (chr17:42,388,142-42,389,213)
# MYC_peak_cpm       → MYC (chr8:127,734,866-127,736,733)
RAW_PEAK_LOCI = {
    "test_locus": ("peak_cpm_500bp",  f"Test locus ({TARGET_CHR}:{TARGET_START:,}-{TARGET_END:,})"),
    "KRAS":       ("ref_peak_cpm",      f"KRAS ({REF_CHR}:{REF_START:,}-{REF_END:,})"),
    "NPRL3":      ("nprl_ref_peak_cpm", f"NPRL3 ({NPRL_REF_CHR}:{NPRL_REF_START:,}-{NPRL_REF_END:,})"),
    "STAT3":      ("STAT3_peak_cpm",    f"STAT3 ({STAT3_CHR}:{STAT3_START:,}-{STAT3_END:,})"),
    "MYC":        ("MYC_peak_cpm",      f"MYC ({MYC_CHR}:{MYC_START:,}-{MYC_END:,})"),
}

raw_peak_cols = ["stem", "cell_line", "replicate", "batch"] + [col for col, _ in RAW_PEAK_LOCI.values()]
meta[raw_peak_cols].to_csv(os.path.join(RAW_PEAK_OUT_DIR, "per_sample_raw_peak_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_raw_peak_cpm.tsv")

# ── Per-locus bar plots (raw peak CPM per cell line, mean ± SEM, with stats) ─
for locus_name, (value_col, label) in RAW_PEAK_LOCI.items():
    print(f"\nPlotting raw peak CPM per cell line — {label} …")
    run_nprl_cell_line_analysis(
        value_col, f"rawpeak_{locus_name}",
        "Peak CPM (un-normalised)",
        f"ATRX: Raw peak CPM per cell line — {label}",
        out_dir=RAW_PEAK_OUT_DIR,
        cell_line_order=PEAK_CELL_LINE_ORDER,
    )

# ── Combined overview: all five loci side by side ────────────────────────────
print("\nPlotting combined raw peak CPM overview across all loci …")
fig, axes = plt.subplots(1, len(RAW_PEAK_LOCI), figsize=(4.2 * len(RAW_PEAK_LOCI), 5), sharey=False)
for ax, (locus_name, (value_col, label)) in zip(axes, RAW_PEAK_LOCI.items()):
    cl_stats_locus = (
        meta.groupby("cell_line", observed=True)[value_col]
        .agg(mean="mean", sem="sem", n="count")
        .reset_index()
    )
    cl_stats_locus["cell_line"] = pd.Categorical(cl_stats_locus["cell_line"], categories=PEAK_CELL_LINE_ORDER, ordered=True)
    cl_stats_locus = cl_stats_locus.sort_values("cell_line")
    colors = [cat_palette[c] for c in cl_stats_locus["cell_line"]]
    positions = np.arange(len(cl_stats_locus))
    ax.bar(positions, cl_stats_locus["mean"], yerr=cl_stats_locus["sem"],
           color=colors, alpha=0.75, capsize=3, width=0.6, error_kw=dict(linewidth=1.2))
    for i, cl in enumerate(cl_stats_locus["cell_line"]):
        pts = meta[meta["cell_line"] == cl][value_col].dropna()
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=10, alpha=0.6, zorder=3)
    ax.set_xticks(positions)
    ax.set_xticklabels(cl_stats_locus["cell_line"], fontsize=8)
    ax.set_title(locus_name, fontsize=9)
    ax.set_ylabel("Peak CPM (un-normalised)" if locus_name == "test_locus" else "", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
fig.suptitle("ATRX: Raw peak CPM per cell line across all loci (mean ± SEM; dots = replicates)", fontsize=9)
plt.tight_layout()
out_base = os.path.join(RAW_PEAK_OUT_DIR, "00_raw_peak_cpm_all_loci_overview")
save_fig(fig, out_base)
plt.close(fig)
print(f"  Saved {out_base}.pdf / .svg")

print(f"\nAll raw peak CPM comparison outputs written to: {RAW_PEAK_OUT_DIR}")
