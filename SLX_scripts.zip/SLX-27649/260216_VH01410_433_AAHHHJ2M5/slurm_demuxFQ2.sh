#!/bin/bash

mkdir demultiplexed
sbatch --time 12:00:00 --mem 32G --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -b SLX-27649_lostreads_r1.fq.gz  -o ./demultiplexed  -s SLX-27649_summary2_demuxFQ_r1.txt SLX-27649_demultiplex_r1.txt SLX-27392.UnspecifiedIndex.AAHHHJ2M5.s_1.r_1.fq.gz"
sbatch --mem 32G --time 12:00:00 --wrap "/Users/simeon01/applications/demultiplexer.rhel/demuxFQ -c -d -i -e -R -t 1 -r 0.01 -l 9 -b SLX-27649_lostreads_r2.fq.gz -o ./demultiplexed -s SLX-27649_summary2_demuxFQ_r2.txt SLX-27649_demultiplex_r2.txt  SLX-27392.UnspecifiedIndex.AAHHHJ2M5.s_1.r_2.fq.gz"
