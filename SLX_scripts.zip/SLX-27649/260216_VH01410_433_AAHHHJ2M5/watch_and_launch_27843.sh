#!/bin/bash
# Wait for smk27649 screen session to finish, then launch SLX-27843 pipeline.
# Run this inside a screen:  screen -dmS watcher bash watch_and_launch_27843.sh
set -euo pipefail

echo "[$(date)] Waiting for smk27649 screen session to finish..."

while screen -ls 2>/dev/null | grep -q "smk27649"; do
    sleep 60
done

echo "[$(date)] smk27649 finished."

# Check if SLX-27649 completed successfully (all 679 genomes on NAS)
NAS_COUNT=$(ls /mnt/nas-data/sblab/group_folders/herka01/ENS_whole_genome_references_combined/*.fa 2>/dev/null | wc -l)
echo "[$(date)] NAS genomes: ${NAS_COUNT}/679"

if [[ "$NAS_COUNT" -lt 679 ]]; then
    echo "[$(date)] WARNING: Only ${NAS_COUNT} genomes on NAS, expected 679. Check SLX-27649 log for errors."
    echo "[$(date)] NOT launching SLX-27843 automatically."
    exit 1
fi

echo "[$(date)] All 679 genomes on NAS. Launching SLX-27843 pipeline..."

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27843

LOG=logs/slurm/smk_master_local_$(date +%Y%m%d_%H%M%S).log
echo "[$(date)] SLX-27843 logging to $LOG"

snakemake --profile profile --jobs 100 2>&1 | tee "$LOG"
