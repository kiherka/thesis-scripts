import os
import glob
import pandas as pd
import pybedtools
import matplotlib.pyplot as plt
from datetime import datetime

def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

# Paths
bed_dir = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_combined/"
gtf_path = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/reference/gencode.v44.annotation.gtf"
enhancer_path = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/reference/fantom5_enhancers_hg38.bed"
out_table = "junction_annotation_table.tsv"
out_pie = "junction_annotation_piechart.png"

log("Starting junction annotation")

# Prepare GTF features as BED files
def gtf_to_bed(gtf, feature_type):
    log(f"Loading {feature_type} features from GTF")
    bed = []
    with open(gtf) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.strip().split('\t')
            if fields[2] == feature_type:
                chrom = fields[0]
                start = int(fields[3]) - 1
                end = int(fields[4])
                bed.append(pybedtools.Interval(chrom, start, end, name=feature_type))
    log(f"  Found {len(bed)} {feature_type} intervals")
    return pybedtools.BedTool(bed)

# Prepare Gencode features
log("Loading reference annotations...")
exons = gtf_to_bed(gtf_path, "exon")
cds = gtf_to_bed(gtf_path, "CDS")
utr5 = gtf_to_bed(gtf_path, "five_prime_UTR")
utr3 = gtf_to_bed(gtf_path, "three_prime_UTR")
genes = gtf_to_bed(gtf_path, "gene")

# Promoters: 1kb either side of TSS
log("Creating promoter regions")
promoters = []
with open(gtf_path) as f:
    for line in f:
        if line.startswith("#"):
            continue
        fields = line.strip().split('\t')
        if fields[2] == "gene":
            chrom = fields[0]
            start = int(fields[3]) - 1001
            end = int(fields[3]) + 1000
            if start < 0:
                start = 0
            promoters.append(pybedtools.Interval(chrom, start, end, name="promoter"))
promoters = pybedtools.BedTool(promoters)
log(f"  Created {len(promoters)} promoter regions")

# Load FANTOM5 enhancers
log("Loading FANTOM5 enhancers")
enhancers = pybedtools.BedTool(enhancer_path)
log(f"  Loaded {len(enhancers)} enhancer regions")

# Collect all junction sites first
log("Collecting all junction sites from BED files...")
all_sites = []
bedfiles = glob.glob(os.path.join(bed_dir, "*.bed"))
log(f"  Found {len(bedfiles)} BED files to process")

for i, bedfile in enumerate(bedfiles, 1):
    sample = os.path.basename(bedfile).split(".")[0]
    with open(bedfile) as f:
        for line in f:
            if line.startswith("#") or line.strip() == "":
                continue
            fields = line.strip().split()
            chrom = fields[0]
            start = int(fields[1])
            end = int(fields[2])
            pos = (start + end) // 2
            all_sites.append((sample, chrom, pos, pos+1))
    if i % 100 == 0:
        log(f"  Processed {i}/{len(bedfiles)} files ({len(all_sites)} sites total)")

log(f"Collected {len(all_sites)} total junction sites")

# Create a single BedTool with all sites
log("Creating BedTool from all sites...")
sites_bed = pybedtools.BedTool([pybedtools.Interval(s[1], s[2], s[3]) for s in all_sites])

# Batch intersect with each feature type
log("Performing batch intersections...")
log("  Intersecting with exons...")
exon_hits = set(sites_bed.intersect(exons, wa=True))
log("  Intersecting with CDS...")
cds_hits = set(sites_bed.intersect(cds, wa=True))
log("  Intersecting with 5'UTR...")
utr5_hits = set(sites_bed.intersect(utr5, wa=True))
log("  Intersecting with 3'UTR...")
utr3_hits = set(sites_bed.intersect(utr3, wa=True))
log("  Intersecting with promoters...")
promoter_hits = set(sites_bed.intersect(promoters, wa=True))
log("  Intersecting with enhancers...")
enhancer_hits = set(sites_bed.intersect(enhancers, wa=True))
log("  Intersecting with genes...")
gene_hits = set(sites_bed.intersect(genes, wa=True))

# Annotate each site based on priority
log("Annotating sites...")
rows = []
for i, (sample, chrom, start, end) in enumerate(all_sites, 1):
    site_key = (chrom, start, end)
    
    if any(h.chrom == chrom and h.start == start for h in enhancer_hits):
        annotation = "Enhancer"
    elif any(h.chrom == chrom and h.start == start for h in promoter_hits):
        annotation = "Promoter"
    elif any(h.chrom == chrom and h.start == start for h in exon_hits):
        annotation = "Exon"
    elif any(h.chrom == chrom and h.start == start for h in cds_hits):
        annotation = "CDS"
    elif any(h.chrom == chrom and h.start == start for h in utr5_hits):
        annotation = "5UTR"
    elif any(h.chrom == chrom and h.start == start for h in utr3_hits):
        annotation = "3UTR"
    elif any(h.chrom == chrom and h.start == start for h in gene_hits):
        annotation = "Intron"
    else:
        annotation = "Intergenic"
    
    rows.append([sample, f"{chrom}:{start}", annotation])
    
    if i % 10000 == 0:
        log(f"  Annotated {i}/{len(all_sites)} sites")

log(f"Annotation complete: {len(rows)} sites annotated")

# Save table
log(f"Saving annotation table to {out_table}")
df = pd.DataFrame(rows, columns=["Sample", "Genomic_location", "Site_type"])
df.to_csv(out_table, sep="\t", index=False)

# Pie chart
log("Creating pie chart...")
pie_counts = df["Site_type"].value_counts()
log(f"  Site type distribution: {dict(pie_counts)}")
plt.figure(figsize=(7,7))
pie_counts.plot.pie(autopct='%1.1f%%', startangle=90, counterclock=False)
plt.ylabel("")
plt.title("Distribution of Insert Sites by Gencode Annotation")
plt.tight_layout()
plt.savefig(out_pie)
plt.close()

log(f"Annotation table saved: {out_table}")
log(f"Pie chart saved: {out_pie}")
log("DONE!")
