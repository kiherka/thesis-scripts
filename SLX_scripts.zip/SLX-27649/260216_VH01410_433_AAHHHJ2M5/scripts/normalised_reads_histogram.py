#!/usr/bin/env python3
"""Normalise junction read counts to RPM and plot the global distribution.

For every sample X:
  1. Read total_aligned_reads from  stats/X.peak_noise.loose.txt
  2. Read n_reads (col 5) from      consensus_loose/X.junctions.bed
  3. Compute  OPM = n_reads / total_aligned_reads * 1e6
     (observations per million aligned reads)

Then pool *all* RPM values across all 679 samples and draw a histogram.

Usage
-----
    python scripts/normalised_reads_histogram.py \
        --bed-dir   consensus_loose \
        --stats-dir stats \
        --out       plots/normalised_junction_rpm_histogram.pdf
"""

import argparse
import glob
import os
import re
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


# ── helpers ────────────────────────────────────────────────────────────
def parse_peak_noise(path: str) -> dict:
    """Return key→value dict from a peak_noise.loose.txt file."""
    d = {}
    with open(path) as fh:
        for line in fh:
            parts = line.strip().split("\t")
            if len(parts) == 2:
                d[parts[0]] = parts[1]
    return d


def parse_junctions(path: str) -> list[int]:
    """Return list of n_reads values from a junctions.bed file."""
    counts = []
    with open(path) as fh:
        for line in fh:
            if line.startswith("#"):
                continue
            cols = line.strip().split("\t")
            if len(cols) >= 5:
                counts.append(int(cols[4]))
    return counts


def normalise_thresholds(tsv_path: str, stats_dir: str) -> dict:
    """Read per-sample thresholds and normalise to RPM.

    Returns dict with keys 'stringent_rpm' and 'combined_rpm', each a list
    of per-sample RPM-normalised thresholds, plus their means.
    """
    stringent_rpm = []
    combined_rpm = []
    with open(tsv_path) as fh:
        header = fh.readline()  # skip header
        for line in fh:
            cols = line.strip().split("\t")
            if len(cols) < 7:
                continue
            sample = cols[0]
            stringent_raw = float(cols[2])   # Stringent threshold (peak noise)
            combined_raw  = float(cols[6])   # Combined threshold (effective)

            stats_path = os.path.join(stats_dir,
                                      f"{sample}.peak_noise.loose.txt")
            if not os.path.exists(stats_path):
                continue
            info = parse_peak_noise(stats_path)
            total_aligned = float(info["total_aligned_reads"])
            if total_aligned == 0:
                continue

            stringent_rpm.append(stringent_raw / total_aligned * 1e6)
            combined_rpm.append(combined_raw / total_aligned * 1e6)

    s_arr = np.array(stringent_rpm)
    c_arr = np.array(combined_rpm)
    return {
        "stringent_rpm": s_arr,
        "combined_rpm":  c_arr,
        "stringent_mean": float(s_arr.mean()),
        "combined_mean":  float(c_arr.mean()),
        "stringent_median": float(np.median(s_arr)),
        "combined_median":  float(np.median(c_arr)),
    }


# ── main ───────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bed-dir", default="consensus_loose",
                    help="Directory with <sample>.junctions.bed files")
    ap.add_argument("--stats-dir", default="stats",
                    help="Directory with <sample>.peak_noise.loose.txt files")
    ap.add_argument("--out", default="plots/normalised_junction_rpm_histogram.pdf",
                    help="Output histogram path (PDF or PNG)")
    ap.add_argument("--thresholds",
                    default="signal_regions_inserts_per_sample.tsv",
                    help="TSV with per-sample threshold columns")
    args = ap.parse_args()

    bed_files = sorted(glob.glob(os.path.join(args.bed_dir, "*.junctions.bed")))
    if not bed_files:
        sys.exit(f"No .junctions.bed files found in {args.bed_dir}")

    all_opm = []
    skipped = []

    for bed_path in bed_files:
        sample = os.path.basename(bed_path).replace(".junctions.bed", "")
        stats_path = os.path.join(args.stats_dir, f"{sample}.peak_noise.loose.txt")
        if not os.path.exists(stats_path):
            skipped.append(sample)
            continue

        info = parse_peak_noise(stats_path)
        total_aligned = float(info["total_aligned_reads"])
        if total_aligned == 0:
            skipped.append(sample)
            continue

        raw_counts = parse_junctions(bed_path)
        opm = [c / total_aligned * 1e6 for c in raw_counts]
        all_opm.extend(opm)

    print(f"Samples processed : {len(bed_files) - len(skipped)}")
    print(f"Samples skipped   : {len(skipped)}")
    print(f"Total junctions   : {len(all_opm)}")

    arr = np.array(all_opm)
    print(f"OPM  min / median / mean / max : "
          f"{arr.min():.2f} / {np.median(arr):.2f} / {arr.mean():.2f} / {arr.max():.2f}")

    # ── threshold normalisation ────────────────────────────────────────
    thr = normalise_thresholds(args.thresholds, args.stats_dir)
    print(f"\nStringent threshold OPM  mean / median : "
          f"{thr['stringent_mean']:.2f} / {thr['stringent_median']:.2f}")
    print(f"Combined  threshold OPM  mean / median : "
          f"{thr['combined_mean']:.2f} / {thr['combined_median']:.2f}")

    # ── plotting ───────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Panel A – full distribution (log-scale x)
    ax = axes[0]
    log_rpm = np.log10(arr + 1)          # +1 to handle any zeros
    ax.hist(log_rpm, bins=100, color="steelblue", edgecolor="white", linewidth=0.3)
    ax.set_xlabel("log₁₀(OPM + 1)")
    ax.set_ylabel("Number of junctions")
    ax.set_title(f"A) All junctions (n = {len(arr):,})")
    # threshold lines (log-scaled to match x-axis)
    ax.axvline(np.log10(thr["stringent_mean"] + 1), color="red", ls="--", lw=1.5,
               label=f"Stringent mean = {thr['stringent_mean']:.0f} OPM")
    ax.axvline(np.log10(thr["combined_mean"] + 1), color="green", ls="-.", lw=1.5,
               label=f"Combined mean = {thr['combined_mean']:.0f} OPM")
    ax.legend(fontsize=8, loc="upper right")

    # Panel B – zoomed in: RPM ≤ 99th percentile
    ax = axes[1]
    p99 = np.percentile(arr, 99)
    subset = arr[arr <= p99]
    ax.hist(subset, bins=100, color="darkorange", edgecolor="white", linewidth=0.3)
    ax.set_xlabel("OPM (observations per million aligned reads)")
    ax.set_ylabel("Number of junctions")
    ax.set_title(f"B) Junctions with OPM ≤ {p99:.0f}  (99th pctl, n = {len(subset):,})")
    # threshold lines (linear scale)
    ax.axvline(thr["stringent_mean"], color="red", ls="--", lw=1.5,
               label=f"Stringent mean = {thr['stringent_mean']:.0f} OPM")
    ax.axvline(thr["combined_mean"], color="green", ls="-.", lw=1.5,
               label=f"Combined mean = {thr['combined_mean']:.0f} OPM")
    ax.legend(fontsize=8, loc="upper right")

    fig.suptitle("Junction observations per million aligned reads (loose filter)",
                 fontsize=13, fontweight="bold", y=1.01)
    fig.tight_layout()
    fig.savefig(args.out, dpi=200, bbox_inches="tight")
    print(f"\nHistogram saved → {args.out}")


if __name__ == "__main__":
    main()
