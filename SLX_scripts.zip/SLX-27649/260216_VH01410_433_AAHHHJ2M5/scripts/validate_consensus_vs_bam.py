#!/usr/bin/env python3
"""
Validate consensus FA junctions against the core BWA-aligned BAMs.

For each sample's consensus junctions, queries the aligned BAM at the
junction clip position (±100bp window) and counts:
  - total reads overlapping the window
  - soft-clipped reads (CIGAR contains S)
  - chimeric reads (SA:Z supplementary alignment tag)
  - reads with mate on SPLINK_INSERT_500bp

Compares chimeric count with consensus n_reads and reports pass/fail.
"""

import argparse
import os
import sys
import subprocess
import re
from collections import defaultdict
from pathlib import Path


def parse_consensus_bed(bed_path):
    """Parse consensus BED to get junction info."""
    junctions = []
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.strip().split("\t")
            if len(fields) < 5:
                continue
            chrom = fields[0]
            start = int(fields[1])
            jid = fields[3]
            n_reads = int(fields[4])
            clip_pos = start  # BED start is 0-based, clip_pos is at start
            junctions.append({
                "chrom": chrom,
                "clip_pos": clip_pos,
                "junction_id": jid,
                "n_reads": n_reads,
            })
    return junctions


def parse_consensus_fa(fa_path):
    """Parse consensus FA headers for n_reads and clip_pos."""
    junctions = []
    with open(fa_path) as f:
        for line in f:
            if not line.startswith(">"):
                continue
            header = line.strip()
            # Extract fields from header
            parts = header.split()
            jid = parts[0].lstrip(">")
            info = {}
            for p in parts[1:]:
                if "=" in p:
                    k, v = p.split("=", 1)
                    info[k] = v
                elif ":" in p and not p.startswith("chr"):
                    pass
                elif ":" in p:
                    info["locus"] = p

            # Get chrom and clip_pos from the locus field or junction_id
            locus = info.get("locus", "")
            clip_pos_str = info.get("clip_pos", "")

            if locus and ":" in locus:
                chrom, pos = locus.rsplit(":", 1)
                pos = int(pos)
            else:
                # Parse from junction_id like junction_1_chr2_4595476
                m = re.match(r"junction_\d+_(chr\w+)_(\d+)", jid)
                if m:
                    chrom = m.group(1)
                    pos = int(m.group(2))
                else:
                    continue

            clip_pos = int(clip_pos_str) if clip_pos_str else pos
            n_reads = int(info.get("n_reads", 0))
            n_consensus = int(info.get("n_consensus_reads", n_reads))

            junctions.append({
                "chrom": chrom,
                "clip_pos": clip_pos,
                "junction_id": jid,
                "n_reads": n_reads,
                "n_consensus_reads": n_consensus,
                "orientation": info.get("orientation", ""),
                "insert_side": info.get("insert_side", ""),
                "junction_offset": int(info.get("junction_offset", 0)),
            })
    return junctions


def index_bam(bam_path, samtools):
    """Index BAM if .bai doesn't exist."""
    bai = bam_path + ".bai"
    if not os.path.exists(bai):
        subprocess.run([samtools, "index", bam_path],
                       check=True, capture_output=True)


def query_bam_at_junction(bam_path, chrom, clip_pos, samtools, window=100):
    """Query BAM at junction position, return evidence counts."""
    region = f"{chrom}:{max(1, clip_pos - window)}-{clip_pos + window}"

    result = {
        "total_reads": 0,
        "soft_clipped": 0,
        "chimeric_sa": 0,
        "mate_on_insert": 0,
        "clipped_at_pos": 0,
    }

    try:
        proc = subprocess.run(
            [samtools, "view", bam_path, region],
            capture_output=True, text=True, check=True
        )
    except subprocess.CalledProcessError:
        return result

    for line in proc.stdout.strip().split("\n"):
        if not line:
            continue
        fields = line.split("\t")
        if len(fields) < 11:
            continue

        result["total_reads"] += 1
        cigar = fields[5]
        pos = int(fields[3])
        mate_ref = fields[6]

        # Soft-clipped?
        if "S" in cigar:
            result["soft_clipped"] += 1

            # Check if clip is at/near the junction position
            # Parse CIGAR to find clip boundaries
            cigar_ops = re.findall(r"(\d+)([MIDNSHP=X])", cigar)
            ref_pos = pos
            for length, op in cigar_ops:
                length = int(length)
                if op in ("M", "D", "N", "=", "X"):
                    ref_pos += length
            # Right clip end or left clip start near clip_pos
            if abs(pos - clip_pos) <= 5 or abs(ref_pos - clip_pos) <= 5:
                result["clipped_at_pos"] += 1

        # SA tag (chimeric)?
        if "SA:Z:" in line:
            result["chimeric_sa"] += 1

        # Mate on insert?
        if mate_ref == "SPLINK_INSERT_500bp" or mate_ref == "=":
            if mate_ref == "SPLINK_INSERT_500bp":
                result["mate_on_insert"] += 1

    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aligned-dir", required=True,
                        help="Directory with core BWA-aligned BAMs")
    parser.add_argument("--consensus-dir", required=True,
                        help="Directory with consensus FA and BED files")
    parser.add_argument("--samtools", default="samtools",
                        help="Path to samtools binary")
    parser.add_argument("--output", required=True,
                        help="Output TSV path")
    parser.add_argument("--window", type=int, default=100,
                        help="Window around junction to query (default: 100)")
    parser.add_argument("--tolerance", type=float, default=0.5,
                        help="Min ratio of BAM chimeric / consensus n_reads "
                             "to pass (default: 0.5)")
    parser.add_argument("--samples", nargs="*",
                        help="Specific samples to validate (default: all)")
    args = parser.parse_args()

    aligned_dir = Path(args.aligned_dir)
    consensus_dir = Path(args.consensus_dir)

    # Discover samples
    if args.samples:
        samples = args.samples
    else:
        samples = sorted(set(
            f.stem.replace(".consensus", "")
            for f in consensus_dir.glob("*.consensus.fa")
        ))

    print(f"Validating {len(samples)} samples...", file=sys.stderr)

    results = []
    pass_count = 0
    fail_count = 0
    skip_count = 0

    for i, sample in enumerate(samples):
        fa_path = consensus_dir / f"{sample}.consensus.fa"
        bed_path = consensus_dir / f"{sample}.junctions.bed"
        bam_path = aligned_dir / f"{sample}.r1.hg38.sort.bam"

        if not fa_path.exists():
            print(f"  [{i+1}/{len(samples)}] {sample}: no consensus FA, skip",
                  file=sys.stderr)
            skip_count += 1
            continue

        if not bam_path.exists():
            print(f"  [{i+1}/{len(samples)}] {sample}: no BAM, skip",
                  file=sys.stderr)
            skip_count += 1
            continue

        # Index BAM if needed
        index_bam(str(bam_path), args.samtools)

        # Parse consensus
        junctions = parse_consensus_fa(str(fa_path))

        if not junctions:
            # Empty consensus = no junctions, check BAM has no insert evidence
            results.append({
                "sample": sample,
                "n_junctions": 0,
                "junction_id": "none",
                "chrom": "-",
                "clip_pos": 0,
                "consensus_reads": 0,
                "bam_total": 0,
                "bam_clipped": 0,
                "bam_chimeric": 0,
                "bam_mate_insert": 0,
                "bam_clipped_at_pos": 0,
                "ratio": "-",
                "status": "PASS_EMPTY",
            })
            pass_count += 1
            continue

        sample_pass = True
        for junc in junctions:
            evidence = query_bam_at_junction(
                str(bam_path), junc["chrom"], junc["clip_pos"],
                args.samtools, args.window
            )

            consensus_reads = junc["n_reads"]
            chimeric = evidence["chimeric_sa"]

            if consensus_reads > 0:
                ratio = chimeric / consensus_reads
            else:
                ratio = 0.0

            status = "PASS" if ratio >= args.tolerance else "FAIL"
            if status == "FAIL":
                sample_pass = False

            results.append({
                "sample": sample,
                "n_junctions": len(junctions),
                "junction_id": junc["junction_id"],
                "chrom": junc["chrom"],
                "clip_pos": junc["clip_pos"],
                "consensus_reads": consensus_reads,
                "bam_total": evidence["total_reads"],
                "bam_clipped": evidence["soft_clipped"],
                "bam_chimeric": chimeric,
                "bam_mate_insert": evidence["mate_on_insert"],
                "bam_clipped_at_pos": evidence["clipped_at_pos"],
                "ratio": f"{ratio:.3f}",
                "status": status,
            })

        if sample_pass:
            pass_count += 1
        else:
            fail_count += 1

        if (i + 1) % 50 == 0:
            print(f"  [{i+1}/{len(samples)}] processed...", file=sys.stderr)

    # Write output
    header = [
        "sample", "n_junctions", "junction_id", "chrom", "clip_pos",
        "consensus_reads", "bam_total", "bam_clipped", "bam_chimeric",
        "bam_mate_insert", "bam_clipped_at_pos", "ratio", "status"
    ]

    with open(args.output, "w") as out:
        out.write("\t".join(header) + "\n")
        for r in results:
            out.write("\t".join(str(r[h]) for h in header) + "\n")

    # Summary
    total = pass_count + fail_count + skip_count
    print(f"\n{'='*60}", file=sys.stderr)
    print(f"VALIDATION SUMMARY", file=sys.stderr)
    print(f"{'='*60}", file=sys.stderr)
    print(f"Total samples:  {total}", file=sys.stderr)
    print(f"  PASS:         {pass_count}", file=sys.stderr)
    print(f"  FAIL:         {fail_count}", file=sys.stderr)
    print(f"  SKIP:         {skip_count}", file=sys.stderr)
    print(f"Total junctions validated: {len(results)}", file=sys.stderr)

    fail_juncs = [r for r in results if r["status"] == "FAIL"]
    if fail_juncs:
        print(f"\nFailed junctions ({len(fail_juncs)}):", file=sys.stderr)
        for r in fail_juncs[:20]:
            print(f"  {r['sample']} {r['junction_id']} "
                  f"consensus={r['consensus_reads']} "
                  f"bam_chimeric={r['bam_chimeric']} "
                  f"ratio={r['ratio']}", file=sys.stderr)
        if len(fail_juncs) > 20:
            print(f"  ... and {len(fail_juncs) - 20} more", file=sys.stderr)

    print(f"\nOutput written to: {args.output}", file=sys.stderr)


if __name__ == "__main__":
    main()
