#!/usr/bin/env python3
"""
Histograms of signal_regions counts extracted from peak_noise stats files.

Three plotting functions:
  1. plot_standard       – unit-width integer bins (stringent & combined)
  2. plot_binned         – custom grouped bins  0, 1-3, 4-6, 7-10, 10-15, 15+
                           (stringent & combined)
  3. plot_loose          – two panels for loose data:
                             a) custom bins  0, 1-5, 6-10, 11-50, 50+
                             b) standard integer-bin histogram

Usage:
    python scripts/histogram_signal_regions.py [--stats-dir stats] [--prefix signal_regions]
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_signal_regions(stats_dir: Path, glob_pattern: str) -> dict[str, int]:
    """Return {sample: signal_regions} for every file matching *glob_pattern*."""
    data = {}
    for f in sorted(stats_dir.glob(glob_pattern)):
        sample = None
        sr = None
        for line in f.read_text().splitlines():
            key, _, val = line.partition("\t")
            if key == "sample":
                sample = val
            elif key == "signal_regions":
                sr = int(val)
        if sample is not None and sr is not None:
            data[sample] = sr
    return data


def _assign_bin(value: int, edges: list[tuple[int, int | None]], labels: list[str]) -> str:
    """Map *value* into the first matching (lo, hi) range; hi=None means open."""
    for (lo, hi), lab in zip(edges, labels):
        if hi is None:
            if value >= lo:
                return lab
        elif lo <= value <= hi:
            return lab
    return labels[-1]


def _binned_bar(ax, values: list[int], edges, bin_labels, colour, label):
    """Draw a categorical bar chart of *values* grouped into *edges*."""
    counts = {lab: 0 for lab in bin_labels}
    for v in values:
        counts[_assign_bin(v, edges, bin_labels)] += 1
    heights = [counts[lab] for lab in bin_labels]
    bars = ax.bar(bin_labels, heights, color=colour, edgecolor="white",
                  linewidth=0.6, alpha=0.85, label=label)
    for bar, h in zip(bars, heights):
        if h > 0:
            ax.text(bar.get_x() + bar.get_width() / 2, h + 0.5, str(h),
                    ha="center", va="bottom", fontsize=8)


def _print_summary(label: str, values: list[int]):
    arr = np.array(values)
    print(f"  {label}: median={np.median(arr):.0f}  "
          f"mean={arr.mean():.1f}  min={arr.min()}  max={arr.max()}")


def _style_ax(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


# ---------------------------------------------------------------------------
# Plotting functions
# ---------------------------------------------------------------------------

COLOURS = {"stringent": "#4C72B0", "combined": "#DD8452", "loose": "#55A868"}

# Bin definitions
STRINGENT_COMBINED_EDGES = [(0, 0), (1, 3), (4, 6), (7, 10), (11, 15), (16, None)]
STRINGENT_COMBINED_LABELS = ["0", "1–3", "4–6", "7–10", "11–15", "15+"]

LOOSE_EDGES = [(0, 0), (1, 5), (6, 10), (11, 50), (51, None)]
LOOSE_LABELS = ["0", "1–5", "6–10", "11–50", "50+"]


def plot_standard(stats_dir: Path, out: str):
    """Standard integer-bin histogram for stringent & combined."""
    stringent = parse_signal_regions(stats_dir, "*.peak_noise.txt")
    combined = parse_signal_regions(stats_dir, "*.peak_noise.combined.txt")

    datasets, labels, colours = [], [], []
    if stringent:
        datasets.append(list(stringent.values()))
        labels.append(f"Stringent (n={len(stringent)})")
        colours.append(COLOURS["stringent"])
    if combined:
        datasets.append(list(combined.values()))
        labels.append(f"Combined (n={len(combined)})")
        colours.append(COLOURS["combined"])

    if not datasets:
        print("No stringent/combined peak_noise files found.")
        return

    all_vals = [v for ds in datasets for v in ds]
    lo, hi = min(all_vals), max(all_vals)
    bins = np.arange(lo - 0.5, hi + 1.5, 1)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(datasets, bins=bins, label=labels, color=colours,
            edgecolor="white", linewidth=0.5, alpha=0.85)
    ax.set_xlabel("Number of signal regions", fontsize=12)
    ax.set_ylabel("Number of samples", fontsize=12)
    ax.set_title("Signal regions per sample (stringent & combined)", fontsize=13)
    ax.legend(fontsize=10)
    xticks = np.arange(lo, hi + 1)
    if len(xticks) > 30:
        xticks = xticks[:: max(1, len(xticks) // 20)]
    ax.set_xticks(xticks)
    _style_ax(ax)
    fig.tight_layout()
    fig.savefig(out, dpi=200)
    print(f"Saved {out}")
    for lab, ds in zip(labels, datasets):
        _print_summary(lab, ds)


def plot_binned(stats_dir: Path, out: str):
    """Grouped-bin bar chart (0, 1-3, 4-6, 7-10, 11-15, 15+) for stringent & combined."""
    stringent = parse_signal_regions(stats_dir, "*.peak_noise.txt")
    combined = parse_signal_regions(stats_dir, "*.peak_noise.combined.txt")

    if not stringent and not combined:
        print("No stringent/combined peak_noise files found.")
        return

    n_panels = sum([bool(stringent), bool(combined)])
    fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 5), squeeze=False)
    axes = axes.flat
    idx = 0
    for data, name, colour in [
        (stringent, "stringent", COLOURS["stringent"]),
        (combined, "combined", COLOURS["combined"]),
    ]:
        if not data:
            continue
        ax = axes[idx]
        label = f"{name.capitalize()} (n={len(data)})"
        _binned_bar(ax, list(data.values()), STRINGENT_COMBINED_EDGES,
                    STRINGENT_COMBINED_LABELS, colour, label)
        ax.set_xlabel("Signal regions", fontsize=12)
        ax.set_ylabel("Number of samples", fontsize=12)
        ax.set_title(f"{name.capitalize()} – binned", fontsize=13)
        ax.legend(fontsize=10)
        _style_ax(ax)
        _print_summary(label, list(data.values()))
        idx += 1

    fig.tight_layout()
    fig.savefig(out, dpi=200)
    print(f"Saved {out}")


def _plate_number(sample: str) -> int | None:
    """Extract the leading plate digit from e.g. 'SPLINK_3A7' → 3."""
    # Sample names are SPLINK_<plate><well>, e.g. SPLINK_1A1, SPLINK_8A7
    import re
    m = re.search(r'SPLINK_(\d)', sample)
    return int(m.group(1)) if m else None


def _split_by_transposase(data: dict[str, int]) -> tuple[dict[str, int], dict[str, int]]:
    """Split sample dict into SB100X (plates 1-5) and SB200X (plates 6-8)."""
    sb100x, sb200x = {}, {}
    for sample, val in data.items():
        plate = _plate_number(sample)
        if plate is not None and 1 <= plate <= 5:
            sb100x[sample] = val
        elif plate is not None and 6 <= plate <= 8:
            sb200x[sample] = val
    return sb100x, sb200x


def plot_binned_by_transposase(stats_dir: Path, out: str):
    """Separate binned histograms for SB100X (plates 1-5) and SB200X (plates 6-8).

    Two rows × two columns:  stringent / combined  ×  SB100X / SB200X.
    Each panel shows the binned bar chart (0, 1-3, 4-6, 7-10, 11-15, 15+)
    with the mean insert count in the legend.
    """
    stringent = parse_signal_regions(stats_dir, "*.peak_noise.txt")
    combined  = parse_signal_regions(stats_dir, "*.peak_noise.combined.txt")

    if not stringent and not combined:
        print("No stringent/combined peak_noise files found.")
        return

    str_100, str_200 = _split_by_transposase(stringent)
    comb_100, comb_200 = _split_by_transposase(combined)

    fig, axes = plt.subplots(2, 2, figsize=(13, 10))

    panel_specs = [
        (axes[0, 0], str_100,  "Stringent – SB100X",  COLOURS["stringent"]),
        (axes[0, 1], str_200,  "Stringent – SB200X",  COLOURS["stringent"]),
        (axes[1, 0], comb_100, "Combined – SB100X",   COLOURS["combined"]),
        (axes[1, 1], comb_200, "Combined – SB200X",   COLOURS["combined"]),
    ]

    for ax, data, title, colour in panel_specs:
        vals = list(data.values())
        n = len(vals)
        if n == 0:
            ax.set_title(title)
            ax.text(0.5, 0.5, "no data", transform=ax.transAxes,
                    ha="center", va="center", fontsize=12, color="grey")
            continue
        avg = np.mean(vals)
        label = f"n={n}, mean={avg:.1f}"
        _binned_bar(ax, vals, STRINGENT_COMBINED_EDGES,
                    STRINGENT_COMBINED_LABELS, colour, label)
        ax.set_xlabel("Signal regions (inserts)", fontsize=11)
        ax.set_ylabel("Number of samples", fontsize=11)
        ax.set_title(title, fontsize=13)
        ax.legend(fontsize=10)
        _style_ax(ax)
        _print_summary(title, vals)

    fig.suptitle("Insert counts by transposase (plates 1-5 = SB100X, 6-8 = SB200X)",
                 fontsize=14, fontweight="bold", y=1.01)
    fig.tight_layout()
    fig.savefig(out, dpi=200, bbox_inches="tight")
    print(f"Saved {out}")


def transposase_summary_table(stats_dir: Path, out_tsv: str):
    """Write a TSV summarising insert counts for SB100X vs SB200X.

    Columns: Filter, Transposase, N_samples, Mean_inserts, Max_inserts, Total_inserts
    """
    stringent = parse_signal_regions(stats_dir, "*.peak_noise.txt")
    combined  = parse_signal_regions(stats_dir, "*.peak_noise.combined.txt")

    str_100, str_200 = _split_by_transposase(stringent)
    comb_100, comb_200 = _split_by_transposase(combined)

    header = ["Filter", "Transposase", "N_samples",
              "Mean_inserts", "Max_inserts", "Total_inserts"]

    def _row(filter_name: str, tx_name: str, data: dict[str, int]) -> list[str]:
        vals = list(data.values())
        if not vals:
            return [filter_name, tx_name, "0", "NA", "NA", "0"]
        arr = np.array(vals)
        return [
            filter_name, tx_name,
            str(len(vals)),
            f"{arr.mean():.2f}",
            str(arr.max()),
            str(arr.sum()),
        ]

    rows = [
        _row("Stringent", "SB100X", str_100),
        _row("Stringent", "SB200X", str_200),
        _row("Combined",  "SB100X", comb_100),
        _row("Combined",  "SB200X", comb_200),
    ]

    with open(out_tsv, "w") as fh:
        fh.write("\t".join(header) + "\n")
        for r in rows:
            fh.write("\t".join(r) + "\n")

    print(f"Saved {out_tsv}")
    # Also print to stdout
    col_w = [max(len(header[i]), max(len(r[i]) for r in rows)) + 2
             for i in range(len(header))]
    fmt = "".join(f"{{:<{w}}}" for w in col_w)
    print(fmt.format(*header))
    for r in rows:
        print(fmt.format(*r))


def plot_loose(stats_dir: Path, out: str):
    """Two-panel figure for loose data: (a) custom bins, (b) standard histogram."""
    loose = parse_signal_regions(stats_dir, "*.peak_noise.loose.txt")
    if not loose:
        print("No loose peak_noise files found.")
        return

    vals = list(loose.values())
    label = f"Loose (n={len(loose)})"
    colour = COLOURS["loose"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    # (a) Custom bins: 0, 1-5, 6-10, 11-50, 50+
    _binned_bar(ax1, vals, LOOSE_EDGES, LOOSE_LABELS, colour, label)
    ax1.set_xlabel("Signal regions", fontsize=12)
    ax1.set_ylabel("Number of samples", fontsize=12)
    ax1.set_title("Loose – binned", fontsize=13)
    ax1.legend(fontsize=10)
    _style_ax(ax1)

    # (b) Standard integer-bin histogram
    lo, hi = min(vals), max(vals)
    bins = np.arange(lo - 0.5, hi + 1.5, 1)
    ax2.hist(vals, bins=bins, color=colour, edgecolor="white",
             linewidth=0.5, alpha=0.85, label=label)
    ax2.set_xlabel("Number of signal regions", fontsize=12)
    ax2.set_ylabel("Number of samples", fontsize=12)
    ax2.set_title("Loose – standard histogram", fontsize=13)
    ax2.legend(fontsize=10)
    xticks = np.arange(lo, hi + 1)
    if len(xticks) > 30:
        xticks = xticks[:: max(1, len(xticks) // 20)]
    ax2.set_xticks(xticks)
    _style_ax(ax2)

    fig.tight_layout()
    fig.savefig(out, dpi=200)
    print(f"Saved {out}")
    _print_summary(label, vals)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_peak_noise_file(path: Path) -> dict[str, str]:
    """Parse a peak_noise file into a {key: value} dict (values as strings)."""
    data = {}
    for line in path.read_text().splitlines():
        key, _, val = line.partition("\t")
        data[key.strip()] = val.strip()
    return data


def insert_table(stats_dir: Path, out_tsv: str):
    """Write a TSV with per-sample insert counts and thresholds for all three filters."""
    # Gather data keyed by sample name
    rows: dict[str, dict] = {}

    for f in sorted(stats_dir.glob("*.peak_noise.txt")):
        d = _parse_peak_noise_file(f)
        sample = d.get("sample", "")
        if not sample:
            continue
        rows.setdefault(sample, {})
        rows[sample]["stringent_inserts"] = d.get("signal_regions", "")
        rows[sample]["stringent_threshold"] = d.get("peak_noise_depth", "")

    for f in sorted(stats_dir.glob("*.peak_noise.loose.txt")):
        d = _parse_peak_noise_file(f)
        sample = d.get("sample", "")
        if not sample:
            continue
        rows.setdefault(sample, {})
        rows[sample]["loose_inserts"] = d.get("signal_regions", "")
        rows[sample]["loose_threshold"] = d.get("loose_threshold", "")

    for f in sorted(stats_dir.glob("*.peak_noise.combined.txt")):
        d = _parse_peak_noise_file(f)
        sample = d.get("sample", "")
        if not sample:
            continue
        rows.setdefault(sample, {})
        rows[sample]["combined_inserts"] = d.get("signal_regions", "")
        # Combined uses OR logic: signal > 100x_avg OR signal > peak_noise.
        # The effective threshold is min(100x_avg, peak_noise).
        avg_thr = d.get("avg_threshold_100x", "")
        peak = d.get("peak_noise_depth", "")
        if avg_thr and peak:
            avg_val = float(avg_thr)
            peak_val = float(peak)
            eff_thr = min(avg_val, peak_val)
            rows[sample]["combined_threshold"] = str(int(eff_thr))
            rows[sample]["combined_threshold_source"] = (
                "100x avg" if avg_val <= peak_val else "peak noise"
            )
        else:
            rows[sample]["combined_threshold"] = avg_thr or peak or ""
            rows[sample]["combined_threshold_source"] = ""

    if not rows:
        print("No peak_noise files found — nothing to tabulate.")
        return

    header = [
        "Cell line",
        "Stringent insert number", "Stringent threshold (peak noise)",
        "Loose insert number",     "Loose threshold (2x avg)",
        "Combined insert number",  "Combined threshold (effective)",
        "Combined threshold source",
    ]

    with open(out_tsv, "w") as fh:
        fh.write("\t".join(header) + "\n")
        for sample in sorted(rows):
            r = rows[sample]
            fh.write("\t".join([
                sample,
                r.get("stringent_inserts", ""),
                r.get("stringent_threshold", ""),
                r.get("loose_inserts", ""),
                r.get("loose_threshold", ""),
                r.get("combined_inserts", ""),
                r.get("combined_threshold", ""),
                r.get("combined_threshold_source", ""),
            ]) + "\n")

    print(f"Saved {out_tsv}  ({len(rows)} samples)")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--stats-dir", default="stats",
        help="Directory containing peak_noise files (default: stats)",
    )
    parser.add_argument(
        "--prefix", default="signal_regions",
        help="Output filename prefix (default: signal_regions)",
    )
    args = parser.parse_args()

    stats_dir = Path(args.stats_dir)
    prefix = args.prefix

    print("=== Standard histogram (stringent & combined) ===")
    plot_standard(stats_dir, f"{prefix}_histogram.pdf")

    print("\n=== Binned histogram (stringent & combined) ===")
    plot_binned(stats_dir, f"{prefix}_binned.pdf")

    print("\n=== Binned histogram by transposase (SB100X vs SB200X) ===")
    plot_binned_by_transposase(stats_dir, f"{prefix}_binned_by_transposase.pdf")

    print("\n=== Transposase summary table ===")
    transposase_summary_table(stats_dir, f"{prefix}_transposase_summary.tsv")

    print("\n=== Loose histograms ===")
    plot_loose(stats_dir, f"{prefix}_loose.pdf")

    print("\n=== Insert count table ===")
    insert_table(stats_dir, f"{prefix}_inserts_per_sample.tsv")


if __name__ == "__main__":
    main()
