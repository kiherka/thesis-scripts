#!/usr/bin/env python3
"""
Create BED files marking the hg38 locations of splinkerette inserts.

For each SPLINK well with detected junctions, produces a BED file with a
±25 bp window around each insert site (the insert itself is not present in
the hg38 reference, so the window flanks the insertion point).

Also produces:
  - A merged BED of all unique insert locations across all wells
  - A bedGraph where the score = number of cell lines (wells) with an
    insert overlapping that position
Junction pairing logic mirrors splink_consensus.py integrate:
  - Two junctions on the same chrom within 10 kb are paired; the insert
    point is the midpoint of the gap between them.
  - A single (unpaired) junction places the insert at the midpoint of the
    junction region (start+end)//2.

Usage:
    python make_insert_location_beds.py <consensus_dir> <output_dir> <whitelist_bed>
"""

import argparse
import collections
import sys
from pathlib import Path


PAIR_MAX_DIST = 10000
FLANK = 25  # bp either side of insert site
MAX_SINGLE_BASE_FRAC = 0.80  # skip junction if any base > 80% of consensus


def load_whitelist(bed_path):
    """Load a whitelist BED into a dict of chrom -> sorted list of (start, end)."""
    regions = collections.defaultdict(list)
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.strip().split("\t")
            regions[fields[0]].append((int(fields[1]), int(fields[2])))
    for chrom in regions:
        regions[chrom].sort()
    return dict(regions)


def is_whitelisted(chrom, start, end, whitelist):
    """Check if a region overlaps any whitelist interval (binary search)."""
    import bisect
    intervals = whitelist.get(chrom, [])
    if not intervals:
        return False
    # Find rightmost interval whose start <= end
    idx = bisect.bisect_right([iv[0] for iv in intervals], end) - 1
    if idx < 0:
        return False
    # Check overlap: interval.end > start
    return intervals[idx][1] > start


def is_low_complexity(consensus_seq, threshold=MAX_SINGLE_BASE_FRAC):
    """Return True if any single base dominates the consensus sequence."""
    if not consensus_seq:
        return True
    seq = consensus_seq.upper().replace("N", "")
    if len(seq) == 0:
        return True
    counts = collections.Counter(seq)
    max_frac = counts.most_common(1)[0][1] / len(seq)
    return max_frac > threshold


def load_consensus_seqs(consensus_fa):
    """Load consensus FASTA into dict of junction_id -> sequence."""
    seqs = {}
    current_id = None
    current_seq = []
    with open(consensus_fa) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if current_id is not None:
                    seqs[current_id] = "".join(current_seq)
                # Header: >junction_1_chr2_32916429 chr2:...
                current_id = line[1:].split()[0]
                current_seq = []
            else:
                current_seq.append(line)
    if current_id is not None:
        seqs[current_id] = "".join(current_seq)
    return seqs


def parse_junction_bed(bed_path, whitelist, consensus_seqs):
    """Parse a junction BED file, filtering by whitelist and complexity.

    Returns list of dicts (only junctions that pass filters).
    """
    sites = []
    n_skipped_whitelist = 0
    n_skipped_complexity = 0
    with open(bed_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split("\t")
            chrom = fields[0]
            start = int(fields[1])
            end = int(fields[2])
            junction_id = fields[3]

            # Filter 1: must overlap whitelist
            if not is_whitelisted(chrom, start, end, whitelist):
                n_skipped_whitelist += 1
                continue

            # Filter 2: consensus must not be low-complexity
            if junction_id in consensus_seqs:
                if is_low_complexity(consensus_seqs[junction_id]):
                    n_skipped_complexity += 1
                    continue

            sites.append({
                "chrom": chrom,
                "start": start,
                "end": end,
                "junction_id": junction_id,
                "n_reads": int(fields[4]),
                "strand": fields[5],
                "consensus_len": int(fields[6]),
                "orientation": fields[7],
            })
    return sites, n_skipped_whitelist, n_skipped_complexity


def compute_insert_points(sites):
    """
    Given a list of junction sites for one well, compute the hg38
    insertion point(s) using the same pairing logic as integrate.
    Returns list of (chrom, insert_pos, junction_ids_str).
    """
    by_chrom = collections.defaultdict(list)
    for site in sites:
        by_chrom[site["chrom"]].append(site)

    insert_points = []
    for chrom in sorted(by_chrom.keys()):
        chrom_sites = sorted(by_chrom[chrom], key=lambda s: s["start"])
        i = 0
        while i < len(chrom_sites):
            site = chrom_sites[i]
            # Try to pair with next site
            if i + 1 < len(chrom_sites):
                next_site = chrom_sites[i + 1]
                gap = next_site["start"] - site["end"]
                if gap < PAIR_MAX_DIST:
                    # Paired: insert point = midpoint of gap
                    insert_pos = (site["end"] + next_site["start"]) // 2
                    ids = f"{site['junction_id']};{next_site['junction_id']}"
                    insert_points.append((chrom, insert_pos, ids))
                    i += 2
                    continue
            # Unpaired: insert at midpoint of junction region
            insert_pos = (site["start"] + site["end"]) // 2
            insert_points.append((chrom, insert_pos, site["junction_id"]))
            i += 1

    return insert_points


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("consensus_dir",
                        help="Directory containing SPLINK_*.junctions.bed files")
    parser.add_argument("output_dir",
                        help="Output directory for per-well BEDs and summary files")
    parser.add_argument("whitelist_bed",
                        help="Whitelist BED — only keep junctions overlapping these regions")
    args = parser.parse_args()

    consensus_dir = Path(args.consensus_dir)
    output_dir = Path(args.output_dir)

    # Load whitelist
    whitelist = load_whitelist(args.whitelist_bed)
    print(f"Loaded whitelist: {sum(len(v) for v in whitelist.values())} regions "
          f"across {len(whitelist)} chromosomes")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Find all junction BED files
    bed_files = sorted(consensus_dir.glob("SPLINK_*.junctions.bed"))
    if not bed_files:
        print(f"ERROR: No SPLINK_*.junctions.bed files found in {consensus_dir}",
              file=sys.stderr)
        sys.exit(1)

    print(f"Found {len(bed_files)} junction BED files in {consensus_dir}")

    # Track all insert positions across wells for summary
    # Key: (chrom, start, end) -> set of well names
    position_wells = collections.defaultdict(set)
    total_wells_with_inserts = 0
    total_insert_sites = 0
    total_skipped_wl = 0
    total_skipped_lc = 0

    for bed_file in bed_files:
        well = bed_file.stem.replace(".junctions", "")  # e.g. SPLINK_1A1

        # Load consensus sequences for this well (for complexity check)
        consensus_fa = bed_file.with_name(f"{well}.consensus.fa")
        consensus_seqs = load_consensus_seqs(consensus_fa) if consensus_fa.exists() else {}

        sites, n_skip_wl, n_skip_lc = parse_junction_bed(
            bed_file, whitelist, consensus_seqs)
        total_skipped_wl += n_skip_wl
        total_skipped_lc += n_skip_lc
        if not sites:
            continue

        insert_points = compute_insert_points(sites)
        if not insert_points:
            continue

        total_wells_with_inserts += 1

        # Write per-well BED
        out_bed = output_dir / f"{well}.insert_locations.bed"
        with open(out_bed, "w") as f:
            for chrom, pos, junc_ids in insert_points:
                start = max(0, pos - FLANK)
                end = pos + FLANK
                f.write(f"{chrom}\t{start}\t{end}\t{well}_{junc_ids}\t0\t.\n")
                position_wells[(chrom, start, end)].add(well)
                total_insert_sites += 1

        print(f"  {well}: {len(insert_points)} insert site(s) -> {out_bed.name}")

    print(f"\n{total_wells_with_inserts} wells with inserts, "
          f"{total_insert_sites} total insert sites")
    print(f"Filtered out: {total_skipped_wl} junctions outside whitelist, "
          f"{total_skipped_lc} low-complexity junctions")

    if not position_wells:
        print("No insert sites found across any wells. Exiting.")
        sys.exit(0)

    # --- Create merged summary ---
    # Sort positions for bedGraph
    sorted_positions = sorted(position_wells.keys())

    # Write summary BED (all unique locations, score = number of wells)
    summary_bed = output_dir / "all_insert_locations.bed"
    with open(summary_bed, "w") as f:
        for chrom, start, end in sorted_positions:
            wells = position_wells[(chrom, start, end)]
            well_names = ",".join(sorted(wells))
            f.write(f"{chrom}\t{start}\t{end}\t{well_names}\t{len(wells)}\t.\n")
    print(f"\nSummary BED: {summary_bed}")

    # Write bedGraph (value = number of cell lines / wells)
    summary_bg = output_dir / "insert_counts.bedGraph"
    with open(summary_bg, "w") as f:
        for chrom, start, end in sorted_positions:
            n_wells = len(position_wells[(chrom, start, end)])
            f.write(f"{chrom}\t{start}\t{end}\t{n_wells}\n")
    print(f"bedGraph:    {summary_bg}")

    # Print summary table
    print(f"\n{'='*60}")
    print(f"Insert location summary")
    print(f"{'='*60}")
    print(f"{'Position':<30} {'Wells':>6}  Cell lines")
    print(f"{'-'*30} {'-'*6}  {'-'*30}")
    for chrom, start, end in sorted_positions:
        wells = sorted(position_wells[(chrom, start, end)])
        pos_str = f"{chrom}:{start}-{end}"
        print(f"{pos_str:<30} {len(wells):>6}  {','.join(wells)}")


if __name__ == "__main__":
    main()
