#!/bin/bash
#SBATCH --job-name=junction_annot
#SBATCH --output=junction_annotation_%j.log
#SBATCH --error=junction_annotation_%j.err
#SBATCH --time=2:00:00
#SBATCH --mem=16G
#SBATCH --cpus-per-task=1

cd /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/scripts

echo "Starting junction annotation at $(date)"
echo "Job ID: $SLURM_JOB_ID"
echo "Running on: $(hostname)"

python junction_gencode_annotation_optimized.py

echo "Finished at $(date)"
