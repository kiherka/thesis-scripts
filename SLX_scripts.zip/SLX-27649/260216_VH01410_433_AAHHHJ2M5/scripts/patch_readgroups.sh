#!/bin/bash
# Patch existing aligned BAMs to add @RG headers (required by Picard MarkDuplicates).
# Uses samtools addreplacerg from the bwa_samtools conda env.
set -euo pipefail

WORKDIR="/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5"
ALIGNDIR="$WORKDIR/aligned"
SAMTOOLS="$WORKDIR/.snakemake/conda/8e1ce714a9d65306df93e06cdb61f89d_/bin/samtools"
LOGFILE="$WORKDIR/logs/patch_readgroups.log"

# Fallback: find samtools in any bwa_samtools env
if [[ ! -x "$SAMTOOLS" ]]; then
    SAMTOOLS=$(find "$WORKDIR/.snakemake/conda" -name samtools -path "*/bin/samtools" 2>/dev/null | head -1)
fi

if [[ ! -x "$SAMTOOLS" ]]; then
    echo "ERROR: samtools not found" | tee -a "$LOGFILE"
    exit 1
fi

echo "START $(date) - Using samtools: $SAMTOOLS" | tee "$LOGFILE"
echo "$($SAMTOOLS --version | head -1)" | tee -a "$LOGFILE"

TOTAL=0
PATCHED=0
SKIPPED=0
FAILED=0

for BAM in "$ALIGNDIR"/*.r1.hg38.sort.bam; do
    [[ -f "$BAM" ]] || continue
    TOTAL=$((TOTAL + 1))
    SAMPLE=$(basename "$BAM" .r1.hg38.sort.bam)

    # Check if @RG already exists
    if $SAMTOOLS view -H "$BAM" 2>/dev/null | grep -q "^@RG"; then
        echo "SKIP $SAMPLE (already has @RG)" | tee -a "$LOGFILE"
        SKIPPED=$((SKIPPED + 1))
        continue
    fi

    TMPBAM="${BAM}.rg_tmp.bam"
    echo "PATCHING $SAMPLE ..." | tee -a "$LOGFILE"

    if $SAMTOOLS addreplacerg \
        -r "ID:${SAMPLE}\tSM:${SAMPLE}\tPL:ILLUMINA\tLB:${SAMPLE}" \
        -o "$TMPBAM" "$BAM" 2>>"$LOGFILE"; then
        # Replace original
        mv "$TMPBAM" "$BAM"
        # Re-index if .bai exists
        if [[ -f "${BAM}.bai" ]]; then
            $SAMTOOLS index "$BAM"
        fi
        echo "  OK $SAMPLE" | tee -a "$LOGFILE"
        PATCHED=$((PATCHED + 1))
    else
        echo "  FAILED $SAMPLE" | tee -a "$LOGFILE"
        rm -f "$TMPBAM"
        FAILED=$((FAILED + 1))
    fi
done

echo "DONE $(date) - Total:$TOTAL Patched:$PATCHED Skipped:$SKIPPED Failed:$FAILED" | tee -a "$LOGFILE"
