import os
import glob
import pandas as pd
import pybedtools
import matplotlib.pyplot as plt

# Paths
bed_dir = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/consensus_loose/"
gtf_path = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/reference/gencode.v44.annotation.gtf"
out_table = "junction_annotation_table.tsv"
out_pie = "junction_annotation_piechart.png"

# Prepare GTF features as BED files
def gtf_to_bed(gtf, feature_type):
    bed = []
    with open(gtf) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.strip().split('\t')
            if fields[2] == feature_type:
                chrom = fields[0]
                start = int(fields[3]) - 1
                end = int(fields[4])
                bed.append(pybedtools.Interval(chrom, start, end, name=feature_type))
    return pybedtools.BedTool(bed)

# Prepare Gencode features
exons = gtf_to_bed(gtf_path, "exon")
cds = gtf_to_bed(gtf_path, "CDS")
utr5 = gtf_to_bed(gtf_path, "5UTR")
utr3 = gtf_to_bed(gtf_path, "3UTR")
genes = gtf_to_bed(gtf_path, "gene")

# Promoters: 2kb upstream of TSS
promoters = []
with open(gtf_path) as f:
    for line in f:
        if line.startswith("#"):
            continue
        fields = line.strip().split('\t')
        if fields[2] == "gene":
            chrom = fields[0]
            start = int(fields[3]) - 2001
            end = int(fields[3]) + 100
            if start < 0:
                start = 0
            promoters.append(pybedtools.Interval(chrom, start, end, name="promoter"))
promoters = pybedtools.BedTool(promoters)

# Helper to annotate a single site
def annotate_site(chrom, pos):
    site = pybedtools.BedTool(f"{chrom}\t{pos}\t{pos+1}\n", from_string=True)
    if site.intersect(exons, u=True):
        return "Exon"
    if site.intersect(cds, u=True):
        return "CDS"
    if site.intersect(utr5, u=True):
        return "5UTR"
    if site.intersect(utr3, u=True):
        return "3UTR"
    if site.intersect(promoters, u=True):
        return "Promoter"
    if site.intersect(genes, u=True):
        return "Intron"
    return "Intergenic"

# Build the annotation table
rows = []
for bedfile in glob.glob(os.path.join(bed_dir, "*.bed")):
    sample = os.path.basename(bedfile).split(".")[0]
    with open(bedfile) as f:
        for line in f:
            if line.startswith("#") or line.strip() == "":
                continue
            fields = line.strip().split()
            chrom = fields[0]
            # Use the midpoint of the junction region
            start = int(fields[1])
            end = int(fields[2])
            pos = (start + end) // 2
            annotation = annotate_site(chrom, pos)
            rows.append([sample, f"{chrom}:{pos}", annotation])

# Save table
df = pd.DataFrame(rows, columns=["Sample", "Genomic_location", "Site_type"])
df.to_csv(out_table, sep="\t", index=False)

# Pie chart
pie_counts = df["Site_type"].value_counts()
plt.figure(figsize=(7,7))
pie_counts.plot.pie(autopct='%1.1f%%', startangle=90, counterclock=False)
plt.ylabel("")
plt.title("Distribution of Insert Sites by Gencode Annotation")
plt.tight_layout()
plt.savefig(out_pie)
plt.close()
print(f"Annotation table: {out_table}")
print(f"Pie chart: {out_pie}")
