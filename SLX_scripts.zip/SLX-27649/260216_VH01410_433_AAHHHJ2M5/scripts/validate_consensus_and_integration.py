#!/usr/bin/env python3
"""
Validate consensus_combined junction calls and integrated genomes.

1. Clip-site validation: For each sample, extract chimeric read clip
   positions from the BAM and confirm the junction BED's modal clip_pos
   matches the true mode of raw clip positions within each cluster.

2. Integration validation: For each sample, verify the integrated genome
   contains the insert sequence at the expected location(s), flanked by
   the correct reference bases.

Usage:
    python validate_consensus_and_integration.py [--samples N] [--all]
"""

import argparse
import collections
import glob
import os
import sys

try:
    import pysam
except ImportError:
    sys.exit("pysam required")


INSERT_CONTIG = "SPLINK_INSERT_500bp"
MERGE_DIST = 500
WORKDIR = "/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5"
BAM_DIR = os.path.join(WORKDIR, "noDups")
BED_DIR = os.path.join(WORKDIR, "consensus_combined")
INTEGRATED_DIR = os.path.join(WORKDIR, "integrated_genomes_combined")
INSERT_FASTA = "/mnt/scratchc/sblab/herka01/herka01/reference/SPLINK_INSERT_500bp.fa"
REF_FASTA = "/mnt/scratchc/sblab/herka01/herka01/reference/reference_with_insert.fa"


def read_fasta_dict(path):
    seqs = {}
    name = None
    parts = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if name:
                    seqs[name] = "".join(parts)
                name = line[1:].split()[0]
                parts = []
            else:
                parts.append(line.upper())
    if name:
        seqs[name] = "".join(parts)
    return seqs


def reverse_complement(seq):
    comp = str.maketrans("ACGTacgt", "TGCAtgca")
    return seq.translate(comp)[::-1]


def parse_junction_bed(bed_path):
    sites = []
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            p = line.strip().split("\t")
            sites.append({
                "chrom": p[0],
                "clip_pos": int(p[8]) if len(p) > 8 else int(p[1]),
                "n_reads": int(p[4]),
                "orientation": p[7] if len(p) > 7 else "forward",
                "junction_id": p[3],
            })
    return sites


def get_raw_clip_positions(bam_path):
    """Extract all chimeric clip positions from BAM, grouped by chrom."""
    clips = collections.defaultdict(list)
    bam = pysam.AlignmentFile(bam_path, "rb")
    for read in bam.fetch(until_eof=True):
        if read.is_unmapped or not read.has_tag("SA"):
            continue
        if INSERT_CONTIG not in read.get_tag("SA"):
            continue
        rname = read.reference_name
        if rname == INSERT_CONTIG:
            continue
        ct = read.cigartuples
        if not ct:
            continue
        left_clip = ct[0][1] if ct[0][0] in (4, 5) else 0
        right_clip = ct[-1][1] if ct[-1][0] in (4, 5) else 0
        if left_clip > 0:
            clips[rname].append(read.reference_start)
        elif right_clip > 0:
            clips[rname].append(read.reference_end)
    bam.close()
    return clips


def cluster_positions(positions, merge_dist=MERGE_DIST):
    """Cluster sorted positions within merge_dist."""
    if not positions:
        return []
    positions = sorted(positions)
    clusters = [[positions[0]]]
    for p in positions[1:]:
        if p - clusters[-1][-1] <= merge_dist:
            clusters[-1].append(p)
        else:
            clusters.append([p])
    return clusters


def validate_clip_sites(sample):
    """Validate that BED clip_pos matches the true modal clip from BAM."""
    bam_path = os.path.join(BAM_DIR,
                            f"{sample}.insertJunctions.noiseFiltered.combined.bam")
    bed_path = os.path.join(BED_DIR, f"{sample}.junctions.bed")

    if not os.path.exists(bam_path) or not os.path.exists(bed_path):
        return None, f"  SKIP: missing files"

    bed_sites = parse_junction_bed(bed_path)
    if not bed_sites:
        return True, f"  No junctions — nothing to validate"

    raw_clips = get_raw_clip_positions(bam_path)

    # Cluster raw clips per chrom, find mode per cluster
    raw_clusters = {}  # (chrom, modal_pos) -> Counter
    for chrom in raw_clips:
        clusters = cluster_positions(raw_clips[chrom])
        for cluster in clusters:
            counter = collections.Counter(cluster)
            modal = counter.most_common(1)[0][0]
            raw_clusters[(chrom, modal)] = counter

    results = []
    all_ok = True
    for site in bed_sites:
        chrom = site["chrom"]
        bed_clip = site["clip_pos"]
        n_reads = site["n_reads"]

        # Find the matching raw cluster
        matched = None
        for (rc, rm), counter in raw_clusters.items():
            if rc == chrom and abs(rm - bed_clip) <= MERGE_DIST:
                matched = (rc, rm, counter)
                break

        if matched is None:
            results.append(f"  ✗ {site['junction_id']} {chrom}:{bed_clip} "
                           f"(n={n_reads}) — NO matching raw cluster found!")
            all_ok = False
            continue

        rc, raw_modal, counter = matched
        total_raw = sum(counter.values())

        if bed_clip == raw_modal:
            results.append(f"  ✓ {site['junction_id']} {chrom}:{bed_clip} "
                           f"bed_reads={n_reads} raw_reads={total_raw} "
                           f"modal_match=EXACT "
                           f"(mode has {counter[raw_modal]} reads, "
                           f"{len(counter)} distinct positions)")
        else:
            # Check if it's close
            diff = abs(bed_clip - raw_modal)
            results.append(f"  ✗ {site['junction_id']} {chrom}:{bed_clip} "
                           f"bed_reads={n_reads} raw_reads={total_raw} "
                           f"modal_match=MISMATCH (raw mode={raw_modal}, "
                           f"off by {diff}bp, "
                           f"raw mode has {counter[raw_modal]} reads, "
                           f"bed pos has {counter.get(bed_clip, 0)} reads)")
            all_ok = False

    return all_ok, "\n".join(results)


def validate_integrated_genome(sample, insert_seq, ref_seqs):
    """Validate insert is correctly spliced into the integrated genome."""
    bed_path = os.path.join(BED_DIR, f"{sample}.junctions.bed")
    genome_path = os.path.join(INTEGRATED_DIR, f"{sample}.integrated.fa")

    if not os.path.exists(genome_path) or not os.path.exists(bed_path):
        return None, f"  SKIP: missing files"

    bed_sites = parse_junction_bed(bed_path)
    if not bed_sites:
        return True, f"  No junctions — genome should equal reference"

    int_seqs = read_fasta_dict(genome_path)

    results = []
    all_ok = True

    # Check insert contig is removed
    if INSERT_CONTIG in int_seqs:
        results.append(f"  ✗ INSERT contig {INSERT_CONTIG} still present!")
        all_ok = False
    else:
        results.append(f"  ✓ INSERT contig removed from integrated genome")

    # Check genome size is reference + (n_inserts * insert_len) - deletions
    ref_size = sum(len(s) for n, s in ref_seqs.items() if n != INSERT_CONTIG)
    int_size = sum(len(s) for s in int_seqs.values())
    insert_len = len(insert_seq)

    # Group sites by chrom to detect paired junctions
    by_chrom = collections.defaultdict(list)
    for s in bed_sites:
        by_chrom[s["chrom"]].append(s)

    n_insertions = 0
    total_deleted = 0
    for chrom in by_chrom:
        sites = sorted(by_chrom[chrom], key=lambda x: x["clip_pos"])
        i = 0
        while i < len(sites):
            if i + 1 < len(sites):
                gap = sites[i + 1]["clip_pos"] - sites[i]["clip_pos"]
                if gap < 10000:
                    total_deleted += gap
                    n_insertions += 1
                    i += 2
                    continue
            n_insertions += 1
            i += 1

    expected_size = ref_size + (n_insertions * insert_len) - total_deleted
    size_diff = int_size - expected_size
    if abs(size_diff) <= 10:
        results.append(f"  ✓ Genome size: {int_size:,} bp "
                       f"(expected ~{expected_size:,}, diff={size_diff})")
    else:
        results.append(f"  ✗ Genome size: {int_size:,} bp "
                       f"(expected ~{expected_size:,}, diff={size_diff})")
        all_ok = False

    # For each junction, verify the insert sequence appears in the
    # integrated genome at the right location
    for site in bed_sites:
        chrom = site["chrom"]
        clip = site["clip_pos"]
        orientation = site["orientation"]

        if chrom not in int_seqs:
            results.append(f"  ✗ {site['junction_id']}: chrom {chrom} "
                           f"not found in integrated genome")
            all_ok = False
            continue

        seq = int_seqs[chrom]
        ins = insert_seq if orientation == "forward" else reverse_complement(insert_seq)
        ins_snippet = ins[:50]  # first 50bp of insert

        # Search for insert snippet near the expected location.
        # Coordinates shift with each prior insertion on the same chrom,
        # so widen the window by n_prior_inserts * insert_len.
        n_prior = sum(1 for s in bed_sites
                       if s["chrom"] == chrom and s["clip_pos"] < clip)
        max_shift = (n_prior + 1) * insert_len + 1000
        search_start = max(0, clip - 2 * insert_len)
        search_end = min(len(seq), clip + max_shift)
        region = seq[search_start:search_end]

        if ins_snippet in region:
            pos_in_region = region.index(ins_snippet)
            abs_pos = search_start + pos_in_region
            results.append(f"  ✓ {site['junction_id']} {chrom}:{clip} "
                           f"insert found at genome pos {abs_pos} "
                           f"(orientation={orientation})")
        else:
            # Try shorter snippet
            short = ins[:30]
            if short in region:
                pos_in_region = region.index(short)
                abs_pos = search_start + pos_in_region
                results.append(f"  ~ {site['junction_id']} {chrom}:{clip} "
                               f"partial insert match (30bp) at pos {abs_pos}")
            else:
                results.append(f"  ✗ {site['junction_id']} {chrom}:{clip} "
                               f"insert NOT FOUND near expected location!")
                all_ok = False

    # Verify reference flanks are intact
    for site in bed_sites:
        chrom = site["chrom"]
        clip = site["clip_pos"]
        if chrom not in ref_seqs or chrom not in int_seqs:
            continue
        # Check 100bp upstream of the junction in both ref and integrated
        ref_flank = ref_seqs[chrom][max(0, clip - 100):clip]
        # Find this flank in the integrated genome
        if ref_flank in int_seqs[chrom]:
            results.append(f"  ✓ {site['junction_id']} upstream 100bp "
                           f"reference flank preserved")
        else:
            # Might be shifted by prior insertions on same chrom
            results.append(f"  ~ {site['junction_id']} upstream flank shifted "
                           f"(expected if multiple insertions on same chrom)")

    return all_ok, "\n".join(results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=10,
                        help="Number of samples to validate (default: 10)")
    parser.add_argument("--all", action="store_true",
                        help="Validate all samples")
    parser.add_argument("--sample", type=str, default=None,
                        help="Validate a specific sample")
    args = parser.parse_args()

    # Get sample list
    beds = sorted(glob.glob(os.path.join(BED_DIR, "*.junctions.bed")))
    samples = [os.path.basename(b).replace(".junctions.bed", "") for b in beds]

    if args.sample:
        samples = [args.sample]
    elif not args.all:
        # Pick a mix: some with many junctions, some with few
        samples = samples[:args.samples]

    print(f"Validating {len(samples)} samples...")
    print(f"Loading insert sequence: {INSERT_FASTA}")
    insert_seqs = read_fasta_dict(INSERT_FASTA)
    insert_name = list(insert_seqs.keys())[0]
    insert_seq = insert_seqs[insert_name]
    print(f"  Insert: {insert_name} ({len(insert_seq)} bp)")

    print(f"Loading reference: {REF_FASTA}")
    ref_seqs = read_fasta_dict(REF_FASTA)
    print(f"  {len(ref_seqs)} contigs")

    clip_pass = 0
    clip_fail = 0
    int_pass = 0
    int_fail = 0
    clip_skip = 0
    int_skip = 0

    for i, sample in enumerate(samples, 1):
        print(f"\n{'='*60}")
        print(f"[{i}/{len(samples)}] {sample}")
        print(f"{'='*60}")

        # 1. Clip-site validation
        print(f"\n--- Clip-site validation ---")
        ok, detail = validate_clip_sites(sample)
        print(detail)
        if ok is None:
            clip_skip += 1
        elif ok:
            clip_pass += 1
        else:
            clip_fail += 1

        # 2. Integration validation
        print(f"\n--- Integration validation ---")
        ok, detail = validate_integrated_genome(sample, insert_seq, ref_seqs)
        print(detail)
        if ok is None:
            int_skip += 1
        elif ok:
            int_pass += 1
        else:
            int_fail += 1

    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    print(f"Clip-site:   {clip_pass} pass, {clip_fail} fail, {clip_skip} skip")
    print(f"Integration: {int_pass} pass, {int_fail} fail, {int_skip} skip")

    if clip_fail > 0 or int_fail > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
