#!/bin/bash
# Run the Snakemake master on the submit/login node (inside tmux/screen)
# so that localrules can access /mnt/nas-data.
#
# Usage:  tmux new -s smk
#         bash run_master.sh          # runs in foreground
#         # Ctrl-b d  to detach       # re-attach: tmux attach -t smk
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5

LOG=logs/slurm/smk_master_local_$(date +%Y%m%d_%H%M%S).log
echo "Logging to $LOG"

snakemake --profile profile --jobs 200 2>&1 | tee "$LOG"
