# Splinkerette PCR Insert Detection: Approach Comparison

## Context
For amplicon sequencing of splinkerette PCR inserts, each paired-end read pair contains:
- **One read**: insert sequence + partial genomic context
- **Other read**: genomic context + potential junction + possible insert portion

**Key Properties of This Insert:**
- **Length**: 500 bp (substantial, well above typical error detection thresholds)
- **Sequence**: Identical in all samples (no expected variation)
- **Implication**: High specificity for insert detection; optimal for targeted analysis

This analysis compares three computational approaches for identifying and analyzing these inserts, with special consideration for the 500 bp fixed-sequence nature of this insert.

---

## Approach 1: Extra Contig Method
*Create an extra contig (the insert) in the reference genome, align all reads to whole genome + contig; look solely for split reads*

### Advantages ✓
- **Explicit junction identification**: Split reads spanning insert ↔ genome boundary become directly observable in alignments
- **Comprehensive**: Captures all possible insert integration patterns and configurations
- **Clear validation**: Can verify insert presence through read pairs that map to both insert contig and genome
- **Quantifiable**: Easy to count reads supporting each insert-genome junction
- **Handles multiple insertions**: Can distinguish between different insert copies if using multiple contigs
- **Quality control**: Misaligned or chimeric reads are obvious from split mapping patterns
- **⭐ 500bp length advantage**: Long enough for reliable split-read mapping; not so long as to complicate reference
- **⭐ Fixed sequence advantage**: No sequence variation means contig approach is inherently stable; no need for updates

### Disadvantages ✗
- **Complex reference preparation**: Requires custom reference genome construction
- **Index complexity**: Larger reference genome with modified index files (mitigated: only one extra 500bp contig)
- **Repetitive sequence issues**: *Reduced concern* - only problematic if 500bp insert has internal repeats or genome homology
- **Computational overhead**: *Reduced concern* - adding single 500bp contig has minimal impact on index size
- **Tools complexity**: Split-read detection requires specialized bioinformatic tools (e.g., LUMPY, Manta, custom scripts)
- **Overkill for simple confirmation**: More complex than needed if only goal is to detect insert presence
- **Less convenient for routine analysis**: Not ideal if just need fast, reproducible quantification

---

## Approach 2: Trim-and-Filter Method
*Trim the insert sequence, align the rest to human reference genome; keep only reads containing the insert*

### Advantages ✓
- **Simple workflow**: Standard trimming (cutadapt-compatible) + normal alignment + basic filtering
- **Focused analysis**: Only processes reads containing the known insert - reduces noise
- **Lower computational cost**: Smaller alignment indexes; faster processing
- **Tool agnostic**: Uses standard bioinformatics tools (cutadapt, bwa, samtools)
- **⭐ 500bp length advantage**: Long enough for very reliable k-mer/sequence matching with zero false negatives
- **⭐ Fixed sequence advantage**: Identical sequence means single, deterministic filter works for all samples
- **Reproducible**: Straightforward, deterministic approach that's easy to document and reproduce
- **No reference modification**: Uses standard reference genome without customization
- **Fast filtering**: String matching/k-mer based filtering is computationally efficient
- **⭐ Best for routine use**: Perfect for production pipelines requiring consistent, repeatable results

### Disadvantages ✗
- **Information loss**: Removes insert sequence - cannot map insert-to-insert or analyze insert internal structure
- **Requires known insert sequence**: Must know exact insert sequence beforehand (✓ you have it)
- **Short insert risk**: *Not applicable* - 500bp is well above minimum threshold
- **Junction information lost**: Cannot directly assess insert-genome junction sequences
- **False negatives**: *Minimized* - 500bp fixed sequence is distinctive; variant/degraded sequences would be intentionally excluded
- **Limited quantification**: Cannot distinguish junction locations, only confirm insert presence
- **Indirect validation**: Cannot independently verify junction breakpoints without contig approach
- **Assumes single insert orientation**: If insert integrates in different orientations, need to account for complement

---

## Approach 3: Unusual Insert Detection Method
*Align to reference genome; look for anomalous or unexpected insert sequences*

### Advantages ✓
- **No a priori knowledge**: Can identify unexpected insertions without knowing insert sequence in advance
- **Standard reference**: Uses unmodified reference genome
- **Flexible**: Can detect various types of insertions and genomic anomalies
- **Integration with existing tools**: Compatible with standard structural variant calling pipelines (LUMPY, DELLY, Manta)

### Disadvantages ✗
- **Unnecessary for known inserts**: Since your insert is well-characterized, this approach adds complexity without benefit
- **High false positive rate**: Distinguishing real inserts from sequencing errors is difficult
- **Lack of specificity**: Does not leverage your known 500bp insert; generates noisy results
- **Poor performance for 500bp inserts**: SV tools are optimized for larger insertions; 500bp is marginal for most detectors
- **Requires anomaly detection**: Need specialized algorithms (coverage changes, breakpoint detection, read orientation)
- **Parameter tuning**: Thresholds for "unusual" are hard to set and dataset-dependent
- **Computationally expensive**: Structural variant calling is resource-intensive
- **Difficult validation**: Hard to validate findings without independent experimental confirmation
- **Integration site ambiguity**: Multiple possible breakpoints may appear equally likely
- **Batch effects**: Results can vary significantly between runs and sequencing depths
- **⭐ Overkill**: Not recommended for this well-defined, fixed-sequence insert

---

## Comparison Matrix

| Criterion | Approach 1: Contig | Approach 2: Trim-Filter | Approach 3: Anomaly |
|-----------|-------------------|------------------------|-------------------|
| **Complexity** | Medium | Low | High |
| **Specificity** | Very High | Very High | Low |
| **Sensitivity** | Very High | Very High | Low-Medium |
| **Speed** | Medium | Fast | Very Slow |
| **Prior Knowledge Required** | Insert sequence ✓ | Insert sequence ✓ | None |
| **False Positive Rate** | Very Low | Very Low | Very High |
| **False Negative Rate** | Very Low | Very Low | High |
| **Junction Detection** | Excellent | Poor | Fair |
| **Junction Precision** | Very High | N/A | Low |
| **Suited for 500bp Fixed Insert** | ✓ Excellent | ✓✓ Excellent | ✗ Not suitable |
| **Reproducibility** | Very High | Very High | Medium |

---

## Recommendations by Use Case

### For Your 500bp Fixed-Sequence Insert:

#### ⭐ **RECOMMENDED PRIMARY: Approach 2 (Trim-Filter)**
**When to use:**
- For **routine quantification and confirmation** of insert presence ← **Your primary use case**
- When you need **fast, reproducible pipeline results**
- For **batch processing** of multiple samples
- When you only need to know **which samples contain the insert**
- For **publication-ready quantification** (high confidence)

**Why it's optimal for your insert:**
- 500bp is long enough for zero false negatives in sequence matching
- Fixed sequence means single filter works for all samples
- Fast enough for routine laboratory use
- Results are deterministic and reproducible

#### **RECOMMENDED SECONDARY: Approach 1 (Contig)**
**When to use:**
- For **detailed structural analysis** of selected samples
- When you need to **map exact genomic integration sites**
- For **publications requiring junction validation**
- To **characterize multiple insertions** or rearrangements
- For **quality control** of unusual samples

**Why it's valuable as secondary approach:**
- Provides precise junction coordinates
- Confirms insert integrity through split-reads
- Manageable complexity: only adding one 500bp contig
- Validates findings from Approach 2

#### **NOT RECOMMENDED: Approach 3 (Anomaly)**
**Why skip it for your insert:**
- You have a well-characterized insert - no discovery needed
- 500bp is suboptimal for most SV tools (designed for larger events)
- False positive rate is too high for this defined sequence
- Would waste computational resources on irrelevant signals
- Does not improve upon Approaches 1 and 2

---

## Recommended Hybrid Approach

**For your 500bp fixed-sequence splinkerette PCR analysis:**

### Tier 1: Primary Production Workflow (Approach 2 - Trim-Filter)
**For all samples:**
- Trim reads containing the 500bp insert sequence using cutadapt
- Align trimmed reads to human reference genome (hg38)
- Filter for uniquely mapped reads (MAPQ ≥ 10)
- **Output**: Genomic coordinates of insert-containing sequences
- **Quantification**: Count of reads containing insert per sample
- **Time**: ~2-5 minutes per sample
- **Confidence**: Very High (>99% specificity for 500bp sequence)

### Tier 2: Validation Workflow (Approach 1 - Contig) *Optional*
**For selected samples or when precision is critical:**
1. Create reference genome with 500bp insert as extra contig
2. Align all reads to reference_genome_plus_insert.fa
3. Extract split-reads (reads mapping to both insert and genome)
4. Map split-reads to precise genomic coordinates
5. **Output**: Exact insert-genome junction breakpoints
6. **Benefit**: Confirms insert integrity and integration sites
7. **Time**: ~15-30 minutes per sample (one-time reference prep)

### Tier 3: Quality Control (Approach 1 adapted)
**For anomaly detection without Approach 3:**
- Use Approach 1 results to identify unusual patterns:
  - Single-read insertions (degraded insert?)
  - Multiple junctions (rearrangement?)
  - Unexpected read orientations (chimeric?)
- Much more reliable than generic SV calling for this known sequence

---

## Implementation Notes

### Approach 1: Practical Considerations & Tools

#### Reference Preparation
- Create augmented reference: Append 500bp insert as separate contig to hg38
  ```bash
  cat hg38.fa insert_500bp.fa > hg38_with_insert.fa
  ```
- Build BWA index: `bwa index hg38_with_insert.fa`
- Index file management can be cumbersome in automated pipelines

#### Standard BWA MEM Pipeline - What Works & What Doesn't
**✓ Can do:**
- Align reads to augmented reference with standard BWA MEM:
  ```bash
  bwa mem hg38_with_insert.fa read1.fq read2.fq | samtools sort -o aligned.bam
  ```
- SAM/BAM output contains chimeric alignments (SA tag) for reads mapping to multiple regions
- Works well for the 500bp insert case

**✗ Limitations of standard pipeline alone:**
- BWA MEM produces `SA` (supplementary alignment) tags for split reads, but requires post-processing
- Simply grepping for SA tags won't reliably identify insert-genome junctions
- Need to parse CIGAR strings and identify which alignments span insert ↔ genome boundary

#### Recommended Tool Combinations

**Option A: Samblaster (Recommended for this use case)**
```bash
bwa mem hg38_with_insert.fa read1.fq read2.fq \
  | samblaster --addMateTags \
  | samtools sort -o aligned.bam
samblaster -i aligned.bam -o alignedSplits.bam -s alignedSplits.sam
```
- **Pros**: Simple, fast, designed for exactly this (extracting split-reads from BWA output)
- **Cons**: Requires separate installation/compilation
- **For 500bp insert**: Perfect; identifies reads mapping to both insert and genome

**Option B: Custom Python/Bash Script (Lightweight)**
```python
# Parse BAM, extract reads with SA tags mapping to both:
#   - Insert contig (chrI or similar name)
#   - Genome chromosome (chr1-22, chrX, chrY)
# Output junction coordinates
```
- **Pros**: Full control, minimal dependencies, can be tailored to your exact needs
- **Cons**: Requires development/testing, maintenance burden
- **For 500bp insert**: Very feasible; straightforward logic

**Option C: Structural Variant Tools (Overkill but functional)**
- **LUMPY**: Probabilistic detection, designed for larger SVs
  - Too sensitive to noise for 500bp inserts
  - Over-parameterized for this use case
  
- **DELLY**: Structural variant caller
  - Can detect insertions but requires careful tuning
  - Better for discovering unknown SVs, not validating known inserts
  
- **Manta**: Industry standard SV caller
  - Most powerful but heaviest weight
  - Optimized for clinical/large-scale SV discovery
  - Overkill for 500bp known insert detection

**Option D: HTSlib + samtools (Minimal approach)**
```bash
# Extract supplementary alignments
samtools view -h -F 2048 aligned.bam | \
  awk '$0 ~ /SA:Z:/' > split_reads.sam

# Parse SA tags to identify insert-genome junctions
# (requires custom parsing logic)
```
- **Pros**: Uses standard Unix tools, no external dependencies beyond samtools
- **Cons**: Requires robust SA tag parsing

#### Recommended Strategy for Your 500bp Insert

**Use: BWA MEM + Samblaster + Custom Junction Parser**

1. **Alignment**:
   ```bash
   bwa mem -t 8 hg38_with_insert.fa R1.fq.gz R2.fq.gz | \
     samblaster --addMateTags | samtools sort -o reads.bam
   ```

2. **Extract split-reads**:
   ```bash
   samtools view -h reads.bam | samblaster -s splitsOnly.bam
   ```

3. **Map junctions** (custom script):
   - Parse split-reads where one segment maps to insert contig
   - Other segment maps to genome chromosome
   - Extract breakpoint coordinates

**Why this combination:**
- BWA MEM is standard, fast, reliable
- Samblaster is lightweight and specifically designed for this task
- Custom parsing is simple for a known 500bp insert
- Total time: ~15-30 min depending on read depth

#### For 500bp Insert: Feasibility Assessment

| Tool Combination | Feasibility | Complexity | Recommended |
|------------------|-------------|-----------|-------------|
| **BWA MEM alone** | Low | N/A | ❌ Requires post-processing |
| **BWA MEM + Samblaster** | High | Low | ✅ **Best choice** |
| **BWA MEM + Custom Python** | High | Medium | ✓ Alternative if Samblaster unavailable |
| **LUMPY** | Medium | High | ⚠️ Overkill, over-sensitive |
| **DELLY** | Medium | High | ⚠️ Overkill, designed for discovery |
| **Manta** | Medium | Very High | ❌ Overkill, production SV caller |
| **HTSlib parsing** | High | High | ⚠️ Minimal but requires robust parsing |

**Bottom line**: Standard BWA MEM pipeline requires supplemental split-read detection. **Samblaster is the ideal companion tool** for this 500bp insert use case.

### Approach 2: Practical Considerations
- Insert trimming pattern: `cutadapt -a EXACT_500BP_INSERT_SEQUENCE ...`
- Filtering: `samtools view -F 4` (keep mapped) + custom filter for insert presence
- Can use k-mer matching (jellyfish, BBtools) for more sensitive insert detection
- **For 500bp insert**: Highly specific; single pattern sufficient

### Approach 3: Practical Considerations
- Requires structural variant calling tools (DELLY, LUMPY, Manta)
- Needs careful parameter tuning per sequencing technology
- High depth required; marginal for clinical use
- **For 500bp insert**: Not recommended - tools are suboptimal for this size

---

## Conclusion

Given that your insert is **500 bp long and identical in every sample**, the analysis strongly favors a **two-tier approach**:

### ✅ **Tier 1 - Primary (Approach 2)**: Trim-and-Filter
- **For all samples and routine analysis**
- Provides fast, reproducible, high-confidence detection
- Perfect fit: 500bp is ideal length for sequence matching
- Fixed sequence eliminates need for updating or multiple patterns
- Recommended for production pipelines

### ✅ **Tier 2 - Validation (Approach 1)**: Contig with Split-Reads
- **For selected samples, publications, or structural analysis**
- Adds modest complexity given just one 500bp contig
- Provides precise junction mapping
- Validates Tier 1 findings with full structural information

### ❌ **Approach 3 (Anomaly)**: Not Recommended
- Unnecessary given your well-characterized insert
- Suboptimal for 500bp insertions
- Would produce noisy, difficult-to-interpret results
- Skip this approach entirely

**For your splinkerette PCR pipeline: Start with Approach 2, supplement with Approach 1 as needed.**
