#!/usr/bin/env python3
"""
Plot mean bigwig trace (CPM) for each ATRX cell line vs WT mean,
in a 2000 bp window centred at the peak start site.

Two bigwig naming conventions are both present in this folder and are
combined as replicates of the same cell line:
  {cell_line}_{rep}_ATRX.r1.trimmed.hg38.sort.sortName.cpm.bs10.bw
  ATRX_{cell_line}_{rep}.r1.hg38.sort..s600.cpm.bs3.bw

Cell lines: WT, 14, 17, 25, 26.

One subplot per (non-WT) cell line, each showing:
  • Mean CPM trace for that cell line (coloured)
  • Mean CPM trace across ALL WT replicates (grey, dashed) as reference
  • Shaded ±SEM for both

Outputs (cpm_analysis/mean_traces/):
  mean_traces_ATRX.pdf
  mean_traces_data.tsv
"""

import re
import glob
import math
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import pyBigWig
from scipy import stats

# ── Plot styling: Helvetica Neue Light everywhere; save PDF + SVG ────────────
def _register_helvetica_neue_light():
    """Extract & register the true 'Helvetica Neue Light' face from the
    system Helvetica Neue TrueType Collection (matplotlib otherwise only
    ever sees face index 0 of a .ttc, which is Regular). Falls back
    silently if the system font or fontTools is unavailable."""
    import matplotlib.font_manager as fm
    cache_path = os.path.expanduser("~/.cache/matplotlib_fonts/HelveticaNeueLight.ttf")
    if not os.path.exists(cache_path):
        ttc_path = "/System/Library/Fonts/HelveticaNeue.ttc"
        if not os.path.exists(ttc_path):
            return
        try:
            from fontTools.ttLib import TTCollection
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            for font in TTCollection(ttc_path).fonts:
                if font["name"].getDebugName(2) == "Light":
                    font.save(cache_path)
                    break
        except Exception:
            return
    if os.path.exists(cache_path):
        fm.fontManager.addfont(cache_path)

_register_helvetica_neue_light()

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"]
plt.rcParams["font.weight"] = "light"
plt.rcParams["axes.labelweight"] = "light"
plt.rcParams["axes.titleweight"] = "light"
plt.rcParams["figure.titleweight"] = "light"

def save_fig(fig, out_base, **kwargs):
    """Save a figure as both PDF and SVG (out_base without extension)."""
    save_kwargs = dict(bbox_inches="tight", dpi=150)
    save_kwargs.update(kwargs)
    for ext in (".pdf", ".svg"):
        fig.savefig(f"{out_base}{ext}", **save_kwargs)

# ── Region ────────────────────────────────────────────────────────────────────
TARGET_CHR  = "chr16"
PEAK_START  = 113670          # window is centred here
WINDOW_HALF = 1000            # ±1000 bp → 2000 bp total
WIN_START   = PEAK_START - WINDOW_HALF
WIN_END     = PEAK_START + WINDOW_HALF
BIN_SIZE    = 10              # bp per bin (200 bins across 2000 bp)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BIGWIG_DIR  = SCRIPT_DIR
OUT_DIR     = os.path.join(SCRIPT_DIR, "cpm_analysis", "mean_traces")

CELL_LINE_ORDER = ["WT", "14", "17", "25", "26"]

os.makedirs(OUT_DIR, exist_ok=True)

# ── Sample parsing ─────────────────────────────────────────────────────────────
def parse_sample(path):
    """
    Recognise either of the two bigwig naming conventions in this folder
    and return dict with cell_line, replicate, batch (bs10 / bs3).
    """
    fname = os.path.basename(path)

    # ATRX_{cell_line}_{rep}.r1.hg38.sort..s600.cpm.bs3.bw
    m = re.match(r'^ATRX_(WT|\d+)_([A-Za-z0-9]+)\.r1\.hg38\.sort\.\.s600\.cpm\.bs3\.bw$', fname)
    if m:
        cell_line, rep = m.group(1), m.group(2)
        return dict(stem=fname, cell_line=cell_line, replicate=rep, batch="bs3")

    # {cell_line}_{rep}_ATRX.r1.trimmed.hg38.sort.sortName.cpm.bs10.bw
    m = re.match(r'^(WT|\d+)_([A-Za-z0-9]+)_ATRX\.r1\.trimmed\.hg38\.sort\.sortName\.cpm\.bs10\.bw$', fname)
    if m:
        cell_line, rep = m.group(1), m.group(2)
        return dict(stem=fname, cell_line=cell_line, replicate=rep, batch="bs10")

    return None

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "*.bw")))
records = []
for path in bw_files:
    info = parse_sample(path)
    if info:
        info["path"] = path
        records.append(info)
    else:
        print(f"  Skipping unrecognised file: {os.path.basename(path)}")

meta = pd.DataFrame(records)
meta["cell_line"] = pd.Categorical(meta["cell_line"], categories=CELL_LINE_ORDER, ordered=True)
meta = meta.sort_values(["cell_line", "batch", "replicate"]).reset_index(drop=True)
print(f"{len(meta)} samples found")
print(meta.groupby("cell_line", observed=True).size().to_string())

# ── Bin positions (x axis, centred at PEAK_START) ─────────────────────────────
bins      = np.arange(WIN_START, WIN_END, BIN_SIZE)
x_rel     = bins - PEAK_START   # offset from peak start (−1000 … +990)
n_bins    = len(bins)

# ── Extract per-replicate traces ───────────────────────────────────────────────
print(f"Extracting traces in {WIN_START}–{WIN_END} ({n_bins} bins × {BIN_SIZE} bp) …")

def fetch_trace(path):
    bw = pyBigWig.open(path)
    sig = []
    for b in bins:
        try:
            v = bw.stats(TARGET_CHR, int(b), int(b + BIN_SIZE), type="mean", exact=True)[0]
        except RuntimeError:
            v = None
        sig.append(float(v) if v is not None else 0.0)
    bw.close()
    return np.array(sig)

traces = {}
for _, row in meta.iterrows():
    traces[row["stem"]] = fetch_trace(row["path"])
    print(f"  {row['stem']}")

# ── Colour palette by cell line ───────────────────────────────────────────────
cell_lines_present = [c for c in CELL_LINE_ORDER if c in meta["cell_line"].unique()]
tab20 = list(cm.tab20.colors)
cat_colors = {c: tab20[i % 20] for i, c in enumerate(cell_lines_present)}

# ── Helper: mean ± SEM across a set of stems ──────────────────────────────────
def mean_sem(stems):
    mat = np.stack([traces[s] for s in stems])
    m   = mat.mean(axis=0)
    s   = mat.std(axis=0, ddof=1) / np.sqrt(mat.shape[0]) if mat.shape[0] > 1 else np.zeros(n_bins)
    return m, s

# ── WT mean (all WT replicates) ────────────────────────────────────────────────
def wt_stems():
    return meta[meta["cell_line"] == "WT"]["stem"].tolist()

# ── Grid layout helper ─────────────────────────────────────────────────────────
def grid_dims(n, max_cols=4):
    ncols = min(n, max_cols)
    nrows = math.ceil(n / ncols)
    return nrows, ncols

# ── Plot one cell line per subplot (vs WT) ────────────────────────────────────
def plot_traces(out_base):
    cls   = [c for c in cell_lines_present if c != "WT"]
    wt_st = wt_stems()
    wt_m, wt_s = mean_sem(wt_st) if wt_st else (np.zeros(n_bins), np.zeros(n_bins))

    nrows, ncols = grid_dims(len(cls), max_cols=4)
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=(ncols * 3.8, nrows * 3.0),
                             constrained_layout=True)
    axes_flat = np.array(axes).flatten() if len(cls) > 1 else [axes]

    for ax_idx, cl in enumerate(cls):
        ax    = axes_flat[ax_idx]
        rows  = meta[meta["cell_line"] == cl]
        col   = cat_colors[cl]
        stems = rows["stem"].tolist()

        cl_m, cl_s = mean_sem(stems)

        # WT background
        if wt_st:
            ax.fill_between(x_rel, wt_m - wt_s, wt_m + wt_s,
                            color="grey", alpha=0.25, linewidth=0)
            ax.plot(x_rel, wt_m, color="grey", lw=1.0,
                    linestyle="--", label=f"WT mean (n={len(wt_st)})")

        # Cell line trace
        ax.fill_between(x_rel, cl_m - cl_s, cl_m + cl_s,
                        color=col, alpha=0.3, linewidth=0)
        ax.plot(x_rel, cl_m, color=col, lw=1.5,
                label=f"{cl} (n={len(stems)})")

        # Peak marker
        ax.axvline(0, color="red", lw=0.8, linestyle=":", alpha=0.7)

        ax.set_title(cl, fontsize=8)
        ax.set_xlabel("Offset from peak start (bp)", fontsize=6)
        ax.set_ylabel("CPM", fontsize=6)
        ax.tick_params(labelsize=5)
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(fontsize=5, loc="upper right", framealpha=0.6)

    for ax_idx in range(len(cls), len(axes_flat)):
        axes_flat[ax_idx].set_visible(False)

    fig.suptitle(
        f"ATRX — Mean CPM trace per cell line\n"
        f"2000 bp window centred at peak start ({TARGET_CHR}:{PEAK_START:,})  |  "
        f"Shading = ±SEM  |  Dashed grey = WT mean ± SEM",
        fontsize=8,
    )
    save_fig(fig, out_base)
    plt.close(fig)
    print(f"Saved {out_base}.pdf / .svg")

# ── Generate plot ───────────────────────────────────────────────────────────────
plot_traces(os.path.join(OUT_DIR, "mean_traces_ATRX"))

# ── Save trace data ────────────────────────────────────────────────────────────
rows_out = []
for stem, tr in traces.items():
    row = meta[meta["stem"] == stem].iloc[0]
    r = {"stem": stem, "cell_line": row["cell_line"],
         "replicate": row["replicate"], "batch": row["batch"]}
    for i, v in enumerate(tr):
        r[f"bin_{bins[i]}"] = v
    rows_out.append(r)
pd.DataFrame(rows_out).to_csv(
    os.path.join(OUT_DIR, "mean_traces_data.tsv"), sep="\t", index=False
)
print(f"Saved mean_traces_data.tsv")
print("Done.")

