#!/usr/bin/env python3
"""Filter a LUMPY VCF for structural variants involving the insert contig.

Keeps any record where:
  - CHROM == insert_contig, OR
  - the ALT field references insert_contig (BND bracket notation)

Usage:
    python filter_insert_svs.py <input.vcf> <insert_contig> <output.vcf>
"""

import sys


def main():
    if len(sys.argv) != 4:
        print(f"Usage: {sys.argv[0]} <input.vcf> <insert_contig> <output.vcf>",
              file=sys.stderr)
        sys.exit(1)

    input_vcf, insert_contig, output_vcf = sys.argv[1:4]

    n_total = 0
    n_insert = 0

    with open(input_vcf) as fin, open(output_vcf, "w") as fout:
        for line in fin:
            # Pass through header lines
            if line.startswith("#"):
                fout.write(line)
                continue

            n_total += 1
            fields = line.split("\t", 8)  # only need first 8 columns
            chrom = fields[0]
            alt = fields[4]

            # Variant sits ON the insert contig, or
            # BND ALT references the insert contig (e.g. N]SPLINK_INSERT_500bp:200])
            if chrom == insert_contig or insert_contig in alt:
                n_insert += 1
                fout.write(line)

    print(f"Total SVs: {n_total}")
    print(f"Insert-related SVs: {n_insert}")


if __name__ == "__main__":
    main()
