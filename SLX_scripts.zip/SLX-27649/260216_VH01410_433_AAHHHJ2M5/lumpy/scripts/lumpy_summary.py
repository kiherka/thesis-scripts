#!/usr/bin/env python3
"""Aggregate LUMPY insert-related SV calls across SPLINK samples.

For each sample, counts total insert-related SVs and BND events,
and lists the top genomic breakpoints with their supporting evidence.

Usage:
    python lumpy_summary.py <insert_contig> <output.tsv> <vcf1> [vcf2 ...]
"""

import os
import re
import sys


def parse_vcf(vcf_path, insert_contig):
    """Parse a filtered VCF and extract insert-related SV events."""
    events = []
    with open(vcf_path) as f:
        for line in f:
            if line.startswith("#"):
                continue
            fields = line.strip().split("\t")
            if len(fields) < 8:
                continue

            chrom = fields[0]
            pos = int(fields[1])
            sv_id = fields[2]
            alt = fields[4]
            qual = fields[5]
            info = fields[7]

            # Parse SV type and evidence counts from INFO
            svtype = _info_val(info, "SVTYPE", "UNKNOWN")
            su = int(_info_val(info, "SU", "0"))
            pe = int(_info_val(info, "PE", "0"))
            sr = int(_info_val(info, "SR", "0"))

            # For BNDs, parse partner location from ALT bracket notation
            partner_chrom = ""
            partner_pos = ""
            if svtype == "BND":
                m = re.search(r'[\[\]](\S+?):(\d+)[\[\]]', alt)
                if m:
                    partner_chrom, partner_pos = m.group(1), m.group(2)

            # Normalise so genome_chrom/genome_pos is the non-insert side
            if chrom == insert_contig:
                genome_chrom = partner_chrom
                genome_pos = partner_pos
                insert_pos = str(pos)
            else:
                genome_chrom = chrom
                genome_pos = str(pos)
                insert_pos = (partner_pos
                              if partner_chrom == insert_contig else "")

            events.append({
                "genome_chrom": genome_chrom,
                "genome_pos": genome_pos,
                "insert_pos": insert_pos,
                "svtype": svtype,
                "qual": qual,
                "su": su,
                "pe": pe,
                "sr": sr,
                "sv_id": sv_id,
            })

    return events


def _info_val(info, key, default=""):
    """Extract a value from a VCF INFO field by key."""
    m = re.search(rf'{key}=([^;\s]+)', info)
    return m.group(1) if m else default


def main():
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <insert_contig> <output.tsv> <vcf> ...",
              file=sys.stderr)
        sys.exit(1)

    insert_contig = sys.argv[1]
    output_tsv = sys.argv[2]
    vcf_files = sys.argv[3:]

    with open(output_tsv, "w") as out:
        out.write("sample\tn_insert_svs\tn_bnd\tn_other\ttop_sites\n")

        for vcf_path in sorted(vcf_files):
            sample = os.path.basename(vcf_path).replace(".insert_svs.vcf", "")
            events = parse_vcf(vcf_path, insert_contig)

            n_total = len(events)
            n_bnd = sum(1 for e in events if e["svtype"] == "BND")
            n_other = n_total - n_bnd

            # Top BND sites sorted by total support (descending)
            bnd_events = [e for e in events
                          if e["svtype"] == "BND"
                          and e["genome_chrom"]
                          and e["genome_pos"]]
            bnd_events.sort(key=lambda e: e["su"], reverse=True)

            top = [f"{e['genome_chrom']}:{e['genome_pos']}(SU={e['su']})"
                   for e in bnd_events[:10]]
            top_sites = ";".join(top) if top else "none"

            out.write(f"{sample}\t{n_total}\t{n_bnd}\t{n_other}\t{top_sites}\n")

    print(f"Summary written to {output_tsv}")
    print(f"Processed {len(vcf_files)} samples")


if __name__ == "__main__":
    main()
