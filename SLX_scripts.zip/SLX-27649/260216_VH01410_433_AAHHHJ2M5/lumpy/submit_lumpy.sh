#!/bin/bash
#SBATCH --partition=epyc
#SBATCH --job-name=lmp_master
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=72:00:00
#SBATCH --output=logs/slurm/lumpy_master_%j.out
#SBATCH --error=logs/slurm/lumpy_master_%j.err
#
# Submit the LUMPY Snakemake master as a SLURM job.
#
# Usage:  sbatch submit_lumpy.sh
#
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/lumpy

mkdir -p logs/slurm

echo "LUMPY Snakemake master started at $(date)"
echo "SLURM job ID: $SLURM_JOB_ID"
echo "Node: $(hostname)"

snakemake --profile profile --jobs 200

echo "LUMPY Snakemake master finished at $(date)"
