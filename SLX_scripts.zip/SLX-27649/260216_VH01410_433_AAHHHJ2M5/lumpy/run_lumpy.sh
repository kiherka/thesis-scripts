#!/bin/bash
# Run the LUMPY pipeline master on the submit/login node (inside screen).
#
# Usage:  screen -S lumpy
#         bash run_lumpy.sh          # runs in foreground
#         # Ctrl-a d  to detach     # re-attach: screen -r lumpy
set -euo pipefail

eval "$(conda shell.bash hook 2>/dev/null)"
conda activate snakemake

cd /mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/lumpy

mkdir -p logs/slurm

LOG=logs/slurm/lumpy_master_$(date +%Y%m%d_%H%M%S).log
echo "Logging to $LOG"

snakemake --profile profile --jobs 200 2>&1 | tee "$LOG"
