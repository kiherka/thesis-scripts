#!/bin/bash
# Copy all 679 combined integrated genomes + BWA indexes to NAS
# Run from submit node (which has NAS access)
set -euo pipefail

SRC=/mnt/scratchc/sblab/herka01/SLX-27649/260216_VH01410_433_AAHHHJ2M5/integrated_genomes_combined
DST=/mnt/nas-data/sblab/group_folders/herka01/ENS_whole_genome_references_combined

mkdir -p "$DST"

total=0
failed=0
for fa in "$SRC"/*.integrated.fa; do
    sample=$(basename "$fa" .integrated.fa)
    # Check all 6 files exist (fa + 5 bwa index files)
    ok=true
    for ext in "" .amb .ann .bwt .pac .sa; do
        if [[ ! -f "${fa}${ext}" ]]; then
            echo "MISSING: ${fa}${ext}"
            ok=false
        fi
    done
    if $ok; then
        for ext in "" .amb .ann .bwt .pac .sa; do
            cp "${fa}${ext}" "${DST}/$(basename ${fa}${ext})"
        done
        total=$((total + 1))
        if (( total % 50 == 0 )); then
            echo "  Copied $total samples..."
        fi
    else
        failed=$((failed + 1))
    fi
done

echo "Done: $total samples copied, $failed failed"
echo "Files on NAS:"
ls "$DST"/*.fa 2>/dev/null | wc -l
