#!/usr/bin/env python3
"""
Analyse smoothened (bs3) CPM bigwig files for BG4 CUT&Tag, local reproduction
of analyse_cpm_v2.py for the expEN7 dataset.

Scope of this script (differs from analyse_cpm_v2.py):
  - Only BG4 samples are analysed (CUTAC/H3K27ac/IgG tracks in this folder
    are ignored).
  - Only the *.smoothened.cpm.bs3.bw files are used (raw + bs10 tracks are
    ignored).
  - Sample names follow the local naming scheme:
        BG4_<CATEGORY>-<CLONE>_<BIOREP>_<TECHREP>.r1...smoothened.cpm.bs3.bw
    e.g. BG4_G3T1-1_B1_T1...  ->  category=G3T1, clone=1, biorep=B1, techrep=T1
    Edit categories: WT, G3T1, G3T4, G3T1F.
    "-1"/"-2"/... identify the clonal cell line within a category.
    B1/B2/B3 = biological replicates. T1/T2 = technical replicates
    (sequencing/mapping repeats of the same biological replicate) and are
    averaged together before any biological-replicate-level analysis.
  - There are no per-sample dedup-read logs available locally, so the
    ">=1,000,000 dedup reads" QC filter from analyse_cpm_v2.py is not
    applied here.
  - The hard-coded BG4_EXCLUDED_STEMS list from analyse_cpm_v2.py was
    specific to a different sequencing run (SLX-27925, KH-* clones) and is
    not relevant to this dataset. Instead, entire clonal cell lines
    G3T1-3 and G3T1F-3 are excluded (per user instruction) and recorded in
    excluded_cell_lines.tsv.

Insert/test site: chrX:71,530,537-71,530,555 (G4 promoter insertion site).
The test-locus CPM window is a region flanking the insert site sized to
exactly match the reference locus size (1,000 bp), so that target and
reference CPM values are computed over equally sized windows.

Both the normalised CPM (target/reference) and the raw CPM (target alone,
reference alone) are plotted at the cell-line and edit-category level.
"""

import re
import glob
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pyBigWig
from scipy import stats
from statsmodels.stats.multitest import multipletests
from itertools import combinations

# ── Regions ───────────────────────────────────────────────────────────────────
TARGET_CHR = "chrX"
PEAK_START = 71_530_537
PEAK_END   = 71_530_555

# Reference (normalisation) locus - unchanged from analyse_cpm_v2.py
REF_CHR   = "chr12"
REF_START = 25_250_600
REF_END   = 25_251_600
REF_SIZE  = REF_END - REF_START

# Test-locus window: flank the insert site so the resulting window is
# exactly REF_SIZE bp wide (same size as the reference locus), instead of a
# fixed ±500 bp flank, so target and reference CPM are directly comparable.
PEAK_LEN     = PEAK_END - PEAK_START
FLANK        = (REF_SIZE - PEAK_LEN) // 2
TARGET_START = PEAK_START - FLANK
TARGET_END   = TARGET_START + REF_SIZE

WINDOWS = {
    "target_matched": (TARGET_START, TARGET_END),
    "10kb":           (PEAK_START - 10000, PEAK_END + 10000),
}

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BIGWIG_DIR = os.path.dirname(SCRIPT_DIR)          # parent "bigwigs" folder
OUT_DIR    = SCRIPT_DIR
BIN_SIZE   = 25

os.makedirs(OUT_DIR, exist_ok=True)

# ── Cell lines excluded wholesale (per user instruction) ──────────────────────
EXCLUDED_CELL_LINES = {"G3T1-3", "G3T1F-3"}

# ── Sample parsing ─────────────────────────────────────────────────────────────
SAMPLE_RE = re.compile(r'^(BG4)_([A-Za-z0-9]+-\d+)_(B\d+)_(T\d+)\.r1')

def parse_sample(filename):
    m = SAMPLE_RE.match(filename)
    if not m:
        return None
    assay, clone, biorep, techrep = m.groups()
    edit_category = re.sub(r'-\d+$', '', clone)
    return dict(assay=assay, clone=clone, edit_category=edit_category,
                biorep=biorep, techrep=techrep)

bw_files = sorted(glob.glob(os.path.join(BIGWIG_DIR, "BG4_*.smoothened.cpm.bs3.bw")))
records = []
for path in bw_files:
    fname = os.path.basename(path)
    info = parse_sample(fname)
    if info:
        info["path"] = path
        info["file_stem"] = fname
        records.append(info)

meta_files = pd.DataFrame(records)
print(f"Found {len(meta_files)} BG4 smoothened bs3 files")

# ── Apply cell-line exclusions ────────────────────────────────────────────────
excl_mask = meta_files["clone"].isin(EXCLUDED_CELL_LINES)
excl_df = meta_files[excl_mask].copy()
excl_df.to_csv(os.path.join(OUT_DIR, "excluded_cell_lines.tsv"), sep="\t", index=False)

meta_files = meta_files[~excl_mask].copy()
print(f"Excluded {len(excl_df)} files belonging to cell line(s): "
      f"{sorted(EXCLUDED_CELL_LINES)}")
print(f"{len(meta_files)} files retained for analysis")

# ── Helper ─────────────────────────────────────────────────────────────────────
def fetch_mean(bw, chrom, start, end):
    try:
        val = bw.stats(chrom, start, end, type="mean", exact=True)[0]
        return float(val) if val is not None else 0.0
    except RuntimeError:
        return 0.0

# ── Extract CPM per file (technical-replicate level) ──────────────────────────
print("\nExtracting CPM values …")
track_bins = {win: np.arange(s, e, BIN_SIZE) for win, (s, e) in WINDOWS.items()}

target_cpms, ref_cpms = [], []
file_track_data = {win: {} for win in WINDOWS}

for _, row in meta_files.iterrows():
    bw = pyBigWig.open(row["path"])
    for win, bins in track_bins.items():
        sig = [fetch_mean(bw, TARGET_CHR, int(b), int(b + BIN_SIZE)) for b in bins]
        file_track_data[win][row["file_stem"]] = np.array(sig)
    target_cpms.append(fetch_mean(bw, TARGET_CHR, TARGET_START, TARGET_END))
    ref_cpms.append(fetch_mean(bw, REF_CHR, REF_START, REF_END))
    bw.close()

meta_files["target_cpm"] = target_cpms
meta_files["ref_cpm"]    = ref_cpms
meta_files["norm_cpm"]   = meta_files.apply(
    lambda r: r["target_cpm"] / r["ref_cpm"] if r["ref_cpm"] > 0 else np.nan, axis=1
)
meta_files.to_csv(os.path.join(OUT_DIR, "per_file_cpm.tsv"), sep="\t", index=False)
print("Saved per_file_cpm.tsv (technical-replicate level)")

# ── Average technical replicates -> biological-replicate level ───────────────
print("\nAveraging technical replicates (T1/T2) per biological replicate …")

meta = (
    meta_files.groupby(["assay", "clone", "edit_category", "biorep"])
    .agg(target_cpm=("target_cpm", "mean"),
         ref_cpm=("ref_cpm", "mean"),
         norm_cpm=("norm_cpm", "mean"),
         n_techreps=("techrep", "count"))
    .reset_index()
)
meta["cell_line"] = "BG4_" + meta["clone"]
meta["stem"] = meta["assay"] + "_" + meta["clone"] + "_" + meta["biorep"]
meta.to_csv(os.path.join(OUT_DIR, "per_sample_cpm.tsv"), sep="\t", index=False)
print("Saved per_sample_cpm.tsv (biological-replicate level)")
print(f"\n{len(meta)} biological replicates retained")
print(meta.groupby("edit_category").size().to_string())

# Average the track signal across technical replicates per biorep
track_data = {win: {} for win in WINDOWS}
for win in WINDOWS:
    for _, row in meta.iterrows():
        sub = meta_files[(meta_files["clone"] == row["clone"]) &
                         (meta_files["biorep"] == row["biorep"])]
        sigs = [file_track_data[win][fs] for fs in sub["file_stem"]]
        track_data[win][row["stem"]] = np.mean(sigs, axis=0)

# ── Colour palette ─────────────────────────────────────────────────────────────
def make_palette(keys):
    n = len(keys)
    colors = sns.color_palette("tab20", n) if n <= 20 else sns.color_palette("husl", n)
    return dict(zip(sorted(keys), colors))

edit_cats = sorted(meta["edit_category"].unique())
cat_palette = make_palette(edit_cats)

# ── 1. Track plots ─────────────────────────────────────────────────────────────
print("\nPlotting CPM tracks …")

sub = meta.sort_values("cell_line")
n_samples = len(sub)

for win_label, (win_start, win_end) in WINDOWS.items():
    bins = track_bins[win_label]
    x = bins - win_start
    peak_rel_s = PEAK_START - win_start
    peak_rel_e = PEAK_END   - win_start

    all_vals = np.concatenate([track_data[win_label][r["stem"]]
                               for _, r in sub.iterrows()])
    ymax = np.nanpercentile(all_vals, 99) * 1.15
    ymax = max(ymax, 0.01)

    fig, axes = plt.subplots(
        n_samples, 1,
        figsize=(14, max(4, 0.38 * n_samples + 1.5)),
        sharex=True, sharey=False,
        gridspec_kw={"hspace": 0.05}
    )
    if n_samples == 1:
        axes = [axes]

    for ax, (_, row) in zip(axes, sub.iterrows()):
        sig = track_data[win_label][row["stem"]]
        color = cat_palette[row["edit_category"]]
        ax.fill_between(x, sig, alpha=0.85, color=color, linewidth=0)
        ax.axvspan(peak_rel_s, peak_rel_e, color="red", alpha=0.15, linewidth=0)
        ax.set_ylim(0, ymax)
        ax.set_ylabel(f"{row['cell_line']}_{row['biorep']}", fontsize=4.5,
                      rotation=0, ha="right", va="center", labelpad=2)
        ax.set_yticks([round(ymax, 2)])
        ax.set_yticklabels([f"{ymax:.2f}"], fontsize=3.5)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(left=False)

    axes[-1].set_xlabel(f"{TARGET_CHR} offset from window start (bp)")
    wlen = win_end - win_start
    fig.suptitle(
        f"BG4: CPM signal – {win_label} window  "
        f"({TARGET_CHR}:{win_start:,}–{win_end:,}, {wlen:,} bp)\n"
        f"Red band = insert/test site ({TARGET_CHR}:{PEAK_START:,}–{PEAK_END:,})  |  "
        f"All tracks: same Y scale (max = {ymax:.2f} CPM)\n"
        f"[Cell lines excluded: {', '.join(sorted(EXCLUDED_CELL_LINES))}; "
        f"T1/T2 technical replicates averaged]",
        fontsize=8
    )
    cats_here = sorted(sub["edit_category"].unique())
    handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
    axes[0].legend(handles, cats_here, loc="upper right", fontsize=5,
                   ncol=max(1, len(cats_here) // 4), framealpha=0.7)

    out = os.path.join(OUT_DIR, f"01_tracks_BG4_{win_label}.pdf")
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"  Saved {out}")

# ── 2. Cell line plot ──────────────────────────────────────────────────────────
print("\nPlotting normalised CPM per cell line …")

cell_line_stats = (
    meta.groupby(["cell_line", "edit_category"])["norm_cpm"]
    .agg(mean="mean", sem="sem", n="count")
    .reset_index()
)
cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_norm_cpm.tsv"), sep="\t", index=False)

sub = cell_line_stats.sort_values("cell_line")
fig, ax = plt.subplots(figsize=(max(8, len(sub) * 0.35 + 2), 5))
colors = [cat_palette[c] for c in sub["edit_category"]]
ax.bar(range(len(sub)), sub["mean"], yerr=sub["sem"],
       color=colors, capsize=3, width=0.7, error_kw=dict(linewidth=1))
ax.set_xticks(range(len(sub)))
ax.set_xticklabels(sub["cell_line"], rotation=60, ha="right", fontsize=6)
ax.set_ylabel("Normalised CPM (target / reference)")
ax.set_title("BG4: Mean normalised CPM per cell line\n"
             "(mean ± SEM across biological replicates)")
cats_here = sorted(sub["edit_category"].unique())
handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
ax.legend(handles, cats_here, loc="upper right", fontsize=7,
          ncol=max(1, len(cats_here) // 4))
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
out = os.path.join(OUT_DIR, "02_cell_line_BG4.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

# ── 3. Edit category plot + statistics ────────────────────────────────────────
print("\nPlotting normalised CPM per edit category + statistics …")

cat_stats = (
    meta.groupby("edit_category")["norm_cpm"]
    .agg(mean="mean", std="std", sem="sem", n="count", values=list)
    .reset_index()
)
cat_stats.to_csv(os.path.join(OUT_DIR, "edit_category_norm_cpm.tsv"), sep="\t", index=False)

groups = {cat: grp["norm_cpm"].dropna().values
          for cat, grp in meta.groupby("edit_category")}
vals = [v for v in groups.values() if len(v) >= 2]
h_stat, kw_p = (stats.kruskal(*vals) if len(vals) >= 2 else (np.nan, np.nan))

all_stats = []
for g1, g2 in combinations(sorted(groups.keys()), 2):
    v1, v2 = groups[g1], groups[g2]
    u, p = (stats.mannwhitneyu(v1, v2, alternative="two-sided")
            if len(v1) >= 2 and len(v2) >= 2 else (np.nan, np.nan))
    all_stats.append(dict(group1=g1, group2=g2, U=u, p_raw=p, kw_H=h_stat, kw_p=kw_p))

stats_df = pd.DataFrame(all_stats)
if not stats_df.empty:
    p_vals = stats_df["p_raw"].values
    valid = ~np.isnan(p_vals)
    padj = np.full(len(p_vals), np.nan)
    if valid.sum() > 1:
        _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
    elif valid.sum() == 1:
        padj[valid] = p_vals[valid]
    stats_df["p_adj_BH"] = padj
    stats_df["significant"] = padj < 0.05
    stats_df.to_csv(os.path.join(OUT_DIR, "statistics_pairwise.tsv"), sep="\t", index=False)
    print("Saved statistics_pairwise.tsv")
    sig = stats_df[stats_df["significant"] == True]
    print(f"{len(sig)} significant pairwise comparisons (FDR<0.05):")
    if not sig.empty:
        print(sig[["group1", "group2", "p_raw", "p_adj_BH"]].to_string(index=False))

def sig_stars(p):
    if np.isnan(p): return ""
    if p < 0.001: return "***"
    if p < 0.01:  return "**"
    if p < 0.05:  return "*"
    return "ns"

sub_cat = cat_stats.sort_values("edit_category")
n_cats = len(sub_cat)
fig, ax = plt.subplots(figsize=(max(6, n_cats * 0.8 + 2), 6))
colors = [cat_palette[c] for c in sub_cat["edit_category"]]
positions = np.arange(n_cats)

ax.bar(positions, sub_cat["mean"], yerr=sub_cat["sem"],
       color=colors, alpha=0.75, capsize=4, width=0.6,
       error_kw=dict(linewidth=1.5), zorder=2)

for i, cat in enumerate(sub_cat["edit_category"]):
    pts = meta[meta["edit_category"] == cat]["norm_cpm"].dropna()
    jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
    ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

if not stats_df.empty:
    y_max = sub_cat["mean"].max() + sub_cat["sem"].max()
    cats_ordered = list(sub_cat["edit_category"])
    step = y_max * 0.12
    level = 0
    for _, row_s in stats_df[stats_df.get("p_adj_BH", pd.Series()) < 0.05].iterrows():
        if row_s["group1"] not in cats_ordered or row_s["group2"] not in cats_ordered:
            continue
        x1 = cats_ordered.index(row_s["group1"])
        x2 = cats_ordered.index(row_s["group2"])
        y = y_max + step * (level + 1)
        ax.plot([x1, x1, x2, x2], [y - step * 0.1, y, y, y - step * 0.1],
                color="black", linewidth=0.8)
        ax.text((x1 + x2) / 2, y + step * 0.05,
                sig_stars(row_s["p_adj_BH"]), ha="center", va="bottom", fontsize=8)
        level += 1

ax.set_xticks(positions)
ax.set_xticklabels(sub_cat["edit_category"], rotation=30, ha="right", fontsize=8)
ax.set_ylabel("Normalised CPM (target / reference)")
kw_text = f"  (Kruskal-Wallis p={kw_p:.3g})" if not np.isnan(kw_p) else ""
ax.set_title(f"BG4: Mean normalised CPM per edit category{kw_text}\n"
             f"(bar = mean ± SEM; dots = biological replicates; * FDR<0.05)\n"
             f"[Cell lines excluded: {', '.join(sorted(EXCLUDED_CELL_LINES))}]")
ax.spines[["top", "right"]].set_visible(False)
plt.tight_layout()
out = os.path.join(OUT_DIR, "03_edit_category_BG4.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

# ── 4. Raw CPM plots (cell line level) ────────────────────────────────────────
print("\nPlotting raw CPM (target & reference) per cell line …")

raw_cell_line_stats = (
    meta.groupby(["cell_line", "edit_category"])[["target_cpm", "ref_cpm"]]
    .agg(["mean", "sem", "count"])
)
raw_cell_line_stats.columns = ["_".join(c) for c in raw_cell_line_stats.columns]
raw_cell_line_stats = raw_cell_line_stats.reset_index().sort_values("cell_line")
raw_cell_line_stats.to_csv(os.path.join(OUT_DIR, "cell_line_raw_cpm.tsv"), sep="\t", index=False)

colors = [cat_palette[c] for c in raw_cell_line_stats["edit_category"]]
fig, axes = plt.subplots(2, 1, figsize=(max(8, len(raw_cell_line_stats) * 0.35 + 2), 9),
                         sharex=True)
for ax, col, label in zip(
    axes, ["target_cpm", "ref_cpm"],
    [f"Target CPM ({TARGET_CHR}:{TARGET_START:,}-{TARGET_END:,})",
     f"Reference CPM ({REF_CHR}:{REF_START:,}-{REF_END:,})"]
):
    ax.bar(range(len(raw_cell_line_stats)), raw_cell_line_stats[f"{col}_mean"],
           yerr=raw_cell_line_stats[f"{col}_sem"],
           color=colors, capsize=3, width=0.7, error_kw=dict(linewidth=1))
    ax.set_ylabel(f"{label}\nraw CPM")
    ax.spines[["top", "right"]].set_visible(False)

axes[-1].set_xticks(range(len(raw_cell_line_stats)))
axes[-1].set_xticklabels(raw_cell_line_stats["cell_line"], rotation=60, ha="right", fontsize=6)
fig.suptitle("BG4: Mean raw CPM per cell line (mean ± SEM across biological replicates)",
             fontsize=9)
cats_here = sorted(raw_cell_line_stats["edit_category"].unique())
handles = [plt.Rectangle((0, 0), 1, 1, color=cat_palette[c]) for c in cats_here]
axes[0].legend(handles, cats_here, loc="upper right", fontsize=7,
               ncol=max(1, len(cats_here) // 4))
plt.tight_layout()
out = os.path.join(OUT_DIR, "04_cell_line_BG4_raw_cpm.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

# ── 5. Raw CPM plots (edit category level) + statistics ──────────────────────
print("\nPlotting raw CPM (target & reference) per edit category …")

raw_cat_stats = (
    meta.groupby("edit_category")[["target_cpm", "ref_cpm"]]
    .agg(["mean", "sem", "count"])
)
raw_cat_stats.columns = ["_".join(c) for c in raw_cat_stats.columns]
raw_cat_stats = raw_cat_stats.reset_index().sort_values("edit_category")
raw_cat_stats.to_csv(os.path.join(OUT_DIR, "edit_category_raw_cpm.tsv"), sep="\t", index=False)

# Kruskal-Wallis + pairwise Mann-Whitney (BH-FDR) for each raw CPM metric
raw_stats_all = []
raw_kw_p = {}
for col in ["target_cpm", "ref_cpm"]:
    groups = {cat: grp[col].dropna().values for cat, grp in meta.groupby("edit_category")}
    vals = [v for v in groups.values() if len(v) >= 2]
    h_stat, kw_p_col = (stats.kruskal(*vals) if len(vals) >= 2 else (np.nan, np.nan))
    raw_kw_p[col] = kw_p_col
    for g1, g2 in combinations(sorted(groups.keys()), 2):
        v1, v2 = groups[g1], groups[g2]
        u, p = (stats.mannwhitneyu(v1, v2, alternative="two-sided")
                if len(v1) >= 2 and len(v2) >= 2 else (np.nan, np.nan))
        raw_stats_all.append(dict(metric=col, group1=g1, group2=g2, U=u, p_raw=p,
                                  kw_H=h_stat, kw_p=kw_p_col))

raw_stats_df = pd.DataFrame(raw_stats_all)
if not raw_stats_df.empty:
    for col in ["target_cpm", "ref_cpm"]:
        mask = raw_stats_df["metric"] == col
        p_vals = raw_stats_df.loc[mask, "p_raw"].values
        valid = ~np.isnan(p_vals)
        padj = np.full(len(p_vals), np.nan)
        if valid.sum() > 1:
            _, padj[valid], _, _ = multipletests(p_vals[valid], method="fdr_bh")
        elif valid.sum() == 1:
            padj[valid] = p_vals[valid]
        raw_stats_df.loc[mask, "p_adj_BH"] = padj
        raw_stats_df.loc[mask, "significant"] = padj < 0.05
    raw_stats_df.to_csv(os.path.join(OUT_DIR, "statistics_pairwise_raw_cpm.tsv"), sep="\t", index=False)
    print("Saved statistics_pairwise_raw_cpm.tsv")
    sig = raw_stats_df[raw_stats_df["significant"] == True]
    print(f"{len(sig)} significant pairwise comparisons (FDR<0.05) for raw CPM:")
    if not sig.empty:
        print(sig[["metric", "group1", "group2", "p_raw", "p_adj_BH"]].to_string(index=False))

n_cats = len(raw_cat_stats)
positions = np.arange(n_cats)
colors = [cat_palette[c] for c in raw_cat_stats["edit_category"]]
cats_ordered = list(raw_cat_stats["edit_category"])
fig, axes = plt.subplots(1, 2, figsize=(max(10, n_cats * 1.4 + 3), 6))
for ax, col, label in zip(
    axes, ["target_cpm", "ref_cpm"],
    [f"Target CPM ({TARGET_CHR}:{TARGET_START:,}-{TARGET_END:,})",
     f"Reference CPM ({REF_CHR}:{REF_START:,}-{REF_END:,})"]
):
    ax.bar(positions, raw_cat_stats[f"{col}_mean"], yerr=raw_cat_stats[f"{col}_sem"],
           color=colors, alpha=0.75, capsize=4, width=0.6,
           error_kw=dict(linewidth=1.5), zorder=2)
    for i, cat in enumerate(raw_cat_stats["edit_category"]):
        pts = meta[meta["edit_category"] == cat][col].dropna()
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, len(pts))
        ax.scatter(i + jitter, pts, color="black", s=15, alpha=0.6, zorder=3)

    if not raw_stats_df.empty:
        col_stats = raw_stats_df[raw_stats_df["metric"] == col]
        y_max = raw_cat_stats[f"{col}_mean"].max() + raw_cat_stats[f"{col}_sem"].max()
        step = y_max * 0.12
        level = 0
        for _, row_s in col_stats[col_stats.get("p_adj_BH", pd.Series()) < 0.05].iterrows():
            if row_s["group1"] not in cats_ordered or row_s["group2"] not in cats_ordered:
                continue
            x1 = cats_ordered.index(row_s["group1"])
            x2 = cats_ordered.index(row_s["group2"])
            y = y_max + step * (level + 1)
            ax.plot([x1, x1, x2, x2], [y - step * 0.1, y, y, y - step * 0.1],
                    color="black", linewidth=0.8)
            ax.text((x1 + x2) / 2, y + step * 0.05,
                    sig_stars(row_s["p_adj_BH"]), ha="center", va="bottom", fontsize=8)
            level += 1

    kw_p_col = raw_kw_p.get(col, np.nan)
    kw_text = f"  (Kruskal-Wallis p={kw_p_col:.3g})" if not np.isnan(kw_p_col) else ""
    ax.set_xticks(positions)
    ax.set_xticklabels(raw_cat_stats["edit_category"], rotation=30, ha="right", fontsize=8)
    ax.set_ylabel(f"{label}\nraw CPM")
    ax.set_title(label.split(" (")[0] + kw_text, fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)

fig.suptitle("BG4: Mean raw CPM per edit category\n"
             "(bar = mean ± SEM; dots = biological replicates; * FDR<0.05)\n"
             f"[Cell lines excluded: {', '.join(sorted(EXCLUDED_CELL_LINES))}]", fontsize=9)
plt.tight_layout()
out = os.path.join(OUT_DIR, "05_edit_category_BG4_raw_cpm.pdf")
fig.savefig(out, bbox_inches="tight", dpi=150)
plt.close(fig)
print(f"  Saved {out}")

print(f"\nAll outputs written to: {OUT_DIR}")
